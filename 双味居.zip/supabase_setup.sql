-- ==========================================
-- Supabase Setup SQL Script
-- 复制并在 Supabase 的 "SQL Editor" 中运行以下脚本以初始化所需的数据库表。
-- ==========================================

-- 1. 创建 settings 表 (存储菜单分类、餐厅设置等全局配置)
CREATE TABLE IF NOT EXISTS public.settings (
    id text PRIMARY KEY,
    categories jsonb DEFAULT '[]'::jsonb,
    promotions jsonb DEFAULT '[]'::jsonb,
    "bgUrl" text DEFAULT '',
    "restaurantName" text DEFAULT '',
    "welcomeMessage" text DEFAULT '',
    "logoUrl" text DEFAULT '',
    "adminPassword" text DEFAULT 'admin123',
    "devicePasswords" jsonb DEFAULT '[]'::jsonb,
    "securityQuestion" text DEFAULT '',
    "securityAnswer" text DEFAULT '',
    "soundEnabled" boolean DEFAULT true,
    "layoutStyle" text DEFAULT 'grid',
    "receiptSettings" jsonb DEFAULT '{}'::jsonb
);

-- 关闭 RLS (为了让前端能够直接安全可靠地读写，也可以按需在 Supabase 后台启用更复杂的安全规则)
ALTER TABLE public.settings DISABLE ROW LEVEL SECURITY;

-- 插入默认的全局配置 (如果尚未存在)
INSERT INTO public.settings (id) VALUES ('global') ON CONFLICT (id) DO NOTHING;


-- 2. 创建 orders 表 (存储顾客提交的订单)
CREATE TABLE IF NOT EXISTS public.orders (
    _id text PRIMARY KEY, -- 使用 UUID 或者字符串主键
    "customerName" text,
    status text DEFAULT 'pending',
    items jsonb DEFAULT '[]'::jsonb,
    total numeric DEFAULT 0,
    timestamp text,
    notes text DEFAULT '',
    "unprintedNewOrder" boolean DEFAULT false,
    "unprintedAdditions" jsonb DEFAULT '[]'::jsonb,
    "createdAt" timestamp with time zone DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.orders DISABLE ROW LEVEL SECURITY;


-- 3. 创建 tables 表 (存储餐桌二维码以及激活状态)
CREATE TABLE IF NOT EXISTS public.tables (
    "tableNo" text PRIMARY KEY,
    key text,
    active boolean DEFAULT true,
    "createdAt" text
);

ALTER TABLE public.tables DISABLE ROW LEVEL SECURITY;

-- ==========================================
-- 存储桶 (Storage Bucket) 配置指南：
-- 1. 请在 Supabase 控制台进入 "Storage" 页面。
-- 2. 新建一个 Storage Bucket，命名为 "menu-assets"。
-- 3. 将其设置为 "Public" (公开访问)。
-- 4. 点击 "Policies" 为该存储桶添加一条允许公开读取与插入(Select / Insert)的策略 (或直接放开 CRUD)。
-- ==========================================

-- ==========================================
-- 开启 Realtime 实时广播/数据同步功能：
-- 您可以直接在 SQL Editor 中运行以下代码，为 settings, orders, tables 表开启实时同步。
-- ==========================================
alter publication supabase_realtime add table public.settings;
alter publication supabase_realtime add table public.orders;
alter publication supabase_realtime add table public.tables;

