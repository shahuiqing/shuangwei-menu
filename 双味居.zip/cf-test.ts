import fs from 'fs';
const token = 'cfut_dOsFdaTXOOXQFHeVLRcSVUF1T6dzmpSEIdj8aYeg04490f38';
const accountId = 'b02c56ea53cc6c341f2df4f7ab687960';
const dbId = '7909fbf9-5128-42be-837f-d5d4927027a8';

async function test() {
  const res = await fetch(`https://api.cloudflare.com/client/v4/accounts/${accountId}/d1/database/${dbId}/query`, {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      sql: "CREATE TABLE IF NOT EXISTS settings (id TEXT PRIMARY KEY, data TEXT)"
    })
  });
  const data = await res.json();
  console.log(JSON.stringify(data));
}
test();

