import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const storage = getStorage(app);

// Configure short timeouts (3 seconds) to prevent infinite hanging when Storage is disabled or over quota
if (storage) {
  storage.maxUploadRetryTime = 3000;
  storage.maxOperationRetryTime = 3000;
}

