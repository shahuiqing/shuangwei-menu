import { safeGetItem, safeSetItem } from "../utils/storage";
import { useState, useMemo, useEffect } from "react";
import type { FormEvent, ChangeEvent } from "react";
import { api } from "../api";
import {
  X,
  Lock,
  Image as ImageIcon,
  Plus,
  Languages,
  Key,
  Sparkles,
  Loader2,
  Volume2,
  VolumeX,
  Trash2,
  Printer,
  QrCode,
  Maximize,
  CircleDollarSign,
  LayoutList,
  Palette,
  Wrench,
  Shield,
  Database,
  Layout,
  DownloadCloud,
  UploadCloud,
  FileSpreadsheet,
  Copy,
  Check,
  Save,
  Settings,
  Sun,
  Moon,
  List,
  Flame,
  Edit2,
  ShoppingBag,
  User,
  CheckCircle,
  Scan,
  Download,
  HardDrive,
  Cloud,
  AlertTriangle,
  RefreshCw,
  Boxes,
} from "lucide-react";
import { QRCodeSVG, QRCodeCanvas } from "qrcode.react";
import { GoogleGenAI, Type } from "@google/genai";
import { compressImage, compressBase64Image, drawBeautifulTableCard } from "../utils/image";
import { uploadBase64ToStorage } from "../utils/storage";
import { InventoryManager } from "./InventoryManager";
import { SupabaseSetupModal } from "./SupabaseSetupModal";

interface AdminPanelProps {
  categories: any[];
  setCategories: (categories: any[]) => void;
  promotions?: any[];
  setPromotions?: (promotions: any[]) => void;
  restaurantName?: string;
  setRestaurantName?: (name: string) => void;
  welcomeMessage?: string;
  setWelcomeMessage?: (msg: string) => void;
  bgUrl: string;
  setBgUrl: (url: string) => void;
  logoUrl: string;
  setLogoUrl: (url: string) => void;
  layoutStyle?: "grid" | "list" | "bento";
  setLayoutStyle?: (style: "grid" | "list" | "bento") => void;
  theme?: "midnight" | "light";
  setTheme?: (theme: "midnight" | "light") => void;
  adminPassword?: string;
  setAdminPassword?: (password: string) => void;
  devicePasswords?: { name: string; password: string }[];
  setDevicePasswords?: (
    passwords: { name: string; password: string }[],
  ) => void;
  securityQuestion?: string;
  securityAnswer?: string;
  setSecurity?: (question: string, answer: string) => void;
  soundEnabled?: boolean;
  setSoundEnabled?: (enabled: boolean) => void;
  onClose: () => void;
  isAuthed: boolean;
  setIsAuthed: (authed: boolean) => void;
  onDeviceAuthed?: () => void;
  isSynced?: boolean;
  isCloudConnected?: boolean;
  onSaveToCloud?: (overrides?: any) => void;
  onRestoreBackup?: (data: any) => Promise<void>;
  receiptSettings?: any;
  setReceiptSettings?: (settings: any) => void;
}

const PRESET_BACKGROUNDS = [
  { id: "none", name: "默认暗黑", url: "" },
  {
    id: "fire",
    name: "沉浸炭火",
    url: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?q=80&w=2574&auto=format&fit=crop",
  },
  {
    id: "wood",
    name: "黑金原木",
    url: "https://images.unsplash.com/photo-1550684376-efcbd6e3f031?q=80&w=2670&auto=format&fit=crop",
  },
  {
    id: "spices",
    name: "秘制香辛",
    url: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?q=80&w=2670&auto=format&fit=crop",
  },
  {
    id: "abstract",
    name: "深邃暗影",
    url: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2664&auto=format&fit=crop",
  },
];

import { ALLERGEN_OPTIONS } from "../constants";

export default function AdminPanel({
  categories,
  setCategories,
  promotions = [],
  setPromotions,
  restaurantName = "炙·双味居",
  setRestaurantName,
  welcomeMessage = "Premium Charcoal BBQ",
  setWelcomeMessage,
  bgUrl,
  setBgUrl,
  logoUrl,
  setLogoUrl,
  layoutStyle = "grid",
  setLayoutStyle,
  theme = "midnight",
  setTheme,
  adminPassword = "admin123",
  setAdminPassword,
  devicePasswords = [],
  setDevicePasswords,
  securityQuestion = "",
  securityAnswer = "",
  setSecurity,
  soundEnabled = true,
  setSoundEnabled,
  onClose,
  isAuthed,
  setIsAuthed,
  onDeviceAuthed,
  isSynced = true,
  isCloudConnected = false,
  onSaveToCloud,
  onRestoreBackup,
  receiptSettings,
  setReceiptSettings,
}: AdminPanelProps) {
  const [currency, setCurrency] = useState("MAD");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isSupabaseSetupOpen, setIsSupabaseSetupOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<
    | "menu"
    | "promotions"
    | "appearance"
    | "tools"
    | "security"
    | "database"
    | "orders"
    | "printer"
  >("orders");

  // Settings State
  const [apiKey, setApiKey] = useState(() => safeGetItem("geminiApiKey") || "");
  const [isPrintServer, setIsPrintServer] = useState(() => safeGetItem("isPrintServer") === "true");
  const [newAdminPassword, setNewAdminPassword] = useState("");
  const [newSecurityQuestion, setNewSecurityQuestion] = useState(
    securityQuestion || "",
  );
  const [newSecurityAnswer, setNewSecurityAnswer] = useState(
    securityAnswer || "",
  );
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    message: string;
    onConfirm: () => void;
    isAlert?: boolean;
  } | null>(null);
  const [checkoutOrder, setCheckoutOrder] = useState<any | null>(null);
  const [checkoutDiscountStr, setCheckoutDiscountStr] = useState<string>("0");
  const [checkoutDiscountMode, setCheckoutDiscountMode] = useState<"amount" | "rate">("amount");
  const [checkoutReceivedStr, setCheckoutReceivedStr] = useState<string>("0");
  const [checkoutPaymentMethod, setCheckoutPaymentMethod] = useState<string>("微信支付");
  const [activeNumpadField, setActiveNumpadField] = useState<
    "discount" | "received"
  >("received");

  const [promptDialog, setPromptDialog] = useState<{
    isOpen: boolean;
    message: string;
    defaultValue: string;
    onConfirm: (value: string) => void;
  } | null>(null);
  const [promptValue, setPromptValue] = useState("");
  const [orderView, setOrderView] = useState<"active" | "history">("active");

  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationProgress, setOptimizationProgress] = useState("");
  const [importProgress, setImportProgress] = useState("");
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportedJsonStr, setExportedJsonStr] = useState("");
  const [copiedSuccess, setCopiedSuccess] = useState(false);

  const [diagnosticData, setDiagnosticData] = useState<any>(null);
  const [isLoadingDiagnostics, setIsLoadingDiagnostics] = useState(false);
  const [diagnosticError, setDiagnosticError] = useState<string | null>(null);

  const [dbTableStats, setDbTableStats] = useState<{ connected: boolean; tables: Record<string, number> } | null>(null);
  const [isSeedingDb, setIsSeedingDb] = useState(false);
  const [seedLogs, setSeedLogs] = useState<string[] | null>(null);

  const runDiagnostics = async () => {
    try {
      setIsLoadingDiagnostics(true);
      setDiagnosticError(null);
      const [res, stats] = await Promise.all([
        api.getStorageDiagnostics(),
        api.getProductionDatabaseStats()
      ]);
      if (res.success) {
        setDiagnosticData(res);
      } else {
        setDiagnosticError(res.error || "获取诊断信息失败");
      }
      setDbTableStats(stats);
    } catch (err: any) {
      setDiagnosticError(err.message || "系统诊断出错");
    } finally {
      setIsLoadingDiagnostics(false);
    }
  };

  const handleSeedDatabase = async (force: boolean = false) => {
    try {
      setIsSeedingDb(true);
      setSeedLogs(null);
      const res = await api.seedProductionDatabase(force);
      setSeedLogs(res.logs || []);
      const stats = await api.getProductionDatabaseStats();
      setDbTableStats(stats);
    } catch (err: any) {
      setSeedLogs(["❌ 执行初始化失败: " + (err.message || err)]);
    } finally {
      setIsSeedingDb(false);
    }
  };

  const handleDeleteStorageFile = async (path: string) => {
    if (!window.confirm(`确定要从云存储中彻底删除此文件吗？此操作无法撤销：\n${path}`)) {
      return;
    }
    try {
      setIsLoadingDiagnostics(true);
      const res = await api.deleteStorageFile(path);
      if (res.success) {
        alert("文件删除成功！");
        await runDiagnostics();
      } else {
        alert("删除失败：" + (res.error || "未知错误"));
      }
    } catch (err: any) {
      alert("删除出错：" + err.message);
    } finally {
      setIsLoadingDiagnostics(false);
    }
  };

  const base64Count = useMemo(() => {
    let count = 0;
    categories.forEach((cat) => {
      if (cat.items) {
        cat.items.forEach((item: any) => {
          if (item.image && item.image.startsWith("data:image/") && item.image.length > 15000) {
            count++;
          }
        });
      }
    });
    return count;
  }, [categories]);

  const handleOptimizeImages = async () => {
    try {
      setIsOptimizing(true);
      setOptimizationProgress("正在准备优化...");
      
      let processed = 0;
      const totalToProcess = base64Count;
      
      const updatedCategories = [];
      for (const cat of categories) {
        const updatedItems = [];
        if (cat.items) {
          for (const item of cat.items) {
            if (item.image && item.image.startsWith("data:image/") && item.image.length > 15000) {
              processed++;
              setOptimizationProgress(`正在优化并托管第 ${processed}/${totalToProcess} 张图片...`);
              try {
                const publicUrl = await uploadBase64ToStorage(item.image, "dishes");
                updatedItems.push({
                  ...item,
                  image: publicUrl
                });
              } catch (err) {
                console.error(`Failed to upload ${item.title}:`, err);
                updatedItems.push(item);
              }
            } else {
              updatedItems.push(item);
            }
          }
        }
        updatedCategories.push({
          ...cat,
          items: updatedItems
        });
      }
      
      setOptimizationProgress("正在更新菜单设置...");
      setCategories(updatedCategories);
      
      if (onSaveToCloud) {
        try {
          await onSaveToCloud({
            categories: updatedCategories,
            silent: true
          });
          alert(`🎉 优化成功！已成功将 ${processed} 张图片迁移至云端存储/高效压缩，数据库空间已释放 99%！`);
        } catch (saveErr: any) {
          console.warn("Save to cloud had warning, but items were updated in local cache:", saveErr);
          // If Firestore is over quota, it is still saved to localStorage!
          alert(`🎉 优化成功！已成功在本地对 ${processed} 张大图进行了 90% 级别的高效压缩，菜单体积缩减了 95%！\n\n*(注意：因云端数据库今日免费额度用尽，该优化已安全保存在本地浏览器中，不影响您的正常使用。等明天额度刷新后即可自动同步到云端！)*`);
        }
      } else {
        alert(`🎉 优化成功！已成功压缩并处理了 ${processed} 张图片。`);
      }
    } catch (e: any) {
      alert(`❌ 优化失败: ${e.message}`);
    } finally {
      setIsOptimizing(false);
      setOptimizationProgress("");
    }
  };

  const [orders, setOrders] = useState<any[]>([]);
  const [tables, setTables] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<{id: string, message: string, time: Date}[]>([]);

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/?role=admin`;
    const ws = new WebSocket(wsUrl);

    ws.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data);
        if (data.type === 'admin_notification') {
          setNotifications(prev => [{ id: Date.now().toString(), message: data.message, time: new Date() }, ...prev].slice(0, 10));
          // Auto-remove notification after 8 seconds
          setTimeout(() => {
            setNotifications(prev => prev.filter(n => Date.now() - n.time.getTime() < 8000));
          }, 8000);
          
          // Play a sound for prominence
          try {
             const audio = new Audio("data:audio/mp3;base64,//NExAAAAANIAAAAAExBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//NExAAAAANIAAAAAExBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq");
             const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
             const osc = ctx.createOscillator();
             const gain = ctx.createGain();
             osc.connect(gain);
             gain.connect(ctx.destination);
             osc.type = "sine";
             osc.frequency.setValueAtTime(880, ctx.currentTime);
             gain.gain.setValueAtTime(0.1, ctx.currentTime);
             osc.start();
             gain.gain.exponentialRampToValueAtTime(0.00001, ctx.currentTime + 1);
             osc.stop(ctx.currentTime + 1);
          } catch(err){}
        }
      } catch (err) {}
    };
    return () => ws.close();
  }, []);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    unsubscribe = api.subscribeToOrders((data) => {
      if (Array.isArray(data)) {
        const now = Date.now();
        data.forEach(order => {
          if (order.status === "completed") {
            const updatedAt = order.updatedAt ? new Date(order.updatedAt).getTime() : new Date(order.timestamp).getTime();
            if (now - updatedAt > 2 * 60 * 60 * 1000) {
              api.deleteOrder(order._id).catch(console.error);
            }
          }
          
          if (isPrintServer) {
            let needsUpdate = false;
            let updatePayload: any = {};

            if (order.unprintedNewOrder) {
              import("../lib/print").then((m) => {
                m.printReceipt(order, currency, receiptSettings, true); // print kitchen ticket
              });
              needsUpdate = true;
              updatePayload.unprintedNewOrder = false;
            }

            if (order.unprintedAdditions && order.unprintedAdditions.length > 0) {
              import("../lib/print").then((m) => {
                order.unprintedAdditions.forEach((addition: any) => {
                  const dummyOrder = { ...order, items: addition.items };
                  m.printReceipt(dummyOrder, currency, receiptSettings, false, "addition");
                });
              });
              needsUpdate = true;
              updatePayload.unprintedAdditions = [];
            }

            if (needsUpdate) {
              api.updateOrder(order._id, updatePayload).catch(console.error);
            }
          }
        });
        const sorted = [...data].sort((a, b) => {
          const statusA = a.status || "pending";
          const statusB = b.status || "pending";
          if (statusA === "pending" && statusB !== "pending") return -1;
          if (statusA !== "pending" && statusB === "pending") return 1;
          return (
            new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
          );
        });
        setOrders(sorted);
      }
    });
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [currency, receiptSettings, isPrintServer]);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    if (activeTab === "qr") {
      unsubscribe = api.subscribeToTables((data) => {
        if (Array.isArray(data)) {
          setTables(data);
        }
      });
    }
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [activeTab]);

  useEffect(() => {
    if (activeTab === "database") {
      runDiagnostics();
    }
  }, [activeTab]);

  // Form state
  const handleSimulateExternalOrder = async () => {
    try {
      const order = {
        orderNumber: "SW-" + Date.now(),
        customerName: "网站客户",
        items: [
          { name: "测试商品A", enTitle: "Test Item A", frTitle: "Produit Test A", quantity: 2, price: 15.0 },
          { name: "测试商品B", enTitle: "Test Item B", quantity: 1, price: 20.0 },
        ],
        total: 50.0,
        notes: "来自 shuangwei 网站的直连订单",
        timestamp: new Date().toISOString(),
        isExternal: true,
        deviceInfo: "模拟设备 (Simulated Device)",
      };

      await api.addOrder(order);
      alert("✅ 模拟外部订单成功接收并打印！");
      import("../lib/print").then((m) =>
        m.printReceipt(order, currency, receiptSettings),
      );
    } catch (error) {
      console.error("网络请求失败:", error);
      alert("网络请求失败：" + error);
    }
  };

  const [selectedCategory, setSelectedCategory] = useState(
    categories[0]?.id || "",
  );
  const [newCategory, setNewCategory] = useState({
    name: "",
    enName: "",
    frName: "",
    arName: "",
    maName: "",
  });
  const [newDish, setNewDish] = useState({
    title: "",
    enTitle: "",
    frTitle: "",
    arTitle: "",
    maTitle: "",
    description: "",
    enDescription: "",
    frDescription: "",
    arDescription: "",
    maDescription: "",
    price: "",
    image: "",
    allergens: [] as string[],
    stock: "",
  });
  const [uploadingItemId, setUploadingItemId] = useState<string | null>(null);

  const [newPromotion, setNewPromotion] = useState({
    title: "",
    enTitle: "",
    frTitle: "",
    arTitle: "",
    maTitle: "",
    description: "",
    enDescription: "",
    frDescription: "",
    arDescription: "",
    maDescription: "",
    image: "",
  });
  const [isTranslating, setIsTranslating] = useState(false);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isGeneratingWelcome, setIsGeneratingWelcome] = useState(false);
  const [generatedWelcomes, setGeneratedWelcomes] = useState<string[]>([]);

  const [isForgotMode, setIsForgotMode] = useState(false);
  const [verifyAnswer, setVerifyAnswer] = useState("");

  const handleVerifySecurity = (e: FormEvent) => {
    e.preventDefault();
    if (verifyAnswer.trim() === securityAnswer) {
      alert(
        `验证成功！您的密码是：\n(Verification successful! Your password is:)\n${adminPassword}`,
      );
      setVerifyAnswer("");
      setIsForgotMode(false);
      setError("");
    } else {
      setError("安全问题答案错误 / Incorrect Answer");
    }
  };

  const [currentWaiter, setCurrentWaiter] = useState<{
    name: string;
    password: string;
  } | null>(null);

  useEffect(() => {
    const savedToken = localStorage.getItem("deviceAuthToken");
    const expiry = localStorage.getItem("deviceAuthTokenExpiry");
    if (savedToken && expiry && Date.now() < parseInt(expiry, 10)) {
      const matched = devicePasswords?.find((d) => d.password === savedToken);
      if (matched) setCurrentWaiter(matched);
    }
  }, [devicePasswords, isAuthed]);

  const handleLogin = (e: FormEvent) => {
    e.preventDefault();
    if (password === adminPassword) {
      setIsAuthed(true);
      return;
    }

    const matchedDevice = devicePasswords?.find((d) => d.password === password);
    if (matchedDevice) {
      localStorage.setItem("deviceAuthToken", matchedDevice.password);
      // 5 days expiry (5 * 24 * 60 * 60 * 1000 = 432000000)
      localStorage.setItem(
        "deviceAuthTokenExpiry",
        (Date.now() + 432000000).toString(),
      );
      alert(
        `✅ 服务员 [${matchedDevice.name}] 已认证，点单功能已解锁 (Waiter Authenticated)`,
      );
      if (onDeviceAuthed) onDeviceAuthed();
      onClose();
      return;
    }

    setError("密码错误 / Incorrect Password");
  };

  const handleApiKeyChange = (e: ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setApiKey(val);
    safeSetItem("geminiApiKey", val);
  };

  const handleExportJson = () => {
    try {
      const backupObj = {
        categories,
        promotions,
        restaurantName,
        welcomeMessage,
        bgUrl,
        logoUrl,
        layoutStyle,
        theme,
        soundEnabled,
        adminPassword,
        devicePasswords,
        securityQuestion,
        securityAnswer,
        exportDate: new Date().toISOString(),
      };

      const jsonStr = JSON.stringify(backupObj, null, 2);
      setExportedJsonStr(jsonStr);

      const blob = new Blob([jsonStr], { type: "application/json;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const fileName = "menu_backup_" + new Date().toISOString().split("T")[0] + ".json";

      const downloadAnchorNode = document.createElement("a");
      downloadAnchorNode.href = url;
      downloadAnchorNode.setAttribute("download", fileName);
      downloadAnchorNode.style.display = "none";
      document.body.appendChild(downloadAnchorNode);
      downloadAnchorNode.click();

      setTimeout(() => {
        if (downloadAnchorNode.parentNode) {
          downloadAnchorNode.parentNode.removeChild(downloadAnchorNode);
        }
        URL.revokeObjectURL(url);
      }, 1000);

      setShowExportModal(true);
    } catch (err: any) {
      console.error("Failed to export JSON:", err);
      alert("导出 JSON 失败: " + (err?.message || "未知错误"));
    }
  };

  const handleExportCsv = () => {
    try {
      const headers = [
        "分类ID",
        "分类名称(中文)",
        "分类英文名",
        "分类法文名",
        "菜品ID",
        "菜品中文名",
        "英文名",
        "法文名",
        "阿拉伯文名",
        "摩洛哥文名",
        "价格",
        "中文描述",
        "英文描述",
        "法文描述",
        "阿拉伯文描述",
        "摩洛哥文描述",
        "图片URL",
      ];

      const rows: string[][] = [headers];

      categories.forEach((cat: any) => {
        const catName = cat.name || cat.id || "";
        const catEnName = cat.enName || "";
        const catFrName = cat.frName || "";

        (cat.items || []).forEach((item: any) => {
          rows.push([
            cat.id || "",
            catName,
            catEnName,
            catFrName,
            item.id || "",
            item.title || "",
            item.enTitle || "",
            item.frTitle || "",
            item.arTitle || "",
            item.maTitle || "",
            item.price || "",
            item.description || "",
            item.enDescription || "",
            item.frDescription || "",
            item.arDescription || "",
            item.maDescription || "",
            item.image && !item.image.startsWith("data:image") ? item.image : "[图片地址]",
          ]);
        });
      });

      const csvContent =
        "\uFEFF" +
        rows
          .map((row) =>
            row
              .map((cell) => `"${String(cell || "").replace(/"/g, '""')}"`)
              .join(",")
          )
          .join("\r\n");

      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const fileName = `menu_items_${new Date().toISOString().split("T")[0]}.csv`;

      const a = document.createElement("a");
      a.href = url;
      a.setAttribute("download", fileName);
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();

      setTimeout(() => {
        if (a.parentNode) {
          a.parentNode.removeChild(a);
        }
        URL.revokeObjectURL(url);
      }, 1000);
    } catch (err: any) {
      console.error("Export CSV failed:", err);
      alert("导出 CSV 失败: " + (err?.message || "未知错误"));
    }
  };

  const handleCopyJson = () => {
    if (!exportedJsonStr) return;
    navigator.clipboard
      .writeText(exportedJsonStr)
      .then(() => {
        setCopiedSuccess(true);
        setTimeout(() => setCopiedSuccess(false), 2000);
      })
      .catch(() => {
        alert("复制失败，请在下方框内全选并手动复制。");
      });
  };

  const handleImportJson = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        setImportProgress("正在读取并解析备份文件... (Reading file...)");
        const obj = JSON.parse(event.target?.result as string);

        if (!obj.categories || !Array.isArray(obj.categories)) {
          setImportProgress("");
          alert("无效的备份文件结构！/ Invalid backup file structure!");
          return;
        }

        // Count base64 images
        let totalImages = 0;
        let uploadedCount = 0;
        for (const cat of obj.categories) {
          if (cat.items && Array.isArray(cat.items)) {
            for (const item of cat.items) {
              if (item.image && item.image.startsWith("data:image/")) {
                totalImages++;
              }
            }
          }
        }

        if (totalImages > 0) {
          setImportProgress(`正在优化并上传备份中的图片 (0/${totalImages})...`);
          
          for (let i = 0; i < obj.categories.length; i++) {
            const cat = obj.categories[i];
            if (cat.items && Array.isArray(cat.items)) {
              for (let j = 0; j < cat.items.length; j++) {
                const item = cat.items[j];
                if (item.image && item.image.startsWith("data:image/")) {
                  uploadedCount++;
                  setImportProgress(
                    `正在优化并托管图片 [${uploadedCount}/${totalImages}]: ${item.title || "菜品"}`
                  );
                  try {
                    if (isCloudConnected) {
                      const publicUrl = await uploadBase64ToStorage(
                        item.image,
                        "dishes",
                      );
                      item.image = publicUrl;
                    }
                  } catch (err) {
                    console.warn(
                      "Failed to upload/compress restored image",
                      err,
                    );
                  }
                }
              }
            }
          }
        }

        setImportProgress("图片处理完成，正在应用数据设置...");

        if (onRestoreBackup) {
          setImportProgress("正在应用并同步恢复的数据到云端数据库...");
          await onRestoreBackup(obj);
        } else {
          // Fallback if not provided
          setCategories(obj.categories);
          if (obj.promotions && setPromotions) setPromotions(obj.promotions);
          if (obj.restaurantName !== undefined && setRestaurantName)
            setRestaurantName(obj.restaurantName);
          if (obj.welcomeMessage !== undefined && setWelcomeMessage)
            setWelcomeMessage(obj.welcomeMessage);
          if (obj.bgUrl !== undefined && setBgUrl) setBgUrl(obj.bgUrl);
          if (obj.logoUrl !== undefined && setLogoUrl) setLogoUrl(obj.logoUrl);
          if (obj.layoutStyle !== undefined && setLayoutStyle)
            setLayoutStyle(obj.layoutStyle);
          if (obj.theme !== undefined && setTheme) setTheme(obj.theme);
          if (obj.soundEnabled !== undefined && setSoundEnabled)
            setSoundEnabled(obj.soundEnabled);
          if (obj.adminPassword !== undefined && setAdminPassword)
            setAdminPassword(obj.adminPassword);
          if (obj.devicePasswords !== undefined && setDevicePasswords)
            setDevicePasswords(obj.devicePasswords);
          if (
            obj.securityQuestion !== undefined &&
            obj.securityAnswer !== undefined &&
            setSecurity
          ) {
            setSecurity(obj.securityQuestion, obj.securityAnswer);
          }

          if (onSaveToCloud) {
            setImportProgress("正在将恢复的数据同步保存到云端数据库...");
            await onSaveToCloud({
              categories: obj.categories,
              promotions: obj.promotions || promotions,
              restaurantName: obj.restaurantName !== undefined ? obj.restaurantName : restaurantName,
              welcomeMessage: obj.welcomeMessage !== undefined ? obj.welcomeMessage : welcomeMessage,
              bgUrl: obj.bgUrl !== undefined ? obj.bgUrl : bgUrl,
              logoUrl: obj.logoUrl !== undefined ? obj.logoUrl : logoUrl,
              layoutStyle: obj.layoutStyle !== undefined ? obj.layoutStyle : layoutStyle,
              theme: obj.theme !== undefined ? obj.theme : theme,
              soundEnabled: obj.soundEnabled !== undefined ? obj.soundEnabled : soundEnabled,
              adminPassword: obj.adminPassword !== undefined ? obj.adminPassword : adminPassword,
              devicePasswords: obj.devicePasswords !== undefined ? obj.devicePasswords : devicePasswords,
              securityQuestion: obj.securityQuestion !== undefined ? obj.securityQuestion : securityQuestion,
              securityAnswer: obj.securityAnswer !== undefined ? obj.securityAnswer : securityAnswer,
              silent: true
            });
          }
        }

        setImportProgress("");
        alert("🎉 恢复成功！数据已成功加载并同步到云端数据库。/ Restored and synced successfully!");

      } catch (err) {
        console.error("Error during JSON import:", err);
        setImportProgress("");
        alert("解析文件失败！/ Failed to parse file!");
      }
    };
    reader.readAsText(file);
    e.target.value = ""; // Reset input
  };

  const handleAIGenerateWelcomeMessages = async () => {
    if (!apiKey) {
      alert("请先在上方输入 Gemini API Key");
      return;
    }

    setIsGeneratingWelcome(true);
    setGeneratedWelcomes([]);
    try {
      const ai = new GoogleGenAI({ apiKey: apiKey });

      const cuisineConcepts = categories.map((c) => c.name).join(", ");

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `You are an expert restaurant marketing copywriter. 
        The restaurant name is "${restaurantName}". 
        The cuisine style includes: ${cuisineConcepts}.
        
        Please generate 4 short, catchy welcome phrases or slogans (max 4-6 words each) in multiple tones. 
        Tone 1: Premium & Elegant (e.g. Premium Charcoal BBQ, Fine Dining Experience)
        Tone 2: Warm & Inviting (e.g. Welcome to Our Table, Taste the Tradition)
        Tone 3: Modern & Trendy
        Tone 4: Local/Authentic flavor focused
        
        You may output in English or a mix depending on what sounds best as a short subtitle.
        Return ONLY a JSON list of strings representing the 4 options.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
      });

      const jsonStr = response.text?.trim() || "[]";
      const options = JSON.parse(jsonStr);
      if (Array.isArray(options) && options.length > 0) {
        setGeneratedWelcomes(options);
      } else {
        alert("AI 未能生成有效的欢迎语选项");
      }
    } catch (err: any) {
      console.error(err);
      alert("生成失败，请检查 API Key 或网络连通性：" + err.message);
    } finally {
      setIsGeneratingWelcome(false);
    }
  };

  const handleAITranslate = async () => {
    if (!apiKey) {
      alert("请先在上方输入 Gemini API Key");
      return;
    }
    if (!newDish.title && !newDish.description) {
      alert("请先输入中文菜品名称或描述");
      return;
    }

    setIsTranslating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: apiKey });

      const currentCategoryName =
        categories.find((c) => c.id === selectedCategory)?.name || "General";

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `You are an expert culinary translator and Michelin-star restaurant menu copywriter specializing in high-end international dining.
        Your task is to translate and culturally adapt the following Chinese dish name and description into English, French, Standard Arabic, and Moroccan Arabic (Darija).

        Context:
        - Restaurant Name: ${restaurantName || "Premium Restaurant"}
        - Dish Category: ${currentCategoryName}
        - Dining Style: Elegant, authentic, and high-quality

        Translation Guidelines:
        - English & French: Use evocative, poetic, and mouth-watering adjectives. Focus on the sensory experience, cooking techniques, and ingredient quality (e.g., "slow-braised", "crispy", "infused with", "velvety"). Avoid clunky literal translations.
        - Standard Arabic: Use sophisticated, formal culinary Arabic (Fusha) that appeals to fine dining customers. Ensure the terminology sounds luxurious.
        - Moroccan Arabic (Darija): Write in Arabic script using native Moroccan colloquial expressions that sound authentic, welcoming, and appetizing to locals, while maintaining a premium feel.
        - General: Prioritize elegance and appetizing appeal over 1-to-1 literal translation, while preserving the core ingredients and flavor profiles.
        
        Original Dish Details:
        Title: ${newDish.title ? newDish.title : "N/A"}
        Description: ${newDish.description ? newDish.description : "N/A"}
        
        Return ONLY a JSON response in the specified schema format. Ensure the translated descriptions are rich and descriptive.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              enTitle: { type: Type.STRING },
              frTitle: { type: Type.STRING },
              arTitle: { type: Type.STRING },
              maTitle: { type: Type.STRING },
              enDescription: { type: Type.STRING },
              frDescription: { type: Type.STRING },
              arDescription: { type: Type.STRING },
              maDescription: { type: Type.STRING },
            },
            required: [
              "enTitle",
              "frTitle",
              "arTitle",
              "maTitle",
              "enDescription",
              "frDescription",
              "arDescription",
              "maDescription",
            ],
          },
        },
      });

      const jsonStr = response.text?.trim() || "{}";
      const translations = JSON.parse(jsonStr);

      setNewDish((prev) => ({
        ...prev,
        ...translations,
      }));
    } catch (err) {
      console.error(err);
      alert("翻译失败，请检查 API Key 或网络环境。");
    } finally {
      setIsTranslating(false);
    }
  };

  const handleAIEnhanceImage = async () => {
    if (!apiKey) {
      alert("请先在上方输入 Gemini API Key");
      return;
    }
    if (!newDish.image || !newDish.image.startsWith("data:image")) {
      alert("请先上传一张本地图片");
      return;
    }

    setIsEnhancing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: apiKey });

      const mimeType = newDish.image.split(";")[0].split(":")[1];
      const base64Data = newDish.image.split(",")[1];

      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-image",
        contents: {
          parts: [
            {
              text: "Enhance this food photo slightly to make it look appetizing and professional, but keep it extremely realistic and authentic to the original dish. Do NOT make it look over-processed, artificial, or AI-generated. Improve only the lighting, color balance, and minor background clutter. The food itself (ingredients, shape, portions, texture) MUST look exactly like the original photo, just taken with a better camera.",
            },
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType,
              },
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: "1:1",
            imageSize: "1K",
          },
        },
      });

      let foundImage = false;
      if (
        response &&
        response.candidates &&
        response.candidates[0] &&
        response.candidates[0].content &&
        response.candidates[0].content.parts
      ) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const base64EncodeString = part.inlineData.data;
            const imageUrl = `data:image/jpeg;base64,${base64EncodeString}`;
            setNewDish((prev) => ({ ...prev, image: imageUrl }));
            foundImage = true;
            break;
          }
        }
      }

      if (!foundImage) {
        alert("美化失败：API 未返回有效图片");
      }
    } catch (err: any) {
      console.error(err);
      alert("AI 美化失败: " + err.message);
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleAddCategory = (e: FormEvent) => {
    e.preventDefault();
    if (!newCategory.name.trim()) return;
    const catId = Math.random().toString(36).substr(2, 9);
    const updatedCategories = [
      ...categories,
      {
        id: catId,
        name: newCategory.name,
        enName: newCategory.enName,
        frName: newCategory.frName,
        arName: newCategory.arName,
        maName: newCategory.maName,
        items: [],
      },
    ];
    setCategories(updatedCategories);
    // autosave disabled
    setNewCategory({
      name: "",
      enName: "",
      frName: "",
      arName: "",
      maName: "",
    });
    if (!selectedCategory) {
      setSelectedCategory(catId);
    }
    alert("分类添加成功！/ Category added!");
  };

  const handleAddPromotion = (e: FormEvent) => {
    e.preventDefault();
    if (!setPromotions || !promotions) return;
    if (!newPromotion.title.trim()) {
      alert("请填写活动标题 (Please enter a promotion title)");
      return;
    }
    const updatedPromotions = [
      ...promotions,
      {
        id: Math.random().toString(36).substr(2, 9),
        ...newPromotion,
        isActive: true,
      },
    ];
    setPromotions(updatedPromotions);
    setNewPromotion({
      title: "",
      enTitle: "",
      frTitle: "",
      arTitle: "",
      maTitle: "",
      description: "",
      enDescription: "",
      frDescription: "",
      arDescription: "",
      maDescription: "",
      image: "",
    });
    alert("活动添加成功！/ Promotion added!");
  };

  const handleRemovePromotion = (promotionId: string) => {
    if (!setPromotions || !promotions) return;
    setConfirmDialog({
      isOpen: true,
      message:
        "确定要删除此活动吗？ (Are you sure you want to delete this promotion?)",
      onConfirm: () => {
        const updatedPromotions = promotions.filter(
          (p) => p.id !== promotionId,
        );
        setPromotions(updatedPromotions);
        setConfirmDialog(null);
      },
    });
  };

  const handleDeleteCategory = (idToRemove: string) => {
    setConfirmDialog({
      isOpen: true,
      message:
        "确定要删除此分类及里面所有菜品吗？\nAre you sure you want to delete this category and all its dishes?",
      onConfirm: () => {
        const updatedCategories = categories.filter((c) => c.id !== idToRemove);
        setCategories(updatedCategories);
        // autosave disabled
        if (selectedCategory === idToRemove) {
          setSelectedCategory(updatedCategories[0]?.id || "");
        }
        setConfirmDialog(null);
      },
    });
  };

  const handleDeleteDish = (categoryId: string, dishId: string) => {
    setConfirmDialog({
      isOpen: true,
      message:
        "确定要删除这个菜品吗？\nAre you sure you want to delete this dish?",
      onConfirm: () => {
        const updatedCategories = categories.map((cat) => {
          if (cat.id === categoryId) {
            return {
              ...cat,
              items: cat.items.filter((item: any) => item.id !== dishId),
            };
          }
          return cat;
        });
        setCategories(updatedCategories);
        // autosave disabled
        setConfirmDialog(null);
      },
    });
  };

  const handleGlobalCurrencyChange = (newCurrency: string) => {
    setConfirmDialog({
      isOpen: true,
      message: `确定要将所有菜品价格符号更新为 ${newCurrency} 吗？\nAre you sure you want to update all price symbols to ${newCurrency}?`,
      onConfirm: () => {
        const regex = /(MAD|CNY|¥|€|\$|£|dh|迪拉姆|元)/gi;

        const updatedCategories = categories.map((cat) => ({
          ...cat,
          items: (cat.items || []).map((item: any) => {
            let priceStr = item.price || "";
            if (regex.test(priceStr)) {
              priceStr = priceStr.replace(regex, newCurrency);
            } else {
              priceStr = `${newCurrency}${priceStr}`;
            }
            priceStr = priceStr.replace(/\s+/g, " ").trim();
            return { ...item, price: priceStr };
          }),
        }));

        setCategories(updatedCategories);
        // autosave disabled
        alert("货币显示符号更新成功！/ Currency symbols updated!");
        setConfirmDialog(null);
      },
    });
  };

  const totalDishes = useMemo(() => {
    return categories.reduce((acc, cat) => acc + (cat.items?.length || 0), 0);
  }, [categories]);

  const dbSizeKB = useMemo(() => {
    try {
      const settingsObj = {
        categories,
        promotions,
        restaurantName,
        welcomeMessage,
        bgUrl,
        logoUrl,
        adminPassword,
        devicePasswords,
        securityQuestion,
        securityAnswer,
        layoutStyle,
        theme,
        soundEnabled,
      };
      const jsonStr = JSON.stringify(settingsObj);
      // Rough estimation of UTF-16 string size in bytes
      return ((jsonStr.length * 2) / 1024).toFixed(2);
    } catch {
      return "0.00";
    }
  }, [
    categories,
    promotions,
    restaurantName,
    welcomeMessage,
    bgUrl,
    logoUrl,
    adminPassword,
    devicePasswords,
    securityQuestion,
    securityAnswer,
    layoutStyle,
    theme,
    soundEnabled,
  ]);

  const handleFullscreenToggle = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  // Print Settings State
  const [printConfig, setPrintConfig] = useState({
    layout: "grid" as "grid" | "list",
    showLogo: true,
    showBackground: true,
    showImages: true,
    showDescription: true,
    showQrCode: true,
    langs: {
      zh: true,
      en: true,
      fr: true,
      ar: true,
      ma: true,
    },
  });

  const handlePrintMenu = () => {
    let html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Menu</title>
        <meta charset="utf-8">
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Noto+Kufi+Arabic:wght@400;700&display=swap');
          :root {
            --bg-url: ${printConfig.showBackground && bgUrl ? `url("${bgUrl}")` : "none"};
          }
          * { box-sizing: border-box; }
          body { 
            font-family: 'Inter', sans-serif; 
            color: #111; 
            padding: 40px; 
            max-width: 900px; 
            margin: 0 auto;
            position: relative;
            background-color: #fff;
          }
          .background-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background-image: var(--bg-url);
            background-size: cover;
            background-position: center;
            opacity: 0.15;
            z-index: -1;
            pointer-events: none;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .header { text-align: center; margin-bottom: 40px; }
          .logo { max-width: 150px; max-height: 150px; margin-bottom: 20px; border-radius: 10px; }
          h1 { text-align: center; border-bottom: 2px solid #333; padding-bottom: 15px; margin-bottom: 10px; font-weight: 700; font-size: 32px; text-transform: uppercase; letter-spacing: 2px; }
          .category { margin-top: 40px; break-inside: avoid; }
          .category-title-wrapper { border-bottom: 2px solid #e5e5e5; padding-bottom: 10px; margin-bottom: 20px; }
          .category-title { font-size: 24px; font-weight: bold; color: #000; display: flex; flex-wrap: wrap; align-items: center; gap: 10px; }
          .category-subtitle { font-size: 14px; color: #555; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; display: flex; flex-wrap: wrap; gap: 15px; margin-top: 6px; }
          
          .grid { display: grid; grid-template-columns: ${printConfig.layout === "list" ? "1fr" : "1fr 1fr"}; gap: 40px 30px; }
          .item { display: flex; margin-bottom: 20px; break-inside: avoid; }
          .item-image { width: 90px; height: 90px; object-fit: cover; border-radius: 8px; margin-right: 15px; flex-shrink: 0; }
          .item-content { flex: 1; display: flex; flex-direction: column; }
          .item-header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px dotted #ccc; padding-bottom: 6px; margin-bottom: 8px; }
          .item-name-group { display: flex; flex-direction: column; flex: 1; padding-right: 15px; gap: 3px; }
          .item-title-primary { font-weight: 700; font-size: 16px; color: #000; }
          .item-title-secondary { font-weight: 600; font-size: 14px; color: #333; }
          .item-title-tertiary { font-size: 14px; color: #444; font-family: 'Noto Kufi Arabic', sans-serif; text-align: left; }
          .item-desc-wrapper { display: ${printConfig.showDescription ? "flex" : "none"}; flex-direction: column; gap: 4px; }
          .item-desc { font-size: 12px; color: #555; line-height: 1.4; text-align: justify; }
          .item-desc.arabic { font-family: 'Noto Kufi Arabic', sans-serif; text-align: right; color: #555; font-size: 11px; }
          .item-price { font-weight: bold; font-size: 18px; white-space: nowrap; color: #000; margin-top: 2px; }
          
          @media print {
            body { padding: 0; }
            .grid { grid-template-columns: ${printConfig.layout === "list" ? "1fr" : "1fr 1fr"}; gap: 30px; }
            @page { margin: 1cm; size: A4; }
          }
        </style>
      </head>
      <body>
        <div class="background-overlay"></div>
        <div class="header">
          ${printConfig.showLogo && logoUrl ? `<img class="logo" src="${logoUrl}" alt="Logo" />` : ""}
          <h1>Menu</h1>
        </div>
    `;

    categories.forEach((cat) => {
      if (cat.items && cat.items.length > 0) {
        const titleLangs = [
          printConfig.langs.en ? cat.enName : "",
          printConfig.langs.fr ? cat.frName : "",
          printConfig.langs.ar ? cat.arName : "",
          printConfig.langs.ma ? cat.maName : "",
        ]
          .filter(Boolean)
          .filter((n) => n !== cat.name);

        html += `
          <div class="category">
            <div class="category-title-wrapper">
                <div class="category-title">${printConfig.langs.zh ? cat.name : titleLangs[0] || cat.name}</div>
                ${titleLangs.length > 0 && printConfig.langs.zh ? `<div class="category-subtitle"><span>${titleLangs.join("</span> • <span>")}</span></div>` : ""}
            </div>
            <div class="grid">
        `;
        cat.items.forEach((item: any) => {
          const mainTitle = printConfig.langs.zh
            ? item.title
            : printConfig.langs.en
              ? item.enTitle
              : printConfig.langs.fr
                ? item.frTitle
                : item.title;
          const subTitles = [
            printConfig.langs.en && mainTitle !== item.enTitle
              ? item.enTitle
              : "",
            printConfig.langs.fr && mainTitle !== item.frTitle
              ? item.frTitle
              : "",
          ]
            .filter(Boolean)
            .join(" / ");

          const arTitles = [
            printConfig.langs.ar ? item.arTitle : "",
            printConfig.langs.ma ? item.maTitle : "",
          ]
            .filter(Boolean)
            .filter((t) => t !== mainTitle)
            .join(" • ");

          const finalPrice = item.price.includes(" / ")
            ? item.price
            : `${item.price}`;

          html += `
            <div class="item">
              ${printConfig.showImages && item.image ? `<img src="${item.image}" class="item-image" />` : ""}
              <div class="item-content">
                <div class="item-header">
                  <div class="item-name-group">
                    <span class="item-title-primary">${mainTitle}</span>
                    ${subTitles ? `<span class="item-title-secondary">${subTitles}</span>` : ""}
                    ${arTitles ? `<span class="item-title-tertiary" dir="rtl" style="text-align: right;">${arTitles}</span>` : ""}
                  </div>
                  <span class="item-price">${finalPrice}</span>
                </div>
                <div class="item-desc-wrapper">
                  ${printConfig.langs.zh && item.description ? `<div class="item-desc">${item.description}</div>` : ""}
                  ${printConfig.langs.en && item.enDescription ? `<div class="item-desc">${item.enDescription}</div>` : ""}
                  ${printConfig.langs.fr && item.frDescription ? `<div class="item-desc">${item.frDescription}</div>` : ""}
                  ${printConfig.langs.ar && item.arDescription ? `<div class="item-desc arabic" dir="rtl">${item.arDescription}</div>` : ""}
                  ${printConfig.langs.ma && item.maDescription ? `<div class="item-desc arabic" dir="rtl">${item.maDescription}</div>` : ""}
                </div>
              </div>
            </div>
          `;
        });
        html += `
            </div>
          </div>
        `;
      }
    });

    html += `
        ${
          printConfig.showQrCode
            ? `
          <div style="margin-top: 60px; text-align: center;">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(window.location.origin)}" alt="Menu QR Code" style="width: 150px; height: 150px; display: block; margin: 0 auto; border-radius: 10px;" />
            <p style="margin-top: 15px; font-size: 14px; font-weight: bold; color: #555;">Scan to view online menu</p>
          </div>
        `
            : ""
        }
      </body>
      </html>
    `;

    // Use hidden offscreen iframe to print directly in current page
    const existingIframe = document.getElementById("print-menu-iframe");
    if (existingIframe && existingIframe.parentNode) {
      existingIframe.parentNode.removeChild(existingIframe);
    }

    const iframe = document.createElement("iframe");
    iframe.id = "print-menu-iframe";
    iframe.style.position = "absolute";
    iframe.style.top = "-9999px";
    iframe.style.left = "-9999px";
    iframe.style.width = "0px";
    iframe.style.height = "0px";
    iframe.style.border = "none";
    iframe.style.visibility = "hidden";
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document || iframe.contentDocument;
    if (doc) {
      doc.open();
      doc.write(html);
      doc.close();
    }

    setTimeout(() => {
      try {
        if (iframe.contentWindow) {
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        }
      } catch (e) {
        console.error("Print failed:", e);
        alert("打印失败，请重试");
      } finally {
        setTimeout(() => {
          if (document.body.contains(iframe)) {
            document.body.removeChild(iframe);
          }
        }, 3000);
      }
    }, 300);

    // Fallback cleanup
    setTimeout(() => {
      if (document.body.contains(iframe)) {
        document.body.removeChild(iframe);
      }
    }, 60000);
  };

  const handleChangePassword = (e: FormEvent) => {
    e.preventDefault();
    if (!newAdminPassword.trim()) return;
    if (setAdminPassword) {
      setAdminPassword(newAdminPassword);
      setNewAdminPassword("");
      if (onSaveToCloud) {
        onSaveToCloud({ adminPassword: newAdminPassword, silent: true });
        alert("密码修改成功并已同步到云端！ / Password changed and synced to cloud!");
      } else {
        alert("密码修改成功！请别忘了保存到云端。 / Password changed successfully!");
      }
    }
  };

  const handleChangeSecurity = (e: FormEvent) => {
    e.preventDefault();
    if (!newSecurityQuestion.trim() || !newSecurityAnswer.trim()) return;
    if (setSecurity) {
      setSecurity(newSecurityQuestion, newSecurityAnswer);
      if (onSaveToCloud) {
        onSaveToCloud({
          securityQuestion: newSecurityQuestion,
          securityAnswer: newSecurityAnswer,
          silent: true
        });
        alert("密保问题修改成功并已同步到云端！ / Security question changed and synced to cloud!");
      } else {
        alert("密保问题设置成功！/ Security question configured!");
      }
    }
  };

  const [localDevicePasswords, setLocalDevicePasswords] =
    useState<{ name: string; password: string }[]>(devicePasswords);

  useEffect(() => {
    setLocalDevicePasswords(devicePasswords);
  }, [devicePasswords]);

  const handleSaveDevicePasswords = (e: FormEvent) => {
    e.preventDefault();
    if (setDevicePasswords) {
      const updatedPasswords = localDevicePasswords.filter(
        (d) => d.name.trim() && d.password.trim(),
      );
      setDevicePasswords(updatedPasswords);
      if (onSaveToCloud) {
        onSaveToCloud({ devicePasswords: updatedPasswords, silent: true });
        alert(
          "服务员密码设置成功并已同步到云端！ / Waiter passwords saved and synced to cloud!",
        );
      } else {
        alert(
          "服务员密码设置成功！请别忘了保存到云端。/ Waiter passwords saved! Don't forget to save to cloud.",
        );
      }
    }
  };

  const handleAddDish = (e: FormEvent) => {
    e.preventDefault();
    if (!selectedCategory || !newDish.title || !newDish.image || !newDish.price)
      return;

    const finalPrice =
      currency && currency !== "none"
        ? `${newDish.price} ${currency}`
        : newDish.price;

    const updatedCategories = categories.map((cat) => {
      if (cat.id === selectedCategory) {
        return {
          ...cat,
          items: [
            ...cat.items,
            {
              ...newDish,
              price: finalPrice,
              stock: newDish.stock.trim() === "" ? null : Number(newDish.stock),
              id: Math.random().toString(36).substr(2, 9),
            },
          ],
        };
      }
      return cat;
    });

    setCategories(updatedCategories);
    // autosave disabled
    setNewDish({
      title: "",
      enTitle: "",
      frTitle: "",
      arTitle: "",
      maTitle: "",
      description: "",
      enDescription: "",
      frDescription: "",
      arDescription: "",
      maDescription: "",
      price: "",
      image: "",
      allergens: [] as string[],
      stock: "",
    });
    alert("菜品添加成功！ Dish added successfully!");
  };

  const rawDiscountNum = parseFloat(checkoutDiscountStr) || 0;
  let parsedDiscount = 0;
  if (checkoutDiscountMode === "rate") {
    let rate = rawDiscountNum;
    if (rate > 10 && rate <= 100) rate = rate / 10;
    if (rate > 0 && rate < 10) {
      const total = checkoutOrder?.total || 0;
      parsedDiscount = total * (1 - rate / 10);
    } else if (rate === 10 || rate === 0) {
      parsedDiscount = 0;
    }
  } else {
    parsedDiscount = rawDiscountNum;
  }
  const parsedReceived = parseFloat(checkoutReceivedStr) || 0;

  const handleNumpadInput = (key: string) => {
    const setState =
      activeNumpadField === "discount"
        ? setCheckoutDiscountStr
        : setCheckoutReceivedStr;

    setState((prev) => {
      if (key === "C") return "0";
      if (key === "⌫") return prev.length > 1 ? prev.slice(0, -1) : "0";

      if (key === ".") {
        if (prev.includes(".")) return prev;
        return prev + ".";
      }

      return prev === "0" && key !== "." ? key : prev + key;
    });
  };

  const numpadKeys = [
    "7",
    "8",
    "9",
    "4",
    "5",
    "6",
    "1",
    "2",
    "3",
    "0",
    ".",
    "⌫",
    "C",
  ];

  const downloadTableCard = (tableNo: string, storeName: string) => {
    const qrCanvas = document.getElementById(`qr-${tableNo}`) as HTMLCanvasElement;
    if (!qrCanvas) return;

    const canvas = document.createElement("canvas");
    canvas.width = 1000;
    canvas.height = 1500;
    
    drawBeautifulTableCard(canvas, qrCanvas, tableNo, storeName);

    const url = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = `Table-${tableNo}-Card.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm sm:p-4 font-sans">
      <div className="bg-zinc-900 border-zinc-800 sm:border rounded-none sm:rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl relative flex flex-col h-[100dvh] sm:h-[90vh]">
        {/* Notifications Overlay */}
        {notifications.length > 0 && (
          <div className="absolute top-10 left-1/2 -translate-x-1/2 z-[200] flex flex-col gap-3 pointer-events-none w-[90%] sm:w-[500px]">
            {notifications.map((notif) => (
              <div key={notif.id} className="bg-orange-600/95 backdrop-blur-xl text-white px-6 py-4 rounded-2xl shadow-[0_10px_40px_rgba(249,115,22,0.6)] border-2 border-orange-400 flex items-center gap-4 font-bold animate-in slide-in-from-top-10 fade-in duration-300">
                <div className="w-3 h-3 rounded-full bg-white animate-pulse shadow-[0_0_10px_white]" />
                <span className="text-base md:text-lg tracking-wide">{notif.message}</span>
              </div>
            ))}
          </div>
        )}

        <div className="absolute top-4 right-14 flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-950/50 border border-zinc-800 pointer-events-none z-10 hidden sm:flex">
          <div
            className={`w-2 h-2 rounded-full ${isSynced ? "bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]" : "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]"}`}
          />
          <span className="text-[10px] text-zinc-400 font-medium tracking-wide">
            {isSynced
              ? isCloudConnected
                ? "EDGEONE SYNCED"
                : "CLOUD SYNCED"
              : "OFFLINE"}
          </span>
        </div>
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-zinc-400 hover:text-white bg-black/20 hover:bg-black/40 p-2 rounded-full transition-colors z-20 custom-cursor-pointer"
        >
          <X size={20} />
        </button>

        {!isAuthed ? (
          isForgotMode ? (
            <form
              onSubmit={handleVerifySecurity}
              className="p-8 flex flex-col items-center flex-1 justify-center"
            >
              <div className="w-16 h-16 bg-orange-600/20 text-orange-500 rounded-full flex items-center justify-center mb-6">
                <Shield size={32} />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">
                安全问题验证
              </h2>
              <p className="text-sm text-zinc-400 mb-8">{securityQuestion}</p>
              <input
                type="text"
                value={verifyAnswer}
                onChange={(e) => {
                  setVerifyAnswer(e.target.value);
                  setError("");
                }}
                placeholder="输入答案 / Enter Answer"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-orange-500 transition-colors mb-4"
                autoFocus
              />
              {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
              <button
                type="submit"
                className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl px-4 py-3 transition-colors mb-4"
              >
                验证并解锁
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsForgotMode(false);
                  setError("");
                }}
                className="text-sm text-zinc-400 hover:text-white transition-colors"
              >
                返回密码登录
              </button>
            </form>
          ) : (
            <form
              onSubmit={handleLogin}
              className="p-8 flex flex-col items-center flex-1 justify-center"
            >
              <div className="w-16 h-16 bg-orange-600/20 text-orange-500 rounded-full flex items-center justify-center mb-6">
                <Lock size={32} />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">身份验证</h2>
              <p className="text-sm text-zinc-400 mb-6 text-center">
                请输入管理员密码进入后台
                <br />
                或输入服务员密码以解锁点单
              </p>

              {currentWaiter && (
                <div className="w-full bg-green-500/10 border border-green-500/20 rounded-xl p-4 flex items-center justify-between mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-500/20 rounded-full flex items-center justify-center text-green-500">
                      <User size={20} />
                    </div>
                    <div className="text-left">
                      <p className="text-green-400 text-sm font-bold">
                        已登录服务员
                      </p>
                      <p className="text-zinc-300 text-sm">
                        {currentWaiter.name}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      localStorage.removeItem("deviceAuthToken");
                      localStorage.removeItem("deviceAuthTokenExpiry");
                      setCurrentWaiter(null);
                      alert("已退出服务员登录");
                      window.location.reload();
                    }}
                    className="text-xs bg-zinc-800 hover:bg-zinc-700 text-white px-3 py-2 rounded-lg transition-colors border border-zinc-700 cursor-pointer"
                  >
                    退出
                  </button>
                </div>
              )}

              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError("");
                }}
                placeholder="Enter Password"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-orange-500 transition-colors mb-4"
                autoFocus
              />
              {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
              <button
                type="submit"
                className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl px-4 py-3 transition-colors mb-4"
              >
                解锁 / Unlock
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!securityQuestion || !securityAnswer) {
                    setError(
                      "未配置安全问题，无法找回密码。请联系超级管理员重置数据。",
                    );
                  } else {
                    setIsForgotMode(true);
                    setError("");
                  }
                }}
                className="text-sm text-zinc-400 hover:text-white transition-colors"
              >
                忘记密码？ (Forgot Password?)
              </button>
            </form>
          )
        ) : (
          <div className="flex flex-col flex-1 min-h-0 h-full overflow-hidden">
            <div className="p-4 sm:p-6 pb-0 shrink-0">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-4 pr-8">
                <h2 className="text-xl sm:text-2xl font-bold text-white">
                  设置控制面板
                </h2>
                {onSaveToCloud && (
                  <button
                    onClick={onSaveToCloud}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded-xl transition-colors shrink-0"
                  >
                    <Database size={16} />
                    保存到云端 (Save to Cloud)
                  </button>
                )}
              </div>

              <div 
                onWheel={(e) => { if (e.deltaY !== 0) e.currentTarget.scrollLeft += e.deltaY; }}
                className="flex overflow-x-auto space-x-2 border-b border-zinc-800 pb-2 custom-scrollbar pr-8 hide-scrollbar cursor-grab active:cursor-grabbing"
              >
                <button
                  onClick={() => setActiveTab("orders")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === "orders" ? "bg-orange-600 text-white" : "bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                >
                  <ShoppingBag size={16} />
                  订单记录
                </button>
                <button
                  onClick={() => setActiveTab("menu")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === "menu" ? "bg-orange-600 text-white" : "bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                >
                  <LayoutList size={16} />
                  菜单管理
                </button>
                <button
                  onClick={() => setActiveTab("promotions")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === "promotions" ? "bg-orange-600 text-white" : "bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                >
                  <Flame size={16} />
                  活动管理
                </button>
                <button
                  onClick={() => setActiveTab("appearance")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === "appearance" ? "bg-orange-600 text-white" : "bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                >
                  <Palette size={16} />
                  外观设置
                </button>
                <button
                  onClick={() => setActiveTab("tools")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === "tools" ? "bg-orange-600 text-white" : "bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                >
                  <Wrench size={16} />
                  实用工具
                </button>
                <button
                  onClick={() => setActiveTab("qr")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === "qr" ? "bg-orange-600 text-white" : "bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                >
                  <Scan size={16} />
                  扫码点餐
                </button>
                <button
                  onClick={() => setActiveTab("printer")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === "printer" ? "bg-orange-600 text-white" : "bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                >
                  <Printer size={16} />
                  打印机设置
                </button>
                <button
                  onClick={() => setActiveTab("security")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === "security" ? "bg-orange-600 text-white" : "bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                >
                  <Shield size={16} />
                  账户安全
                </button>
                <button
                  onClick={() => setActiveTab("database")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === "database" ? "bg-orange-600 text-white" : "bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                >
                  <Database size={16} />
                  数据与备份 (Database)
                </button>
                <button
                  onClick={() => setActiveTab("inventory")}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap ${activeTab === "inventory" ? "bg-orange-600 text-white" : "bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                >
                  <Boxes size={16} />
                  库存与BOM联控
                </button>
              </div>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto custom-scrollbar flex-1 min-h-0 pb-16">
              {activeTab === "orders" && (
                <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                  <div className="flex items-center justify-between mb-4 flex-wrap gap-4">
                    <div className="flex bg-zinc-900 rounded-xl p-1 border border-zinc-800">
                      <button
                        onClick={() => setOrderView("active")}
                        className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${orderView === "active" ? "bg-orange-600 text-white" : "text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                      >
                        活跃订单 (Active)
                      </button>
                      <button
                        onClick={() => setOrderView("history")}
                        className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${orderView === "history" ? "bg-orange-600 text-white" : "text-zinc-400 hover:text-white hover:bg-zinc-800"}`}
                      >
                        历史订单 (History)
                      </button>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={handleSimulateExternalOrder}
                        className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold text-orange-500 bg-orange-500/10 hover:bg-orange-500/20 rounded-lg transition-colors border border-orange-500/20"
                      >
                        <Sparkles size={16} />
                        模拟外部订单
                      </button>
                      {orders.filter(o => orderView === "history" ? o.status === "completed" : o.status !== "completed").length > 0 && (
                        <button
                          onClick={() => {
                            const statusToClear = orderView === "history" ? "completed" : "pending";
                            setConfirmDialog({
                              isOpen: true,
                              message:
                                `确定要清空${orderView === "history" ? "历史" : "活跃"}订单记录吗？\n(Are you sure you want to clear ${orderView === "history" ? "historical" : "active"} orders?)`,
                              onConfirm: async () => {
                                try {
                                  await api.clearOrders(statusToClear);
                                } catch (e) {
                                  console.error("Failed to delete orders:", e);
                                }
                                setConfirmDialog(null);
                              },
                            });
                          }}
                          className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold text-red-500 bg-red-500/10 hover:bg-red-500/20 rounded-lg transition-colors border border-red-500/20"
                        >
                          <Trash2 size={16} />
                          清空记录 (Clear)
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="space-y-4">
                    {orders.filter(o => orderView === "history" ? o.status === "completed" : o.status !== "completed").length === 0 ? (
                      <p className="text-zinc-500 text-center py-8">
                        暂无订单记录 (No orders yet)
                      </p>
                    ) : (
                      orders.filter(o => orderView === "history" ? o.status === "completed" : o.status !== "completed").map((order, idx) =>
                        order ? (
                          <div
                            key={idx}
                            className="bg-zinc-900 border border-zinc-800 rounded-xl p-4"
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <span className="text-orange-400 font-bold text-lg">
                                  桌号/顾客名 (Table/Name):{" "}
                                  {order?.customerName || "未填写"}
                                </span>
                                {order?.deviceName && (
                                  <div className="text-zinc-500 text-sm mt-1">
                                    设备 (Device): {order.deviceName}
                                  </div>
                                )}
                                <div className="text-zinc-400 text-xs mt-1">
                                  时间:{" "}
                                  {order?.timestamp
                                    ? (() => {
                                        try {
                                          const d = new Date(order.timestamp);
                                          if (isNaN(d.getTime()))
                                            return String(order.timestamp);
                                          return d.toLocaleString("zh-CN");
                                        } catch (e) {
                                          return String(order.timestamp);
                                        }
                                      })()
                                    : ""}
                                </div>
                                <div className="text-zinc-500 text-xs mt-1">
                                  单号: {order?.orderNumber || "N/A"}
                                </div>
                                {order?.deviceInfo && (
                                  <div className="text-blue-400 text-xs mt-1">
                                    设备 (Device): {order.deviceInfo}
                                  </div>
                                )}
                                {order?.isExternal && (
                                  <div className="text-orange-500 text-xs mt-1">
                                    来自外部网站 (External Web)
                                  </div>
                                )}
                              </div>
                              <div className="flex flex-col items-end gap-2">
                                <div className="flex items-center gap-2">
                                  {order?.status === "completed" && (
                                    <>
                                    <span className="text-xs px-2 py-1 bg-green-500/20 text-green-500 rounded font-bold">
                                      已结账 (Completed)
                                    </span>
                                    {order?.paymentMethod && (
                                      <span className="text-[11px] text-orange-400 font-semibold bg-orange-500/10 border border-orange-500/30 px-1.5 py-0.5 rounded">
                                        💳 {order.paymentMethod}
                                      </span>
                                    )}
                                    </>
                                  )}
                                  {order?.status === "served" && (
                                    <span className="text-xs px-2 py-1 bg-teal-500/20 text-teal-500 rounded font-bold">
                                      已上菜 (Served)
                                    </span>
                                  )}
                                  {order?.status === "preparing" && (
                                    <span className="text-xs px-2 py-1 bg-blue-500/20 text-blue-500 rounded font-bold">
                                      制作中 (Preparing)
                                    </span>
                                  )}
                                  {(!order?.status ||
                                    order?.status === "pending") && (
                                    <span className="text-xs px-2 py-1 bg-orange-500/20 text-orange-500 rounded font-bold">
                                      待接单 (Pending)
                                    </span>
                                  )}
                                  <div className="text-white font-bold text-lg">
                                    {order?.total || ""}
                                  </div>
                                </div>
                                <div className="flex flex-wrap items-center justify-end gap-2 mt-1">
                                  {order?.status !== "completed" && (
                                    <>
                                      {(!order?.status || order?.status === "pending") && (
                                        <button
                                          onClick={async () => {
                                            try {
                                              await api.updateOrderStatus(order._id, "preparing");
                                            } catch (e) {
                                              alert("操作失败 (Failed to update status)");
                                            }
                                          }}
                                          className="flex items-center gap-1 text-xs px-2 py-1 bg-blue-600 hover:bg-blue-500 rounded text-white transition-colors"
                                        >
                                          接单 (Accept)
                                        </button>
                                      )}
                                      {order?.status === "preparing" && (
                                        <button
                                          onClick={async () => {
                                            try {
                                              await api.updateOrderStatus(order._id, "served");
                                            } catch (e) {
                                              alert("操作失败 (Failed to update status)");
                                            }
                                          }}
                                          className="flex items-center gap-1 text-xs px-2 py-1 bg-teal-600 hover:bg-teal-500 rounded text-white transition-colors"
                                        >
                                          上菜 (Serve)
                                        </button>
                                      )}
                                      <button
                                        onClick={async () => {
                                          let currentTable =
                                            order?.customerName || "";
                                          if (
                                            currentTable.startsWith("桌号_")
                                          ) {
                                            currentTable = currentTable.replace(
                                              "桌号_",
                                              "",
                                            );
                                          }
                                          const newTable = prompt(
                                            "请输入新的桌号 (Enter new table number):",
                                            currentTable,
                                          );
                                          if (
                                            newTable &&
                                            newTable.trim() &&
                                            newTable.trim() !== currentTable
                                          ) {
                                            try {
                                              await api.updateOrder(order._id, {
                                                customerName: `桌号_${newTable.trim()}`,
                                              });
                                            } catch (e) {
                                              alert(
                                                "修改失败 (Failed to update table)",
                                              );
                                            }
                                          }
                                        }}
                                        className="flex items-center gap-1 text-xs px-2 py-1 bg-zinc-700 hover:bg-zinc-600 rounded text-white transition-colors"
                                      >
                                        <Edit2 size={14} /> 换台 (Change Table)
                                      </button>
                                      <button
                                        onClick={() => {
                                          setCheckoutOrder(order);
                                          setCheckoutPaymentMethod(order?.paymentMethod || "微信支付");
                                          setCheckoutDiscountStr("0");
                                          setCheckoutDiscountMode("amount");
                                          setCheckoutReceivedStr(
                                            String(order.total || 0),
                                          );
                                          setActiveNumpadField("received");
                                        }}
                                        className="flex items-center gap-1 text-xs px-2 py-1 bg-green-600 hover:bg-green-500 rounded text-white transition-colors"
                                      >
                                        <CheckCircle size={14} /> 结账
                                        (Complete)
                                      </button>
                                    </>
                                  )}
                                  <button
                                    onClick={() => {
                                      import("../lib/print").then((m) =>
                                        m.printReceipt(
                                          order,
                                          currency,
                                          receiptSettings,
                                          true, // isKitchenTicket
                                        ),
                                      );
                                    }}
                                    className="flex items-center gap-1 text-xs px-2 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-zinc-300 transition-colors"
                                  >
                                    <Printer size={14} /> 厨房做菜单
                                  </button>
                                  <button
                                    onClick={() => {
                                      import("../lib/print").then((m) =>
                                        m.printReceipt(
                                          order,
                                          currency,
                                          receiptSettings,
                                        ),
                                      );
                                    }}
                                    className="flex items-center gap-1 text-xs px-2 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-zinc-300 transition-colors"
                                  >
                                    <Printer size={14} /> 打印小票
                                  </button>
                                  {order?.items?.some((item: any) => item.isAdded) && (
                                    <button
                                      onClick={() => {
                                        import("../lib/print").then((m) => {
                                          const additionsOrder = { ...order, items: order.items.filter((i: any) => i.isAdded) };
                                          m.printReceipt(
                                            additionsOrder,
                                            currency,
                                            receiptSettings,
                                            false,
                                            "addition"
                                          );
                                        });
                                      }}
                                      className="flex items-center gap-1 text-xs px-2 py-1 bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/30 rounded text-orange-500 transition-colors"
                                    >
                                      <Printer size={14} /> 打印加菜单
                                    </button>
                                  )}
                                  <button
                                    onClick={() => {
                                      setConfirmDialog({
                                        isOpen: true,
                                        message: "确定要删除此订单吗？ (Are you sure you want to delete this order?)",
                                        onConfirm: async () => {
                                          try {
                                            await api.deleteOrder(order._id);
                                          } catch (e) {
                                            console.error("Failed to delete order", e);
                                          }
                                          setConfirmDialog(null);
                                        }
                                      });
                                    }}
                                    className="flex items-center gap-1 text-xs px-2 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded transition-colors"
                                  >
                                    <Trash2 size={14} /> 删除
                                  </button>
                                </div>
                              </div>
                            </div>
                            {order?.status !== "completed" && (
                              <ul className="space-y-2 mt-3 pt-3 border-t border-zinc-800/50">
                                {order?.items?.map((item: any, i: number) =>
                                  item ? (
                                    <li
                                      key={i}
                                      className={`flex justify-between items-center text-sm p-2 rounded ${item.served ? "bg-green-500/10 text-green-500/70 line-through" : item.isAdded ? "bg-orange-500/10 border border-orange-500/20" : "bg-zinc-900"}`}
                                    >
                                      <div className="flex items-center gap-2">
                                        <button
                                          onClick={async () => {
                                            const newItems = [...order.items];
                                            newItems[i] = {
                                              ...item,
                                              served: !item.served,
                                            };
                                            try {
                                              await api.updateOrder(order._id, {
                                                items: newItems,
                                              });
                                            } catch (e) {
                                              console.error(
                                                "Failed to update item status:",
                                                e,
                                              );
                                            }
                                          }}
                                          className={`p-1 rounded-full border ${item.served ? "bg-green-500 text-white border-green-500" : "border-zinc-500 text-transparent hover:border-zinc-300"}`}
                                        >
                                          <CheckCircle size={14} />
                                        </button>
                                        <span
                                          className={
                                            item.served
                                              ? "text-green-500/70"
                                              : item.isAdded
                                                ? "text-orange-400 font-medium"
                                                : "text-zinc-300"
                                          }
                                        >
                                          {item?.name || ""}
                                          {item?.isAdded && !item.served ? <span className="ml-2 text-[10px] px-1.5 py-0.5 bg-orange-500/20 text-orange-500 rounded-sm">加菜</span> : ""}
                                          {item?.isAdded && item.served ? " (加菜)" : ""}
                                        </span>
                                      </div>
                                      <div className="flex items-center gap-3">
                                        {(!order?.status ||
                                          order?.status === "pending") && (
                                          <button
                                            onClick={async () => {
                                              if (
                                                confirm(
                                                  `确定要退掉一个 ${item?.name || ""} 吗？(Refund one item?)`,
                                                )
                                              ) {
                                                const newItems = [
                                                  ...order.items,
                                                ];
                                                const currentItem = newItems[i];
                                                let newTotal =
                                                  (order.total || 0) -
                                                  (currentItem?.price || 0);
                                                if (newTotal < 0) newTotal = 0;

                                                if (currentItem.quantity > 1) {
                                                  newItems[i] = {
                                                    ...currentItem,
                                                    quantity:
                                                      currentItem.quantity - 1,
                                                  };
                                                } else {
                                                  newItems.splice(i, 1);
                                                }

                                                try {
                                                  await api.updateOrder(
                                                    order._id,
                                                    {
                                                      items: newItems,
                                                      total: newTotal,
                                                    },
                                                  );
                                                } catch (e) {
                                                  alert(
                                                    "退菜失败 (Failed to refund)",
                                                  );
                                                }
                                              }
                                            }}
                                            className="text-xs text-red-500 hover:text-red-400 p-1 rounded hover:bg-red-500/10 transition-colors whitespace-nowrap"
                                          >
                                            退菜
                                          </button>
                                        )}
                                        <span
                                          className={
                                            item.served
                                              ? "text-green-500/70"
                                              : "text-zinc-500"
                                          }
                                        >
                                          x{item?.quantity || 1}
                                        </span>
                                        <span
                                          className={`${item.served ? "text-green-500/70" : "text-zinc-400"} w-12 text-right`}
                                        >
                                          {(item?.price || 0) *
                                            (item?.quantity || 1)}
                                        </span>
                                      </div>
                                    </li>
                                  ) : null,
                                )}
                              </ul>
                            )}
                          </div>
                        ) : null,
                      )
                    )}
                  </div>
                </div>
              )}
              {activeTab === "tools" && (
                <>
                  {/* API Settings */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <h3 className="text-lg font-semibold text-white mb-2 flex items-center gap-2">
                      <Key size={20} className="text-orange-500" /> API 设置
                      (用于 AI 翻译 / 完善图片)
                    </h3>
                    <input
                      type="password"
                      value={apiKey}
                      onChange={handleApiKeyChange}
                      placeholder="在此输入您的 Gemini API Key"
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
                    />
                    <p className="text-[10px] text-zinc-500 mt-2">
                      API Key 仅本地保存在您的浏览器中。用于一键进行多语言翻译和
                      AI 图片美化增强功能。
                    </p>
                  </div>
                </>
              )}
              {activeTab === "appearance" && (
                <>
                  {/* Layout Settings */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                      <Layout size={20} className="text-orange-500" />
                      菜单布局样式 / Layout Style
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        onClick={() => setLayoutStyle && setLayoutStyle("grid")}
                        className={`flex flex-col items-center justify-center p-4 rounded-xl border ${layoutStyle === "grid" ? "border-orange-500 bg-orange-500/10 text-orange-500" : "border-zinc-800 bg-zinc-900 text-zinc-400 hover:border-zinc-600"} transition-colors gap-2`}
                      >
                        <div className="w-16 h-12 bg-zinc-800 rounded flex flex-col gap-1 p-1">
                          <div className="w-full h-1/2 bg-zinc-700 rounded-sm"></div>
                          <div className="w-full h-1/4 bg-zinc-600 rounded-sm"></div>
                          <div className="w-1/2 h-1/4 bg-zinc-600 rounded-sm"></div>
                        </div>
                        <span className="text-sm font-semibold mt-1">
                          经典网格 (Grid)
                        </span>
                      </button>
                      <button
                        onClick={() => setLayoutStyle && setLayoutStyle("list")}
                        className={`flex flex-col items-center justify-center p-4 rounded-xl border ${layoutStyle === "list" ? "border-orange-500 bg-orange-500/10 text-orange-500" : "border-zinc-800 bg-zinc-900 text-zinc-400 hover:border-zinc-600"} transition-colors gap-2`}
                      >
                        <div className="w-16 h-12 bg-zinc-800 rounded flex gap-1 p-1">
                          <div className="w-1/3 h-full bg-zinc-700 rounded-sm"></div>
                          <div className="flex-1 flex flex-col gap-1">
                            <div className="w-full h-1/3 bg-zinc-600 rounded-sm"></div>
                            <div className="w-2/3 h-1/3 bg-zinc-600 rounded-sm"></div>
                          </div>
                        </div>
                        <span className="text-sm font-semibold mt-1">
                          优雅列表 (List)
                        </span>
                      </button>
                      <button
                        onClick={() =>
                          setLayoutStyle && setLayoutStyle("bento")
                        }
                        className={`flex flex-col items-center justify-center p-4 rounded-xl border ${layoutStyle === "bento" ? "border-orange-500 bg-orange-500/10 text-orange-500" : "border-zinc-800 bg-zinc-900 text-zinc-400 hover:border-zinc-600"} transition-colors gap-2`}
                      >
                        <div className="w-16 h-12 bg-zinc-800 rounded grid grid-cols-2 grid-rows-2 gap-1 p-1">
                          <div className="col-span-2 row-span-1 bg-zinc-700 rounded-sm"></div>
                          <div className="col-span-1 border border-zinc-700 rounded-sm"></div>
                          <div className="col-span-1 border border-zinc-700 rounded-sm"></div>
                        </div>
                        <span className="text-sm font-semibold mt-1">
                          便当网格 (Bento)
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Theme Settings */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                      <Palette size={20} className="text-orange-500" />
                      界面主题 / Theme Mode
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <button
                        onClick={() => setTheme && setTheme("midnight")}
                        className={`flex flex-col items-center justify-center p-4 rounded-xl border ${theme === "midnight" ? "border-orange-500 bg-orange-500/10 text-orange-500" : "border-zinc-800 bg-zinc-900 text-zinc-400 hover:border-zinc-600"} transition-colors gap-2`}
                      >
                        <Moon
                          size={24}
                          className={
                            theme === "midnight"
                              ? "text-orange-500"
                              : "text-zinc-500"
                          }
                        />
                        <span className="text-sm font-semibold mt-1">
                          暗夜黑 (Midnight)
                        </span>
                      </button>
                      <button
                        onClick={() => setTheme && setTheme("light")}
                        className={`flex flex-col items-center justify-center p-4 rounded-xl border ${theme === "light" ? "border-orange-500 bg-orange-500/10 text-orange-500" : "border-zinc-800 bg-zinc-900 text-zinc-400 hover:border-zinc-600"} transition-colors gap-2`}
                      >
                        <Sun
                          size={24}
                          className={
                            theme === "light"
                              ? "text-orange-500"
                              : "text-zinc-500"
                          }
                        />
                        <span className="text-sm font-semibold mt-1">
                          明亮白 (Light)
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Sound Settings */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1 flex items-center gap-2">
                        {soundEnabled ? (
                          <Volume2 size={20} className="text-orange-500" />
                        ) : (
                          <VolumeX size={20} className="text-zinc-500" />
                        )}
                        翻页音效
                      </h3>
                      <p className="text-xs text-zinc-400">
                        开启或关闭菜单页面切换时的高级音效
                      </p>
                    </div>
                    <button
                      onClick={() =>
                        setSoundEnabled && setSoundEnabled(!soundEnabled)
                      }
                      className={`w-14 h-8 rounded-full p-1 transition-colors relative flex items-center ${soundEnabled ? "bg-orange-500" : "bg-zinc-700"}`}
                    >
                      <div
                        className={`w-6 h-6 bg-white rounded-full transition-transform duration-300 shadow-md ${soundEnabled ? "translate-x-6" : "translate-x-0"}`}
                      />
                    </button>
                  </div>
                </>
              )}
              {activeTab === "tools" && (
                <>
                  {/* Currency Settings */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50 flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1 flex items-center gap-2">
                        <CircleDollarSign
                          size={20}
                          className="text-orange-500"
                        />{" "}
                        全局货币单位 / Global Currency
                      </h3>
                      <p className="text-xs text-zinc-400">
                        一键替换所有菜品价格显示的货币符号。(注意：不会转换汇率数值)
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => handleGlobalCurrencyChange("MAD")}
                        className="bg-zinc-800 hover:bg-orange-600 text-white text-xs font-bold rounded-lg px-3 py-2 transition-colors border border-zinc-700 hover:border-orange-500"
                      >
                        设为 MAD 迪拉姆
                      </button>
                      <button
                        type="button"
                        onClick={() => handleGlobalCurrencyChange("¥")}
                        className="bg-zinc-800 hover:bg-orange-600 text-white text-xs font-bold rounded-lg px-3 py-2 transition-colors border border-zinc-700 hover:border-orange-500"
                      >
                        设为 CNY 人民币
                      </button>
                      <button
                        type="button"
                        onClick={() => handleGlobalCurrencyChange("€")}
                        className="bg-zinc-800 hover:bg-orange-600 text-white text-xs font-bold rounded-lg px-3 py-2 transition-colors border border-zinc-700 hover:border-orange-500"
                      >
                        设为 EUR 欧元
                      </button>
                      <button
                        type="button"
                        onClick={() => handleGlobalCurrencyChange("$")}
                        className="bg-zinc-800 hover:bg-orange-600 text-white text-xs font-bold rounded-lg px-3 py-2 transition-colors border border-zinc-700 hover:border-orange-500"
                      >
                        设为 USD 美元
                      </button>
                    </div>
                  </div>
                </>
              )}
              {activeTab === "appearance" && (
                <>
                  {/* Fullscreen Action */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1 flex items-center gap-2">
                        <Maximize size={20} className="text-orange-500" />{" "}
                        全屏模式 / Fullscreen
                      </h3>
                      <p className="text-xs text-zinc-400">
                        切换浏览器全屏模式以获得沉浸式体验 / Toggle fullscreen
                        mode
                      </p>
                    </div>
                    <button
                      onClick={handleFullscreenToggle}
                      className="bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl px-4 py-2.5 transition-colors text-sm border border-zinc-700 flex items-center gap-2 max-w-fit"
                    >
                      <Maximize size={16} /> 切换全屏 / Toggle
                    </button>
                  </div>
                </>
              )}
              {activeTab === "qr" && (
                <div className="space-y-6">
                  {/* Create Table QR Code */}
                  <div className="p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <QrCode size={20} className="text-orange-500" />{" "}
                      管理桌台二维码 (Manage Table QR Codes)
                    </h3>
                    <div className="flex gap-4">
                      <input
                        type="text"
                        placeholder="输入桌号 (Enter Table Number)"
                        className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-orange-500 transition-colors"
                        id="qr-table-input"
                      />
                      <button
                        onClick={async () => {
                          const input = document.getElementById(
                            "qr-table-input",
                          ) as HTMLInputElement;
                          let tableNo = input.value.trim();
                          if (!tableNo) {
                            alert("请输入桌号 (Please enter a table number)");
                            return;
                          }
                          tableNo = tableNo.replace(/\//g, "-");
                          try {
                            const existing = await api.getTableQr(tableNo);
                            if (existing) {
                              alert("该桌台已存在 (Table already exists)");
                              return;
                            }
                            await api.createTableQr(tableNo);
                            input.value = "";
                            alert("添加成功 (Added successfully)");
                          } catch (e) {
                            alert("添加失败 (Failed to add)");
                          }
                        }}
                        className="px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl transition-colors whitespace-nowrap"
                      >
                        添加桌台 (Add Table)
                      </button>
                    </div>
                  </div>

                  {/* Active Tables */}
                  <div className="p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <List size={20} className="text-orange-500" /> 所有桌台
                      (All Tables)
                    </h3>
                    {tables.length === 0 ? (
                      <p className="text-zinc-500 text-center py-8">
                        暂无桌台 (No tables available)
                      </p>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {tables.map((table) => (
                          <div
                            key={table.tableNo}
                            className={`bg-zinc-900 border ${table.active ? "border-orange-500/50" : "border-zinc-800"} rounded-xl p-4 flex flex-col items-center transition-colors`}
                          >
                            <div className="w-full flex justify-between items-start mb-4">
                              <div>
                                <span className="text-lg font-bold text-white">
                                  桌号: {table.tableNo}
                                </span>
                                <div
                                  className={`text-xs ${table.active ? "text-green-500" : "text-zinc-500"}`}
                                >
                                  {table.active
                                    ? "已开台 (Opened)"
                                    : "未开台 (Closed)"}
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <button
                                  onClick={async () => {
                                    await api.updateTableStatus(
                                      table.tableNo,
                                      !table.active,
                                    );
                                  }}
                                  className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors ${table.active ? "bg-zinc-800 text-zinc-400 hover:text-white" : "bg-orange-600 text-white hover:bg-orange-500"}`}
                                >
                                  {table.active
                                    ? "清台 (Close)"
                                    : "开台 (Open)"}
                                </button>
                                <button
                                  onClick={async () => {
                                    if (
                                      confirm(
                                        `确定要删除桌台 ${table.tableNo} 吗？(Delete table?)`,
                                      )
                                    ) {
                                      await api.deleteTableQr(table.tableNo);
                                    }
                                  }}
                                  className="text-red-500 hover:text-red-400 p-2 rounded-lg hover:bg-zinc-800 transition-colors"
                                  title="删除 (Delete)"
                                >
                                  <X size={16} />
                                </button>
                              </div>
                            </div>
                            <div className="p-4 bg-white rounded-xl mb-4 w-fit opacity-100 hover:opacity-100 transition-opacity border-4 border-zinc-100 shadow-sm relative overflow-hidden">
                              {/* Decorative corners */}
                              <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-orange-500 rounded-tl-xl"></div>
                              <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-orange-500 rounded-tr-xl"></div>
                              <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-orange-500 rounded-bl-xl"></div>
                              <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-orange-500 rounded-br-xl"></div>
                              <div className="p-2">
                                <QRCodeCanvas
                                  id={`qr-${table.tableNo}`}
                                  value={`${window.location.origin}${window.location.pathname}?table=${table.tableNo}&key=${table.key}`}
                                  size={150}
                                  level={receiptSettings?.qrCodeLevel || "H"}
                                  fgColor={receiptSettings?.qrCodeFgColor || "#18181b"}
                                  bgColor={receiptSettings?.qrCodeBgColor || "#ffffff"}
                                  imageSettings={{
                                    src: receiptSettings?.topLogoUrl || "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZjU5ZTBiIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0iTTMgMnY3YzAgMS4xLjkgMiAyIDJoNGEyIDIgMCAwIDAgMi0yVjIiLz48cGF0aCBkPSJNNyAydjIwIi8+PHBhdGggZD0iTTIxIDE1VjJ2MGE1IDUgMCAwIDAtNSA1djZjMCAxLjEuOSAyIDIgMmgzWm0wIDB2NyIvPjwvc3ZnPg==",
                                    height: 36,
                                    width: 36,
                                    excavate: true,
                                  }}
                                />
                              </div>
                            </div>
                            <div className="text-xs text-zinc-500 text-center mb-3">
                              可打印此二维码贴在桌子上
                              <br />
                              (Print and stick to table)
                            </div>
                            <div className="flex gap-2 w-full">
                              <button
                                onClick={() => {
                                  const url = `${window.location.origin}${window.location.pathname}?table=${table.tableNo}&key=${table.key}`;
                                  navigator.clipboard.writeText(url);
                                  alert("链接已复制 (Link copied)");
                                }}
                                className="flex-1 py-1.5 text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg transition-colors"
                              >
                                复制链接
                              </button>
                              <button
                                onClick={() => {
                                  downloadTableCard(table.tableNo, receiptSettings.storeName);
                                }}
                                className="flex-1 py-1.5 text-xs bg-orange-600 hover:bg-orange-500 text-white font-semibold rounded-lg transition-colors flex items-center justify-center gap-1 shadow-lg"
                              >
                                <Download size={12} />
                                下载桌牌 (Download Card)
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
              {activeTab === "printer" && (
                <>
                  {/* Print Menu Action */}
                  <div className="mb-6 bg-zinc-950 rounded-2xl border border-zinc-800/50 overflow-hidden">
                    <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800/50 bg-zinc-900/50">
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-1 flex items-center gap-2">
                          <Printer size={20} className="text-orange-500" />{" "}
                          打印与排版设置 / Print Setup
                        </h3>
                        <p className="text-xs text-zinc-400">
                          定制您的纸质菜单排版和内容 / Customize your physical
                          menu layout.
                        </p>
                      </div>
                      <button
                        onClick={handlePrintMenu}
                        className="bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl px-4 py-2.5 transition-colors text-sm flex items-center justify-center gap-2 max-w-fit"
                      >
                        <Printer size={16} /> 预览 & 打印 (Print PDF)
                      </button>
                    </div>

                    <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-semibold text-zinc-300 block mb-2">
                            排版风格 / Layout Style
                          </label>
                          <div className="flex bg-zinc-900 p-1 rounded-xl w-full border border-zinc-800">
                            <button
                              onClick={() =>
                                setPrintConfig({
                                  ...printConfig,
                                  layout: "grid",
                                })
                              }
                              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${printConfig.layout === "grid" ? "bg-zinc-700 text-white" : "text-zinc-400"}`}
                            >
                              网格双列 (Grid)
                            </button>
                            <button
                              onClick={() =>
                                setPrintConfig({
                                  ...printConfig,
                                  layout: "list",
                                })
                              }
                              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${printConfig.layout === "list" ? "bg-zinc-700 text-white" : "text-zinc-400"}`}
                            >
                              列表单列 (List)
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="text-sm font-semibold text-zinc-300 block mb-2">
                            包含元素 / Include Elements
                          </label>
                          <div className="space-y-2">
                            <label className="flex items-center gap-2 cursor-pointer border border-zinc-800 p-2 rounded-lg hover:bg-zinc-800/50">
                              <input
                                type="checkbox"
                                className="rounded text-orange-500 form-checkbox bg-zinc-900 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                checked={printConfig.showImages}
                                onChange={(e) =>
                                  setPrintConfig({
                                    ...printConfig,
                                    showImages: e.target.checked,
                                  })
                                }
                              />
                              <span className="text-sm text-zinc-400 font-medium">
                                菜品图片 (Images)
                              </span>
                            </label>
                            <label className="flex items-center gap-2 cursor-pointer border border-zinc-800 p-2 rounded-lg hover:bg-zinc-800/50">
                              <input
                                type="checkbox"
                                className="rounded text-orange-500 form-checkbox bg-zinc-900 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                checked={printConfig.showDescription}
                                onChange={(e) =>
                                  setPrintConfig({
                                    ...printConfig,
                                    showDescription: e.target.checked,
                                  })
                                }
                              />
                              <span className="text-sm text-zinc-400 font-medium">
                                详细描述 (Descriptions)
                              </span>
                            </label>
                            <div className="grid grid-cols-2 gap-2">
                              <label className="flex items-center gap-2 cursor-pointer border border-zinc-800 p-2 rounded-lg hover:bg-zinc-800/50">
                                <input
                                  type="checkbox"
                                  className="rounded text-orange-500 form-checkbox bg-zinc-900 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                  checked={printConfig.showBackground}
                                  onChange={(e) =>
                                    setPrintConfig({
                                      ...printConfig,
                                      showBackground: e.target.checked,
                                    })
                                  }
                                />
                                <span className="text-sm text-zinc-400 font-medium">
                                  背景 (Background)
                                </span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer border border-zinc-800 p-2 rounded-lg hover:bg-zinc-800/50">
                                <input
                                  type="checkbox"
                                  className="rounded text-orange-500 form-checkbox bg-zinc-900 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                  checked={printConfig.showLogo}
                                  onChange={(e) =>
                                    setPrintConfig({
                                      ...printConfig,
                                      showLogo: e.target.checked,
                                    })
                                  }
                                />
                                <span className="text-sm text-zinc-400 font-medium">
                                  Logo
                                </span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer border border-zinc-800 p-2 rounded-lg hover:bg-zinc-800/50">
                                <input
                                  type="checkbox"
                                  className="rounded text-orange-500 form-checkbox bg-zinc-900 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                  checked={printConfig.showQrCode}
                                  onChange={(e) =>
                                    setPrintConfig({
                                      ...printConfig,
                                      showQrCode: e.target.checked,
                                    })
                                  }
                                />
                                <span className="text-sm text-zinc-400 font-medium">
                                  二维码 (QR)
                                </span>
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-semibold text-zinc-300 block mb-2">
                            多语言配置 / Printed Languages
                          </label>
                          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 flex flex-col gap-3">
                            <label className="flex items-center gap-3 cursor-pointer">
                              <input
                                type="checkbox"
                                className="rounded text-orange-500 form-checkbox bg-zinc-950 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                checked={printConfig.langs.zh}
                                onChange={(e) =>
                                  setPrintConfig({
                                    ...printConfig,
                                    langs: {
                                      ...printConfig.langs,
                                      zh: e.target.checked,
                                    },
                                  })
                                }
                              />
                              <span className="text-sm text-zinc-300 font-medium flex-1">
                                中文 (Chinese)
                              </span>
                              <span className="text-xs text-orange-500">
                                主语言
                              </span>
                            </label>
                            <label className="flex items-center gap-3 cursor-pointer">
                              <input
                                type="checkbox"
                                className="rounded text-orange-500 form-checkbox bg-zinc-950 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                checked={printConfig.langs.en}
                                onChange={(e) =>
                                  setPrintConfig({
                                    ...printConfig,
                                    langs: {
                                      ...printConfig.langs,
                                      en: e.target.checked,
                                    },
                                  })
                                }
                              />
                              <span className="text-sm text-zinc-300 font-medium flex-1">
                                English (英语)
                              </span>
                            </label>
                            <label className="flex items-center gap-3 cursor-pointer">
                              <input
                                type="checkbox"
                                className="rounded text-orange-500 form-checkbox bg-zinc-950 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                checked={printConfig.langs.fr}
                                onChange={(e) =>
                                  setPrintConfig({
                                    ...printConfig,
                                    langs: {
                                      ...printConfig.langs,
                                      fr: e.target.checked,
                                    },
                                  })
                                }
                              />
                              <span className="text-sm text-zinc-300 font-medium flex-1">
                                Français (法语)
                              </span>
                            </label>
                            <label className="flex items-center gap-3 cursor-pointer">
                              <input
                                type="checkbox"
                                className="rounded text-orange-500 form-checkbox bg-zinc-950 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                checked={printConfig.langs.ar}
                                onChange={(e) =>
                                  setPrintConfig({
                                    ...printConfig,
                                    langs: {
                                      ...printConfig.langs,
                                      ar: e.target.checked,
                                    },
                                  })
                                }
                              />
                              <span className="text-sm text-zinc-300 font-medium flex-1">
                                العربية (阿拉伯语)
                              </span>
                            </label>
                            <label className="flex items-center gap-3 cursor-pointer">
                              <input
                                type="checkbox"
                                className="rounded text-orange-500 form-checkbox bg-zinc-950 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                checked={printConfig.langs.ma}
                                onChange={(e) =>
                                  setPrintConfig({
                                    ...printConfig,
                                    langs: {
                                      ...printConfig.langs,
                                      ma: e.target.checked,
                                    },
                                  })
                                }
                              />
                              <span className="text-sm text-zinc-300 font-medium flex-1">
                                الدارجة (摩洛哥方言)
                              </span>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Receipt Settings */}
                  {receiptSettings && setReceiptSettings && (
                    <div className="mb-6 bg-zinc-950 rounded-2xl border border-zinc-800/50 overflow-hidden">
                      <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800/50 bg-zinc-900/50">
                        <div>
                          <h3 className="text-lg font-semibold text-white mb-1 flex items-center gap-2">
                            <Printer size={20} className="text-orange-500" />{" "}
                            小票打印设置 / Receipt Setup
                          </h3>
                          <p className="text-xs text-zinc-400">
                            定制您的热敏小票排版和内容 / Customize your thermal
                            receipt layout.
                          </p>
                        </div>
                        {onSaveToCloud && (
                          <div className="flex items-center gap-3">
                            <button
                              onClick={() => {
                                const testOrder = {
                                  id:
                                    "TEST-" + Math.floor(Math.random() * 10000),
                                  timestamp: new Date().toISOString(),
                                  customerName: "Test Customer (测试)",
                                  items: [
                                    {
                                      name: "Test Item 1",
                                      enTitle: "Test Item 1 English",
                                      frTitle: "Test Item 1 Français",
                                      arTitle: "عنصر اختبار 1",
                                      maTitle: "عنصر اختبار الدارجة 1",
                                      quantity: 2,
                                      price: 50,
                                    },
                                    {
                                      name: "Test Item 2",
                                      enTitle: "Test Item 2 English",
                                      frTitle: "Test Item 2 Français",
                                      arTitle: "عنصر اختبار 2",
                                      maTitle: "عنصر اختبار الدارجة 2",
                                      quantity: 1,
                                      price: 100,
                                    },
                                  ],
                                  total: 200,
                                };
                                import("../lib/print").then((m) =>
                                  m.printReceipt(
                                    testOrder,
                                    currency,
                                    receiptSettings,
                                  ),
                                );
                              }}
                              className="bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl px-4 py-2.5 transition-colors text-sm flex items-center justify-center gap-2 max-w-fit border border-zinc-700"
                            >
                              <Printer size={16} /> 打印测试 (Test Print)
                            </button>
                            <button
                              onClick={() =>
                                onSaveToCloud({
                                  receiptSettings,
                                  silent: false,
                                })
                              }
                              className="bg-green-600 hover:bg-green-500 text-white font-bold rounded-xl px-4 py-2.5 transition-colors text-sm flex items-center justify-center gap-2 max-w-fit"
                            >
                              保存小票设置
                            </button>
                          </div>
                        )}
                      </div>

                      <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-2">
                              店铺名称 (Store Name)
                            </label>
                            <input
                              type="text"
                              value={receiptSettings.storeName}
                              onChange={(e) =>
                                setReceiptSettings({
                                  ...receiptSettings,
                                  storeName: e.target.value,
                                })
                              }
                              className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm"
                              placeholder="默认使用页面标题"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-2">
                              二维码中心图标 URL (QR Center Logo Image)
                            </label>
                            <input
                              type="text"
                              value={receiptSettings.topLogoUrl || ""}
                              onChange={(e) =>
                                setReceiptSettings({
                                  ...receiptSettings,
                                  topLogoUrl: e.target.value,
                                })
                              }
                              className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm"
                              placeholder="留空则使用默认图标"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-2">
                              二维码配色 (QR Code Colors)
                            </label>
                            
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4">
                              {[
                                { name: '经典黑白', fg: '#18181b', bg: '#ffffff' },
                                { name: '暗夜鎏金', fg: '#fbbf24', bg: '#18181b' },
                                { name: '品牌鲜橙', fg: '#ea580c', bg: '#ffffff' },
                                { name: '极光碧绿', fg: '#064e3b', bg: '#ecfdf5' },
                                { name: '深海湛蓝', fg: '#1e3a8a', bg: '#eff6ff' },
                                { name: '勃艮第红', fg: '#831843', bg: '#fdf2f8' }
                              ].map((preset, idx) => (
                                <button
                                  key={idx}
                                  onClick={() => setReceiptSettings({ ...receiptSettings, qrCodeFgColor: preset.fg, qrCodeBgColor: preset.bg })}
                                  className="flex items-center gap-2 p-2 rounded-lg border border-zinc-700 bg-zinc-900 hover:border-orange-500 transition-colors text-left"
                                >
                                  <div className="flex w-6 h-6 rounded-md overflow-hidden border border-zinc-600 shrink-0">
                                    <div className="w-1/2 h-full" style={{ backgroundColor: preset.bg }}></div>
                                    <div className="w-1/2 h-full" style={{ backgroundColor: preset.fg }}></div>
                                  </div>
                                  <span className="text-xs text-zinc-300 truncate">{preset.name}</span>
                                </button>
                              ))}
                            </div>

                            <div className="flex flex-col sm:flex-row gap-4">
                              <div className="flex-1">
                                <label className="block text-xs text-zinc-500 mb-1">前景色 (Foreground)</label>
                                <div className="flex gap-2">
                                  <input
                                    type="color"
                                    value={receiptSettings.qrCodeFgColor || "#18181b"}
                                    onChange={(e) =>
                                      setReceiptSettings({
                                        ...receiptSettings,
                                        qrCodeFgColor: e.target.value,
                                      })
                                    }
                                    className="w-12 h-10 bg-zinc-900 border border-zinc-700 rounded-lg cursor-pointer shrink-0"
                                  />
                                  <input
                                    type="text"
                                    value={receiptSettings.qrCodeFgColor || "#18181b"}
                                    onChange={(e) =>
                                      setReceiptSettings({
                                        ...receiptSettings,
                                        qrCodeFgColor: e.target.value,
                                      })
                                    }
                                    className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm font-mono uppercase"
                                    placeholder="#18181B"
                                  />
                                </div>
                              </div>
                              <div className="flex-1">
                                <label className="block text-xs text-zinc-500 mb-1">背景色 (Background)</label>
                                <div className="flex gap-2">
                                  <input
                                    type="color"
                                    value={receiptSettings.qrCodeBgColor || "#ffffff"}
                                    onChange={(e) =>
                                      setReceiptSettings({
                                        ...receiptSettings,
                                        qrCodeBgColor: e.target.value,
                                      })
                                    }
                                    className="w-12 h-10 bg-zinc-900 border border-zinc-700 rounded-lg cursor-pointer shrink-0"
                                  />
                                  <input
                                    type="text"
                                    value={receiptSettings.qrCodeBgColor || "#ffffff"}
                                    onChange={(e) =>
                                      setReceiptSettings({
                                        ...receiptSettings,
                                        qrCodeBgColor: e.target.value,
                                      })
                                    }
                                    className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm font-mono uppercase"
                                    placeholder="#FFFFFF"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-2">
                              二维码容错率 (QR Error Correction Level)
                            </label>
                            <select
                              value={receiptSettings.qrCodeLevel || "H"}
                              onChange={(e) =>
                                setReceiptSettings({
                                  ...receiptSettings,
                                  qrCodeLevel: e.target.value,
                                })
                              }
                              className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm"
                            >
                              <option value="L">L (7%) - 适合简单二维码，线条较少</option>
                              <option value="M">M (15%) - 适合无中心图标的常规情况</option>
                              <option value="Q">Q (25%) - 适合中心有较小图标</option>
                              <option value="H">H (30%) - 适合中心有较大图标 (推荐)</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-2">
                              底部 Logo URL (Bottom Logo Image)
                            </label>
                            <input
                              type="text"
                              value={receiptSettings.bottomLogoUrl || ""}
                              onChange={(e) =>
                                setReceiptSettings({
                                  ...receiptSettings,
                                  bottomLogoUrl: e.target.value,
                                })
                              }
                              className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm"
                              placeholder="例如: https://example.com/footer.png"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-2">
                              底部语 1 (Footer Line 1)
                            </label>
                            <input
                              type="text"
                              value={receiptSettings.footerText1}
                              onChange={(e) =>
                                setReceiptSettings({
                                  ...receiptSettings,
                                  footerText1: e.target.value,
                                })
                              }
                              className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-2">
                              底部语 2 (Footer Line 2)
                            </label>
                            <input
                              type="text"
                              value={receiptSettings.footerText2}
                              onChange={(e) =>
                                setReceiptSettings({
                                  ...receiptSettings,
                                  footerText2: e.target.value,
                                })
                              }
                              className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm"
                            />
                          </div>
                          <div className="col-span-1 md:col-span-2">
                            <label className="block text-sm font-semibold text-zinc-300 mb-2">
                              谷歌地图好评链接 (Google Maps Review Link)
                            </label>
                            <input
                              type="text"
                              value={receiptSettings.googleMapsReviewLink || ""}
                              onChange={(e) =>
                                setReceiptSettings({
                                  ...receiptSettings,
                                  googleMapsReviewLink: e.target.value,
                                })
                              }
                              className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm"
                              placeholder="https://g.page/r/..."
                            />
                            <p className="text-xs text-zinc-500 mt-2">
                              设置后，顾客可以在点餐后的相关界面直接点击链接为您留下好评。
                            </p>
                          </div>
                          <div className="col-span-1 md:col-span-2">
                            <label className="flex items-start gap-3 cursor-pointer p-4 bg-zinc-900 border border-zinc-700 rounded-xl hover:bg-zinc-800/50 transition-colors">
                              <div className="flex items-center h-5">
                                <input
                                  type="checkbox"
                                  className="rounded text-orange-500 form-checkbox bg-zinc-950 border-zinc-600 focus:ring-orange-500 w-5 h-5"
                                  checked={isPrintServer}
                                  onChange={(e) => {
                                    const val = e.target.checked;
                                    setIsPrintServer(val);
                                    if (val) {
                                      localStorage.setItem("isPrintServer", "true");
                                    } else {
                                      localStorage.removeItem("isPrintServer");
                                    }
                                  }}
                                />
                              </div>
                              <div className="flex flex-col">
                                <span className="text-sm font-semibold text-white">
                                  将此设备设为打印服务器 (Set this device as Print Server)
                                </span>
                                <span className="text-xs text-zinc-400 mt-1">
                                  开启后，当有新订单或加菜单时，此设备将自动唤起打印机进行打印。(When enabled, this device will automatically trigger the printer for new orders and additions.)
                                </span>
                              </div>
                            </label>
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-2">
                              小票列宽 (Receipt Column Width)
                            </label>
                            <select
                              value={receiptSettings.columnWidth || "80mm"}
                              onChange={(e) =>
                                setReceiptSettings({
                                  ...receiptSettings,
                                  columnWidth: e.target.value,
                                })
                              }
                              className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm"
                            >
                              <option value="58mm">58mm (窄边小票)</option>
                              <option value="80mm">80mm (标准小票)</option>
                              <option value="100%">100% (自适应宽度)</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-2">
                              字体大小 (Font Size)
                            </label>
                            <select
                              value={receiptSettings.fontSize || "14px"}
                              onChange={(e) =>
                                setReceiptSettings({
                                  ...receiptSettings,
                                  fontSize: e.target.value,
                                })
                              }
                              className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-orange-500 transition-colors text-sm"
                            >
                              <option value="12px">小号 (Small - 12px)</option>
                              <option value="14px">中号 (Medium - 14px)</option>
                              <option value="16px">大号 (Large - 16px)</option>
                              <option value="18px">
                                特大号 (X-Large - 18px)
                              </option>
                            </select>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-3">
                              显示设置 (Display Options)
                            </label>
                            <div className="space-y-2">
                              <label className="flex items-center gap-2 cursor-pointer border border-zinc-800 p-2 rounded-lg hover:bg-zinc-800/50">
                                <input
                                  type="checkbox"
                                  className="rounded text-orange-500 form-checkbox bg-zinc-900 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                  checked={receiptSettings.showStoreName}
                                  onChange={(e) =>
                                    setReceiptSettings({
                                      ...receiptSettings,
                                      showStoreName: e.target.checked,
                                    })
                                  }
                                />
                                <span className="text-sm text-zinc-400 font-medium">
                                  打印店铺名称 (Print Store Name)
                                </span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer border border-zinc-800 p-2 rounded-lg hover:bg-zinc-800/50">
                                <input
                                  type="checkbox"
                                  className="rounded text-orange-500 form-checkbox bg-zinc-900 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                  checked={receiptSettings.showDate}
                                  onChange={(e) =>
                                    setReceiptSettings({
                                      ...receiptSettings,
                                      showDate: e.target.checked,
                                    })
                                  }
                                />
                                <span className="text-sm text-zinc-400 font-medium">
                                  打印日期时间 (Print Date)
                                </span>
                              </label>
                              <label className="flex items-center gap-2 cursor-pointer border border-zinc-800 p-2 rounded-lg hover:bg-zinc-800/50">
                                <input
                                  type="checkbox"
                                  className="rounded text-orange-500 form-checkbox bg-zinc-900 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                  checked={receiptSettings.showQrCode}
                                  onChange={(e) =>
                                    setReceiptSettings({
                                      ...receiptSettings,
                                      showQrCode: e.target.checked,
                                    })
                                  }
                                />
                                <span className="text-sm text-zinc-400 font-medium">
                                  打印底部二维码 (Print QR Code)
                                </span>
                              </label>
                            </div>
                          </div>

                          <div>
                            <label className="block text-sm font-semibold text-zinc-300 mb-3">
                              打印语言 (Print Languages)
                            </label>
                            <div className="flex flex-wrap gap-2">
                              {[
                                { id: "zh", label: "中文" },
                                { id: "en", label: "English" },
                                { id: "fr", label: "Français" },
                                { id: "ar", label: "العربية" },
                                { id: "ma", label: "Darija" },
                              ].map((lang) => {
                                const currentLangs =
                                  receiptSettings.printLanguages || [
                                    "zh",
                                    "en",
                                    "fr",
                                    "ar",
                                    "ma",
                                  ];
                                const isChecked = currentLangs.includes(
                                  lang.id,
                                );
                                return (
                                  <label
                                    key={lang.id}
                                    className="flex items-center gap-2 cursor-pointer border border-zinc-800 p-2 rounded-lg hover:bg-zinc-800/50"
                                  >
                                    <input
                                      type="checkbox"
                                      className="rounded text-orange-500 form-checkbox bg-zinc-900 border-zinc-700 focus:ring-orange-500 w-4 h-4"
                                      checked={isChecked}
                                      onChange={(e) => {
                                        let newLangs;
                                        if (e.target.checked) {
                                          newLangs = [...currentLangs, lang.id];
                                        } else {
                                          newLangs = currentLangs.filter(
                                            (l: string) => l !== lang.id,
                                          );
                                        }
                                        setReceiptSettings({
                                          ...receiptSettings,
                                          printLanguages: newLangs,
                                        });
                                      }}
                                    />
                                    <span className="text-sm text-zinc-400 font-medium">
                                      {lang.label}
                                    </span>
                                  </label>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
              {activeTab === "appearance" && (
                <>
                  {/* Brand Settings */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <Sparkles size={20} className="text-orange-500" />{" "}
                      品牌与欢迎语 (Brand & Welcome)
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1">
                          店铺名称 / Restaurant Name
                        </label>
                        <input
                          type="text"
                          value={restaurantName}
                          onChange={(e) =>
                            setRestaurantName &&
                            setRestaurantName(e.target.value)
                          }
                          placeholder="例如: 炙·双味居"
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1">
                          定制欢迎语 / Custom Welcome Message
                        </label>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <input
                            type="text"
                            value={welcomeMessage}
                            onChange={(e) =>
                              setWelcomeMessage &&
                              setWelcomeMessage(e.target.value)
                            }
                            placeholder="例如: Premium Charcoal BBQ"
                            className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                          />
                          <button
                            type="button"
                            onClick={handleAIGenerateWelcomeMessages}
                            disabled={isGeneratingWelcome}
                            className="shrink-0 flex items-center justify-center gap-2 text-xs font-semibold px-4 py-2 bg-orange-600/10 text-orange-500 hover:bg-orange-600 hover:text-white border border-orange-600/50 rounded-xl transition-colors disabled:opacity-50"
                          >
                            {isGeneratingWelcome ? (
                              <Loader2 size={14} className="animate-spin" />
                            ) : (
                              <Sparkles size={14} />
                            )}
                            AI 智能生成标语
                          </button>
                        </div>

                        {generatedWelcomes.length > 0 && (
                          <div className="mt-3 p-3 bg-zinc-900/50 rounded-xl border border-zinc-800 border-dashed">
                            <h4 className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider mb-2">
                              点击选择 AI 生成的标语:
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {generatedWelcomes.map((msg, idx) => (
                                <button
                                  key={idx}
                                  type="button"
                                  onClick={() =>
                                    setWelcomeMessage && setWelcomeMessage(msg)
                                  }
                                  className="text-xs text-left px-3 py-2 bg-zinc-800 hover:bg-zinc-700 hover:text-orange-400 transition-colors rounded-lg border border-zinc-700"
                                >
                                  {msg}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Background Settings */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <ImageIcon size={20} className="text-orange-500" />{" "}
                      更换背景与 Logo
                    </h3>

                    <div className="space-y-4">
                      <div className="flex flex-col gap-2">
                        <label className="text-xs font-medium text-zinc-400">
                          背景图片 / Background
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={bgUrl}
                            onChange={(e) => setBgUrl(e.target.value)}
                            placeholder="输入图片 URL 或点击上传"
                            className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                          />
                          <label className="flex items-center justify-center bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-xl px-4 cursor-pointer transition-colors text-sm font-semibold text-zinc-300">
                            {isUploading ? (
                              <>
                                <Loader2
                                  size={14}
                                  className="animate-spin mr-1"
                                />{" "}
                                上传中
                              </>
                            ) : (
                              <span>上传图片</span>
                            )}
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  try {
                                    setIsUploading(true);
                                    const compressed =
                                      await compressImage(file);
                                    if (isCloudConnected) {
                                      const publicUrl =
                                        await uploadBase64ToStorage(
                                          compressed,
                                          "backgrounds",
                                        );
                                      if (setBgUrl) {
                                        setBgUrl(publicUrl);
                                        if (onSaveToCloud)
                                          onSaveToCloud({
                                            bgUrl: publicUrl,
                                            silent: true,
                                          });
                                      }
                                    } else {
                                      if (setBgUrl) setBgUrl(compressed);
                                    }
                                  } catch (err: any) {
                                    console.error("Image upload failed:", err);
                                    alert(err.message || "上传失败");
                                  } finally {
                                    setIsUploading(false);
                                  }
                                }
                              }}
                            />
                          </label>
                        </div>

                        <div className="mt-3">
                          <div className="text-xs font-medium text-zinc-400 mb-2">
                            预设绝佳主题风格 / Preset Themes:
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                            {PRESET_BACKGROUNDS.map((preset) => (
                              <button
                                key={preset.id}
                                onClick={() => setBgUrl(preset.url)}
                                className={`flex flex-col items-center justify-center p-2 rounded-xl border ${bgUrl === preset.url ? "border-orange-500 bg-orange-500/10" : "border-zinc-800 bg-zinc-900 hover:border-zinc-600"} transition-colors gap-2 relative overflow-hidden group`}
                              >
                                <div className="w-full h-16 rounded-lg bg-zinc-800 relative z-10 flex items-center justify-center overflow-hidden">
                                  {preset.url ? (
                                    <img
                                      src={preset.url}
                                      alt={preset.name}
                                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                                    />
                                  ) : (
                                    <div className="w-full h-full bg-linear-to-b from-zinc-800 to-zinc-950"></div>
                                  )}
                                </div>
                                <span
                                  className={`text-xs font-semibold z-10 ${bgUrl === preset.url ? "text-orange-500" : "text-zinc-400"}`}
                                >
                                  {preset.name}
                                </span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2 pt-4 border-t border-zinc-800/50">
                        <label className="text-xs font-medium text-zinc-400">
                          品牌图标 / Brand Logo
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={logoUrl}
                            onChange={(e) => setLogoUrl(e.target.value)}
                            placeholder="输入 Logo 图片 URL 或点击上传"
                            className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                          />
                          <label className="flex items-center justify-center bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-xl px-4 cursor-pointer transition-colors text-sm font-semibold text-zinc-300">
                            {isUploading ? (
                              <>
                                <Loader2
                                  size={14}
                                  className="animate-spin mr-1"
                                />{" "}
                                上传中
                              </>
                            ) : (
                              <span>上传 Logo</span>
                            )}
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  try {
                                    setIsUploading(true);
                                    const compressed =
                                      await compressImage(file);
                                    if (isCloudConnected) {
                                      const publicUrl =
                                        await uploadBase64ToStorage(
                                          compressed,
                                          "logos",
                                        );
                                      if (setLogoUrl) {
                                        setLogoUrl(publicUrl);
                                        if (onSaveToCloud)
                                          onSaveToCloud({
                                            logoUrl: publicUrl,
                                            silent: true,
                                          });
                                      }
                                    } else {
                                      if (setLogoUrl) setLogoUrl(compressed);
                                    }
                                  } catch (err: any) {
                                    console.error("Image upload failed:", err);
                                    alert(err.message || "上传失败");
                                  } finally {
                                    setIsUploading(false);
                                  }
                                }
                              }}
                            />
                          </label>
                        </div>
                      </div>
                    </div>

                    <p className="text-[10px] text-zinc-500 mt-2">
                      背景留空以使用默认暗黑渐变背景。Logo
                      留空使用系统默认图标。
                    </p>
                  </div>
                </>
              )}
              {activeTab === "menu" && (
                <>
                  {/* Category Management */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                        <Settings size={20} className="text-orange-500" />{" "}
                        现有分类与菜品管理 (Manage Categories & Dishes)
                      </h3>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handleExportJson}
                          className="flex items-center gap-1.5 px-3 py-2 bg-zinc-900 border border-zinc-800 hover:border-orange-500 text-zinc-300 hover:text-orange-500 rounded-xl text-xs font-semibold transition-colors active:scale-95"
                        >
                          <DownloadCloud size={16} className="text-orange-400" />
                          <span>导出 JSON 备份</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleExportCsv}
                          className="flex items-center gap-1.5 px-3 py-2 bg-zinc-900 border border-zinc-800 hover:border-green-500 text-zinc-300 hover:text-green-500 rounded-xl text-xs font-semibold transition-colors active:scale-95"
                        >
                          <FileSpreadsheet size={16} className="text-green-400" />
                          <span>导出 Excel/CSV</span>
                        </button>
                      </div>
                    </div>
                    <form
                      onSubmit={handleAddCategory}
                      className="flex flex-col gap-2 mb-4"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-2">
                        <input
                          type="text"
                          value={newCategory.name}
                          onChange={(e) =>
                            setNewCategory({
                              ...newCategory,
                              name: e.target.value,
                            })
                          }
                          placeholder="分类名称 (ZH)"
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                          required
                        />
                        <input
                          type="text"
                          value={newCategory.enName}
                          onChange={(e) =>
                            setNewCategory({
                              ...newCategory,
                              enName: e.target.value,
                            })
                          }
                          placeholder="Name (EN)"
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                        />
                        <input
                          type="text"
                          value={newCategory.frName}
                          onChange={(e) =>
                            setNewCategory({
                              ...newCategory,
                              frName: e.target.value,
                            })
                          }
                          placeholder="Nom (FR)"
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                        />
                        <input
                          type="text"
                          value={newCategory.arName}
                          onChange={(e) =>
                            setNewCategory({
                              ...newCategory,
                              arName: e.target.value,
                            })
                          }
                          placeholder="الاسم (AR)"
                          dir="auto"
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white text-right focus:outline-none focus:border-orange-500"
                        />
                        <input
                          type="text"
                          value={newCategory.maName}
                          onChange={(e) =>
                            setNewCategory({
                              ...newCategory,
                              maName: e.target.value,
                            })
                          }
                          placeholder="الاسم (MA - Darija)"
                          dir="auto"
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white text-right focus:outline-none focus:border-orange-500"
                        />
                      </div>
                      <button
                        type="submit"
                        className="bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl px-4 py-2.5 transition-colors text-sm border border-zinc-700 self-end"
                      >
                        添加多语分类 / Add Multi-Lang Category
                      </button>
                    </form>
                    {categories.length > 0 && (
                      <div className="space-y-3 mt-4 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
                        {categories.map((cat) => (
                          <div
                            key={cat.id}
                            className="bg-zinc-900/50 rounded-xl border border-zinc-800 overflow-hidden"
                          >
                            <div className="flex items-center justify-between p-3 bg-zinc-900 border-b border-zinc-800">
                              <span className="text-sm text-zinc-300 font-medium">
                                {cat.name}{" "}
                                <span className="text-zinc-600 text-xs ml-2">
                                  ({cat.items?.length || 0})
                                </span>
                              </span>
                              <button
                                onClick={() => handleDeleteCategory(cat.id)}
                                className="flex items-center gap-1 text-xs px-2 py-1 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white rounded-md transition-colors"
                                title="Delete category"
                              >
                                <Trash2 size={14} /> 删除分类
                              </button>
                            </div>
                            {cat.items && cat.items.length > 0 && (
                              <div className="p-2 space-y-2 max-h-40 overflow-y-auto custom-scrollbar">
                                {(cat.items || []).map((item: any) => (
                                  <div
                                    key={item.id}
                                    className="flex items-center justify-between p-2 bg-zinc-950/50 rounded-lg group"
                                  >
                                    <div className="flex items-center gap-3 overflow-hidden">
                                      <label
                                        htmlFor={`upload-item-${item.id}`}
                                        className="cursor-pointer relative flex flex-shrink-0 w-10 h-10 group/img"
                                      >
                                        <div
                                          className={`absolute inset-0 bg-black/60 flex items-center justify-center rounded-md z-10 transition-all ${uploadingItemId === item.id ? "opacity-100" : "opacity-0 md:group-hover/img:opacity-100"}`}
                                        >
                                          {uploadingItemId === item.id ? (
                                            <Loader2
                                              size={16}
                                              className="text-white animate-spin"
                                            />
                                          ) : (
                                            <UploadCloud
                                              size={16}
                                              className="text-white drop-shadow-md"
                                            />
                                          )}
                                        </div>
                                        <input
                                          id={`upload-item-${item.id}`}
                                          type="file"
                                          accept="image/*"
                                          className="hidden"
                                          onChange={async (e) => {
                                            const file = e.target.files?.[0];
                                            if (file) {
                                              try {
                                                setUploadingItemId(item.id);
                                                const compressed =
                                                  await compressImage(file);
                                                let finalUrl = compressed;
                                                if (isCloudConnected) {
                                                  finalUrl =
                                                    await uploadBase64ToStorage(
                                                      compressed,
                                                      "dishes",
                                                    );
                                                }
                                                const updatedCategories =
                                                  categories.map((c) => {
                                                    if (c.id === cat.id) {
                                                      return {
                                                        ...c,
                                                        items: (
                                                          c.items || []
                                                        ).map((i: any) =>
                                                          i.id === item.id
                                                            ? {
                                                                ...i,
                                                                image: finalUrl,
                                                              }
                                                            : i,
                                                        ),
                                                      };
                                                    }
                                                    return c;
                                                  });
                                                setCategories(
                                                  updatedCategories,
                                                );
                                                if (onSaveToCloud)
                                                  onSaveToCloud({
                                                    categories:
                                                      updatedCategories,
                                                    silent: true,
                                                  });
                                              } catch (err: any) {
                                                console.error(
                                                  "Image upload failed:",
                                                  err,
                                                );
                                                alert(
                                                  "上传失败 (Upload failed): " +
                                                    (err.message ||
                                                      "unknown error"),
                                                );
                                              } finally {
                                                setUploadingItemId(null);
                                              }
                                            }
                                            e.target.value = ""; // Reset
                                          }}
                                        />
                                        {item.image ? (
                                          <img
                                            src={item.image}
                                            alt=""
                                            className="w-10 h-10 rounded-md object-cover bg-zinc-800"
                                          />
                                        ) : (
                                          <div className="w-10 h-10 rounded-md bg-zinc-800 flex items-center justify-center text-zinc-500">
                                            {uploadingItemId !== item.id && (
                                              <UploadCloud size={16} />
                                            )}
                                          </div>
                                        )}
                                      </label>
                                      <div className="flex flex-col min-w-0">
                                        <span className="text-sm font-medium text-zinc-300 truncate">
                                          {item.title}
                                        </span>
                                        <span className="text-[10px] text-zinc-500 font-mono">
                                          {item.stock !== undefined && item.stock !== null ? `库存: ${item.stock} 份` : "库存: 无限制"}
                                        </span>
                                      </div>
                                    </div>
                                    <div className="flex gap-2 flex-wrap sm:flex-nowrap">
                                      <button
                                        onClick={() => {
                                          const updatedCategories = categories.map((c) => {
                                            if (c.id === cat.id) {
                                              return {
                                                ...c,
                                                items: (c.items || []).map((i: any) =>
                                                  i.id === item.id
                                                    ? { ...i, isSoldOut: !i.isSoldOut }
                                                    : i
                                                ),
                                              };
                                            }
                                            return c;
                                          });
                                          setCategories(updatedCategories);
                                          if (onSaveToCloud)
                                            onSaveToCloud({
                                              categories: updatedCategories,
                                              silent: true,
                                            });
                                        }}
                                        className={`flex items-center gap-1 text-[10px] sm:text-xs px-2 py-1.5 bg-zinc-900 border rounded-md transition-colors flex-shrink-0 ${
                                          item.isSoldOut
                                            ? "border-orange-500/50 text-orange-400 hover:bg-orange-500 hover:text-white"
                                            : "border-zinc-500/30 text-zinc-400 hover:bg-zinc-700 hover:text-white"
                                        }`}
                                        title={item.isSoldOut ? "标记为在售 (Mark as available)" : "标记为售罄 (Mark as sold out)"}
                                      >
                                        {item.isSoldOut ? "已售罄" : "售罄"}
                                      </button>
                                      <button
                                        onClick={() => {
                                          setPromptValue(item.price);
                                          setPromptDialog({
                                            isOpen: true,
                                            message: `修改 ${item.title} 的价格 / Edit price:`,
                                            defaultValue: item.price,
                                            onConfirm: (newPrice: string) => {
                                              if (newPrice.trim() !== "") {
                                                const updatedCategories =
                                                  categories.map((c) => {
                                                    if (c.id === cat.id) {
                                                      return {
                                                        ...c,
                                                        items: (
                                                          c.items || []
                                                        ).map((i: any) =>
                                                          i.id === item.id
                                                            ? {
                                                                ...i,
                                                                price:
                                                                  newPrice.trim(),
                                                              }
                                                            : i,
                                                        ),
                                                      };
                                                    }
                                                    return c;
                                                  });
                                                setCategories(
                                                  updatedCategories,
                                                );
                                                if (onSaveToCloud)
                                                  onSaveToCloud({
                                                    categories:
                                                      updatedCategories,
                                                    silent: true,
                                                  });
                                              }
                                              setPromptDialog(null);
                                            },
                                          });
                                        }}
                                        className="flex items-center gap-1 text-[10px] sm:text-xs px-2 py-1.5 bg-zinc-900 border border-blue-500/30 text-blue-400 hover:bg-blue-500 hover:text-white rounded-md transition-colors flex-shrink-0"
                                        title="Edit price"
                                      >
                                        <Edit2 size={14} /> 改价
                                      </button>
                                      <button
                                        onClick={() => {
                                          const currentStock = item.stock !== undefined && item.stock !== null ? String(item.stock) : "";
                                          setPromptValue(currentStock);
                                          setPromptDialog({
                                            isOpen: true,
                                            message: `修改 ${item.title} 的库存数量 (留空为无限制) / Edit stock quantity:`,
                                            defaultValue: currentStock,
                                            onConfirm: (newStock: string) => {
                                              const stockVal = newStock.trim() === "" ? null : Number(newStock.trim());
                                              const updatedCategories =
                                                categories.map((c) => {
                                                  if (c.id === cat.id) {
                                                    return {
                                                      ...c,
                                                      items: (
                                                        c.items || []
                                                      ).map((i: any) =>
                                                        i.id === item.id
                                                          ? {
                                                              ...i,
                                                              stock: isNaN(Number(stockVal)) ? null : stockVal,
                                                              isSoldOut: stockVal === 0 ? true : i.isSoldOut,
                                                            }
                                                          : i,
                                                      ),
                                                    };
                                                  }
                                                  return c;
                                                });
                                              setCategories(
                                                updatedCategories,
                                              );
                                              if (onSaveToCloud)
                                                onSaveToCloud({
                                                  categories:
                                                    updatedCategories,
                                                  silent: true,
                                                });
                                              setPromptDialog(null);
                                            },
                                          });
                                        }}
                                        className="flex items-center gap-1 text-[10px] sm:text-xs px-2 py-1.5 bg-zinc-900 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500 hover:text-white rounded-md transition-colors flex-shrink-0"
                                        title="Edit stock"
                                      >
                                        <Database size={14} /> 改库存
                                      </button>
                                      <button
                                        onClick={() =>
                                          handleDeleteDish(cat.id, item.id)
                                        }
                                        className="flex items-center gap-1 text-[10px] sm:text-xs px-2 py-1.5 bg-zinc-900 border border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white rounded-md transition-colors flex-shrink-0"
                                        title="Delete dish"
                                      >
                                        <Trash2 size={14} /> 删除
                                      </button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </>
              )}
              {activeTab === "promotions" && (
                <>
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <Flame size={20} className="text-orange-500" /> 添加新活动
                      (Add Promotion)
                    </h3>
                    <form onSubmit={handleAddPromotion} className="space-y-4">
                      <div className="flex gap-2 mb-4">
                        <input
                          type="text"
                          value={newPromotion.title}
                          onChange={(e) =>
                            setNewPromotion({
                              ...newPromotion,
                              title: e.target.value,
                            })
                          }
                          placeholder="活动标题 (中文) / Promotion Title"
                          className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                          required
                        />
                        <button
                          type="submit"
                          className="bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl px-4 py-2.5 transition-colors text-sm"
                        >
                          添加活动
                        </button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            图片 URL / Image URL
                          </label>
                          <input
                            type="text"
                            value={newPromotion.image}
                            onChange={(e) =>
                              setNewPromotion({
                                ...newPromotion,
                                image: e.target.value,
                              })
                            }
                            placeholder="活动图片 (必填)"
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            描述 (中)
                          </label>
                          <textarea
                            value={newPromotion.description}
                            onChange={(e) =>
                              setNewPromotion({
                                ...newPromotion,
                                description: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white resize-none"
                            rows={2}
                          />
                        </div>
                        <div className="col-span-1 md:col-span-2 text-xs text-zinc-500 italic mt-2 border-t border-zinc-800 pt-2">
                          多语版本 (Multi-language) - 如果为空将在界面中降级显示
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            Title (EN)
                          </label>
                          <input
                            type="text"
                            value={newPromotion.enTitle}
                            onChange={(e) =>
                              setNewPromotion({
                                ...newPromotion,
                                enTitle: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            Description (EN)
                          </label>
                          <textarea
                            value={newPromotion.enDescription}
                            onChange={(e) =>
                              setNewPromotion({
                                ...newPromotion,
                                enDescription: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white resize-none"
                            rows={1}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            Titre (FR)
                          </label>
                          <input
                            type="text"
                            value={newPromotion.frTitle}
                            onChange={(e) =>
                              setNewPromotion({
                                ...newPromotion,
                                frTitle: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            Description (FR)
                          </label>
                          <textarea
                            value={newPromotion.frDescription}
                            onChange={(e) =>
                              setNewPromotion({
                                ...newPromotion,
                                frDescription: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white resize-none"
                            rows={1}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            عنوان (AR)
                          </label>
                          <input
                            type="text"
                            value={newPromotion.arTitle}
                            onChange={(e) =>
                              setNewPromotion({
                                ...newPromotion,
                                arTitle: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white text-right"
                            dir="auto"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            الوصف (AR)
                          </label>
                          <textarea
                            value={newPromotion.arDescription}
                            onChange={(e) =>
                              setNewPromotion({
                                ...newPromotion,
                                arDescription: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white resize-none text-right"
                            dir="auto"
                            rows={1}
                          />
                        </div>
                      </div>
                    </form>
                  </div>

                  {promotions && promotions.length > 0 && (
                    <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                      <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                        <List size={20} className="text-orange-500" /> 现有活动
                        (Current Promotions)
                      </h3>
                      <div className="space-y-3">
                        {promotions.map((promo) => (
                          <div
                            key={promo.id}
                            className="flex flex-col sm:flex-row items-center gap-4 bg-zinc-900/50 p-3 rounded-xl border border-zinc-800"
                          >
                            {promo.image && (
                              <img
                                src={promo.image}
                                alt="promo"
                                className="w-24 h-16 object-cover rounded-md"
                              />
                            )}
                            <div className="flex-1 text-sm text-white font-medium">
                              <div>{promo.title}</div>
                              <div className="text-xs text-zinc-500 truncate max-w-[200px]">
                                {promo.description}
                              </div>
                            </div>
                            <div className="flex gap-2 w-full sm:w-auto mt-2 sm:mt-0">
                              <button
                                onClick={() => {
                                  const newList = promotions.map((p) =>
                                    p.id === promo.id
                                      ? { ...p, isActive: !p.isActive }
                                      : p,
                                  );
                                  if (setPromotions) setPromotions(newList);
                                }}
                                className={`px-3 py-1.5 rounded-lg text-xs font-bold border ${promo.isActive ? "bg-green-900/30 text-green-400 border-green-500/30" : "bg-zinc-800 text-zinc-400 border-zinc-700"}`}
                              >
                                {promo.isActive
                                  ? "可见 (Active)"
                                  : "隐藏 (Hidden)"}
                              </button>
                              <button
                                onClick={() => handleRemovePromotion(promo.id)}
                                className="px-3 py-1.5 bg-zinc-800 text-red-400 hover:bg-red-900/30 border border-zinc-700 hover:border-red-500/30 rounded-lg text-xs font-bold transition-colors"
                              >
                                删除
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
              {activeTab === "security" && (
                <>
                  {/* Change Password Settings */}
                  <form
                    onSubmit={handleChangePassword}
                    className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50"
                  >
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <Lock size={20} className="text-orange-500" />{" "}
                      更改管理员密码
                    </h3>
                    <div className="flex gap-2">
                      <input
                        type="password"
                        value={newAdminPassword}
                        onChange={(e) => setNewAdminPassword(e.target.value)}
                        placeholder="输入新密码"
                        className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                        required
                      />
                      <button
                        type="submit"
                        className="bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl px-4 py-2.5 transition-colors text-sm border border-zinc-700"
                      >
                        确认更改
                      </button>
                    </div>
                    <p className="text-[10px] text-zinc-500 mt-2">
                      一旦更改，所有设备下次登录都需要使用新密码。
                    </p>
                  </form>

                  {/* Config Device Passwords */}
                  <form
                    onSubmit={handleSaveDevicePasswords}
                    className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50"
                  >
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <Lock size={20} className="text-orange-500" />{" "}
                      服务员模式配置 (Waiter Mode Passwords)
                    </h3>
                    <div className="flex flex-col gap-3">
                      {[0, 1, 2, 3, 4].map((index) => (
                        <div key={index} className="flex gap-2 items-center">
                          <span className="text-zinc-500 text-xs w-6">
                            {index + 1}.
                          </span>
                          <input
                            type="text"
                            value={localDevicePasswords[index]?.name || ""}
                            onChange={(e) => {
                              const newArr = [...localDevicePasswords];
                              if (!newArr[index])
                                newArr[index] = { name: "", password: "" };
                              newArr[index].name = e.target.value;
                              setLocalDevicePasswords(newArr);
                            }}
                            placeholder="服务员工号/姓名 (Waiter ID/Name)"
                            className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
                          />
                          <input
                            type="text"
                            value={localDevicePasswords[index]?.password || ""}
                            onChange={(e) => {
                              const newArr = [...localDevicePasswords];
                              if (!newArr[index])
                                newArr[index] = { name: "", password: "" };
                              newArr[index].password = e.target.value;
                              setLocalDevicePasswords(newArr);
                            }}
                            placeholder="服务员密码 (Password)"
                            className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
                          />
                        </div>
                      ))}
                      <button
                        type="submit"
                        className="bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl px-4 py-2.5 transition-colors text-sm border border-zinc-700 self-end mt-2"
                      >
                        保存服务员密码 (Save Waiter Passwords)
                      </button>
                    </div>
                    <p className="text-[10px] text-zinc-500 mt-2">
                      配置后，服务员可通过在登录界面输入此密码直接解锁点单功能。最多配置5个服务员。
                      (Configure passwords to allow waiters to unlock ordering
                      directly. Max 5 waiters.)
                    </p>
                  </form>

                  {/* Config Security Question */}
                  <form
                    onSubmit={handleChangeSecurity}
                    className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50"
                  >
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <Shield size={20} className="text-orange-500" />{" "}
                      设置密码找回密保
                    </h3>
                    <div className="flex flex-col gap-2">
                      <input
                        type="text"
                        value={newSecurityQuestion}
                        onChange={(e) => setNewSecurityQuestion(e.target.value)}
                        placeholder="例如：我的第一只宠物叫什么？"
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                        required
                      />
                      <input
                        type="text"
                        value={newSecurityAnswer}
                        onChange={(e) => setNewSecurityAnswer(e.target.value)}
                        placeholder="输入密保答案"
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                        required
                      />
                      <button
                        type="submit"
                        className="bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl px-4 py-2.5 transition-colors text-sm border border-zinc-700 self-end mt-2"
                      >
                        保存密保设置
                      </button>
                    </div>
                    <p className="text-[10px] text-zinc-500 mt-2">
                      开启密保后，如遗忘密码，可通过回答问题查看最新密码。
                    </p>
                  </form>
                </>
              )}
              {activeTab === "database" && (
                <>
                  {/* Local Backup & Restore */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <h3 className="text-lg font-semibold text-white mb-2 flex items-center gap-2">
                      <Save size={20} className="text-orange-500" />{" "}
                      本地备份与恢复 (Local Backup)
                    </h3>
                    <p className="text-xs text-zinc-400 mb-4">
                      您可以将当前的所有分类、菜品、背景配置下载为 JSON
                      格式备份到本地设备，或导出 Excel/CSV 菜品清单表格，也可以从本地恢复菜单。
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        onClick={handleExportJson}
                        className="bg-zinc-900 border border-zinc-800 hover:border-orange-500 text-zinc-300 hover:text-orange-500 px-4 py-3 rounded-xl transition-colors text-sm font-semibold flex flex-col items-center justify-center gap-1.5 active:scale-95"
                      >
                        <DownloadCloud size={22} className="text-orange-400" />
                        <span>导出 JSON 备份</span>
                        <span className="text-[10px] font-normal text-zinc-500">(Export JSON)</span>
                      </button>
                      <button
                        onClick={handleExportCsv}
                        className="bg-zinc-900 border border-zinc-800 hover:border-green-500 text-zinc-300 hover:text-green-500 px-4 py-3 rounded-xl transition-colors text-sm font-semibold flex flex-col items-center justify-center gap-1.5 active:scale-95"
                      >
                        <FileSpreadsheet size={22} className="text-green-400" />
                        <span>导出 Excel / CSV</span>
                        <span className="text-[10px] font-normal text-zinc-500">(Export Spreadsheet)</span>
                      </button>
                      <label className="bg-zinc-900 border border-zinc-800 hover:border-blue-500 text-zinc-300 hover:text-blue-500 px-4 py-3 rounded-xl transition-colors text-sm font-semibold flex flex-col items-center justify-center gap-1.5 cursor-pointer active:scale-95">
                        <UploadCloud size={22} className="text-blue-400" />
                        <span>从本地恢复</span>
                        <span className="text-[10px] font-normal text-zinc-500">(Import JSON)</span>
                        <input
                          type="file"
                          accept=".json"
                          className="hidden"
                          onChange={handleImportJson}
                        />
                      </label>
                    </div>
                  </div>

                  {/* Firebase Connection Setup */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                        <Database size={20} className="text-orange-500" />{" "}
                        Firestore 数据库连接状态
                      </h3>
                      {isCloudConnected ? (
                        <span className="px-2.5 py-1 rounded bg-green-500/10 text-green-400 border border-green-500/20 text-xs font-semibold flex items-center gap-1.5">
                          <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                          已连接 (Connected)
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded bg-red-500/10 text-red-400 border border-red-500/20 text-xs font-semibold flex items-center gap-1.5">
                          <div className="w-1.5 h-1.5 rounded-full bg-red-500" />
                          未连接 (Disconnected)
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-zinc-400">
                      系统正在连接至云端的 Firebase Firestore
                      作为主数据库，实现数据实时同步。
                    </p>
                  </div>

                  {/* Image Storage Optimization Card */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <h3 className="text-lg font-semibold text-white mb-2 flex items-center gap-2">
                      <Sparkles size={20} className="text-orange-500" />{" "}
                      图片托管与空间优化 (Image Storage Optimization)
                    </h3>
                    {base64Count > 0 ? (
                      <div>
                        <p className="text-xs text-zinc-300 mb-3">
                          ⚠️ <strong>检测到您的菜单中含有本地 Base64 图片：</strong>
                          <br />
                          当前有 <span className="text-orange-500 font-bold text-sm">{base64Count}</span> 个菜品的图片是作为 Base64 数据直接保存在 Firestore 数据库中。
                          由于 Firestore 单个文档的大小限制为 <span className="text-orange-500 font-bold">1 MB (1024 KB)</span>，这些大图片已使您的数据库接近满载 ({dbSizeKB} KB / 1024 KB)。
                          <strong>这正是您可能无法继续添加或更新菜单的原因！</strong>
                        </p>
                        <p className="text-xs text-zinc-400 mb-4">
                          点击下方按钮，系统将自动把所有 Base64 格式的菜品图片上传至安全的 <strong>Firebase Storage 云存储空间</strong>，并在数据库中只保留轻量的图片网址。这将能释放 99% 的空间！
                        </p>
                        <button
                          onClick={handleOptimizeImages}
                          disabled={isOptimizing}
                          className="w-full bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 text-sm shadow-lg shadow-orange-600/10 disabled:opacity-50"
                        >
                          {isOptimizing ? (
                            <>
                              <Loader2 size={18} className="animate-spin" />
                              <span>{optimizationProgress}</span>
                            </>
                          ) : (
                            <>
                              <Sparkles size={18} />
                              <span>一键优化图片存储 (自动迁移至 Storage)</span>
                            </>
                          )}
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-start gap-3 p-3 bg-green-500/5 border border-green-500/10 rounded-xl">
                        <CheckCircle size={20} className="text-green-500 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs text-green-400 font-semibold mb-1">
                            图片存储状态优良 / All Images Optimized
                          </p>
                          <p className="text-[11px] text-zinc-400">
                            您的所有菜品图片都已完美托管在 Firebase Cloud Storage 云存储或外链中，
                            没有占用多余的 Firestore 数据库单文档空间。您的数据库将能极为高效地运作，支持无限次上传与修改！
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Database Information */}
                  <div className="p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50 flex flex-col gap-4">
                    <div className="flex-1 w-full">
                      <h3 className="text-lg font-semibold text-white mb-1 flex items-center gap-2">
                        <Database size={20} className="text-orange-500" />{" "}
                        当前菜单数据体积 (Firestore Document Size)
                      </h3>
                      <p className="text-xs text-zinc-400 mb-4">
                        目前含有 {categories.length} 个分类，共 {totalDishes}{" "}
                        个菜品。
                      </p>

                      {/* Storage Progress Bar */}
                      <div className="w-full">
                        <div className="flex justify-between text-xs font-mono text-zinc-400 mb-1.5">
                          <span>
                            {dbSizeKB} KB 已用 ({((Number(dbSizeKB) / 1024) * 100).toFixed(1)}%)
                          </span>
                          <span>1024 KB (Firestore 单文档上限)</span>
                        </div>
                        <div className="w-full h-2 rounded-full border border-zinc-800 overflow-hidden bg-zinc-900">
                          <div
                            className={`h-full transition-all duration-500 ${Number(dbSizeKB) > 900 ? "bg-red-500 animate-pulse" : Number(dbSizeKB) > 700 ? "bg-amber-500" : "bg-emerald-500"}`}
                            style={{
                              width: `${Math.min(100, Math.max(0.2, (Number(dbSizeKB) / 1024) * 100))}%`,
                            }}
                          />
                        </div>
                        <p className="text-[10px] text-zinc-500 mt-2 text-right">
                          *(提示：由于 Firestore 对 global 设置采用单文档存储，图片迁移至 Storage 后该体积将直接缩减至 &lt;10 KB)
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Supabase Storage System Diagnostics Card */}
                  <div className="mb-6 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50">
                    <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                        <Cloud size={20} className="text-orange-500 animate-pulse" />{" "}
                        Supabase 云数据库与存储空间联控
                      </h3>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setIsSupabaseSetupOpen(true)}
                          className="flex items-center gap-1.5 text-xs bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-lg transition-all shadow-md shadow-emerald-600/20"
                        >
                          <Database size={13} />
                          <span>配置 / 切换 Supabase 云端凭证</span>
                        </button>

                        <button
                          onClick={runDiagnostics}
                          disabled={isLoadingDiagnostics}
                          className="flex items-center gap-1 text-xs bg-zinc-900 border border-zinc-700 hover:border-orange-500 hover:text-orange-400 text-zinc-300 px-2.5 py-1.5 rounded-lg transition-colors disabled:opacity-50"
                        >
                          <RefreshCw size={12} className={isLoadingDiagnostics ? "animate-spin" : ""} />
                          <span>{isLoadingDiagnostics ? "正在扫描..." : "刷新诊断"}</span>
                        </button>
                      </div>
                    </div>

                    {isLoadingDiagnostics && !diagnosticData ? (
                      <div className="flex flex-col items-center justify-center py-8 text-zinc-500 gap-2">
                        <Loader2 className="animate-spin text-orange-500" size={24} />
                        <span className="text-xs">正在深度扫描云端存储桶文件并计算空间占比...</span>
                      </div>
                    ) : diagnosticError ? (
                      <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-xs flex flex-col gap-2">
                        <p className="flex items-center gap-1.5 font-semibold">
                          <AlertTriangle size={14} /> 诊断异常: {diagnosticError}
                        </p>
                        <button
                          onClick={runDiagnostics}
                          className="bg-red-500/20 hover:bg-red-500/30 text-white font-semibold py-1.5 px-3 rounded-lg transition-colors text-center self-start"
                        >
                          重新连接并扫描
                        </button>
                      </div>
                    ) : diagnosticData ? (
                      <div className="space-y-4 text-xs">
                        {/* Space Usage Progress */}
                        <div className="p-3 bg-zinc-900/50 rounded-xl border border-zinc-800/80">
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-zinc-400 font-semibold flex items-center gap-1">
                              <HardDrive size={13} className="text-orange-500" />
                              云端存储桶 (menu-assets) 容量状态
                            </span>
                            <span className="text-zinc-400 font-mono">
                              {(diagnosticData.totalUsedBytes / (1024 * 1024)).toFixed(2)} MB / {(diagnosticData.bucketLimitBytes / (1024 * 1024)).toFixed(0)} MB
                            </span>
                          </div>
                          
                          {/* Progress Bar */}
                          <div className="w-full h-2 bg-zinc-950 border border-zinc-800 rounded-full overflow-hidden mb-2">
                            <div
                              className={`h-full transition-all duration-500 ${
                                (diagnosticData.totalUsedBytes / diagnosticData.bucketLimitBytes) > 0.8
                                  ? "bg-red-500 animate-pulse"
                                  : (diagnosticData.totalUsedBytes / diagnosticData.bucketLimitBytes) > 0.5
                                  ? "bg-amber-500"
                                  : "bg-emerald-500"
                              }`}
                              style={{
                                width: `${Math.min(100, Math.max(0.5, (diagnosticData.totalUsedBytes / diagnosticData.bucketLimitBytes) * 100))}%`
                              }}
                            />
                          </div>

                          <div className="flex justify-between text-[10px] text-zinc-500">
                            <span>
                              可用空间: {((diagnosticData.bucketLimitBytes - diagnosticData.totalUsedBytes) / (1024 * 1024)).toFixed(2)} MB
                            </span>
                            <span>
                              已用占比: {((diagnosticData.totalUsedBytes / diagnosticData.bucketLimitBytes) * 100).toFixed(2)}%
                            </span>
                          </div>
                        </div>

                        {/* Production Database Tables Status & Seed/Sync */}
                        <div className="p-3.5 bg-zinc-900/80 rounded-xl border border-zinc-800">
                          <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                            <span className="text-zinc-200 font-semibold flex items-center gap-1.5 text-xs">
                              <Database size={14} className="text-emerald-400" />
                              生产环境数据库全表状态 (Production Database Tables)
                            </span>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => handleSeedDatabase(false)}
                                disabled={isSeedingDb}
                                className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold px-2.5 py-1 rounded-lg transition-all text-[11px] shadow-sm shadow-emerald-600/20"
                              >
                                {isSeedingDb ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />}
                                <span>一键自动补全空表</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  if (window.confirm("确定要对 Supabase 生产环境数据库执行强制全量重置同步吗？这会刷新初始化数据。")) {
                                    handleSeedDatabase(true);
                                  }
                                }}
                                disabled={isSeedingDb}
                                className="flex items-center gap-1 bg-amber-600/20 border border-amber-500/40 hover:bg-amber-600/30 text-amber-300 disabled:opacity-50 font-semibold px-2.5 py-1 rounded-lg transition-all text-[11px]"
                              >
                                <span>重置初始化</span>
                              </button>
                            </div>
                          </div>

                          {dbTableStats?.tables ? (
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-2">
                              {[
                                { key: "settings", label: "全局设置", icon: "⚙️" },
                                { key: "categories", label: "菜单分类", icon: "📁" },
                                { key: "menu_items", label: "菜品数据", icon: "🍖" },
                                { key: "inventory_items", label: "原材料库存", icon: "📦" },
                                { key: "recipe_boms", label: "BOM配方", icon: "🧪" },
                                { key: "tables", label: "QR餐桌", icon: "🪑" },
                                { key: "orders", label: "顾客订单", icon: "🧾" },
                              ].map(item => {
                                const count = dbTableStats.tables[item.key] ?? -1;
                                const isEmpty = count === 0;
                                const isError = count === -1;
                                return (
                                  <div
                                    key={item.key}
                                    className={`p-2 rounded-lg border text-left flex flex-col justify-between ${
                                      isError
                                        ? "bg-red-500/5 border-red-500/20 text-red-400"
                                        : isEmpty
                                        ? "bg-amber-500/5 border-amber-500/20 text-amber-300"
                                        : "bg-zinc-950 border-zinc-800 text-zinc-300"
                                    }`}
                                  >
                                    <div className="flex items-center justify-between text-[11px] text-zinc-400">
                                      <span>{item.icon} {item.label}</span>
                                      <span className="font-mono text-[10px] text-zinc-500">{item.key}</span>
                                    </div>
                                    <div className="mt-1 flex items-baseline justify-between">
                                      <span className="text-sm font-bold font-mono">
                                        {isError ? "未建表" : `${count} 条`}
                                      </span>
                                      <span className="text-[10px]">
                                        {isError ? "⚠️" : isEmpty ? "需初始化" : "正常已同步"}
                                      </span>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          ) : (
                            <div className="py-3 text-center text-zinc-500 text-[11px] flex items-center justify-center gap-1.5">
                              <Loader2 size={13} className="animate-spin text-emerald-500" />
                              正在获取生产数据库各表记录数...
                            </div>
                          )}

                          {seedLogs && seedLogs.length > 0 && (
                            <div className="mt-2 p-2.5 bg-zinc-950 border border-zinc-800 rounded-lg text-[11px] font-mono space-y-1 max-h-32 overflow-y-auto">
                              <div className="text-emerald-400 font-bold mb-1 flex items-center gap-1">
                                <Sparkles size={12} /> 同步/初始化结果日志:
                              </div>
                              {seedLogs.map((log, idx) => (
                                <div key={idx} className="text-zinc-300 leading-snug">
                                  {log}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Automatic Compression Rule Announcement */}
                        <div className="p-3 bg-orange-500/5 border border-orange-500/10 rounded-xl text-zinc-400">
                          <p className="font-semibold text-orange-400 mb-1 flex items-center gap-1">
                            <Sparkles size={13} />
                            智能大图自动压缩已生效 (High-Res Smart Compression)
                          </p>
                          <p className="text-[10px] leading-relaxed">
                            为了保障手机端极速加载，系统已应用 <strong>1200px 高清无损压缩算法</strong>。
                            上传超过 1MB 的超大菜品图片或背景时，前端将在上传前自动将其压缩至 150KB-300KB 的黄金平衡尺寸，在保持高清的同时节省 85% 以上的云存储桶空间！
                          </p>
                        </div>

                        {/* File list header */}
                        <div>
                          <div className="flex justify-between text-zinc-400 font-semibold mb-2 items-center px-1">
                            <span>云端文件列表 ({diagnosticData.files.length} 个文件)</span>
                            <span className="text-zinc-500 font-normal">点击垃圾桶可清理冗余/无用大图</span>
                          </div>

                          {diagnosticData.files.length === 0 ? (
                            <div className="p-4 bg-zinc-900/30 rounded-xl border border-zinc-800/30 text-center text-zinc-500">
                              目前云端存储桶没有上传任何菜品大图
                            </div>
                          ) : (
                            <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                              {diagnosticData.files.map((file: any, idx: number) => {
                                const sizeInKB = file.size / 1024;
                                const isLarge = sizeInKB > 500;
                                const isHuge = sizeInKB > 1500;
                                return (
                                  <div
                                    key={idx}
                                    className="p-2.5 bg-zinc-900/40 border border-zinc-800/60 hover:bg-zinc-900/70 rounded-xl flex items-center justify-between gap-3 transition-colors"
                                  >
                                    <div className="min-w-0 flex-1">
                                      <p className="font-mono text-[11px] text-zinc-300 truncate" title={file.path}>
                                        {file.path}
                                      </p>
                                      <div className="flex items-center gap-1.5 mt-1 text-[10px] text-zinc-500">
                                        <span>大小: </span>
                                        <span className={`font-mono font-semibold ${isHuge ? "text-red-500" : isLarge ? "text-amber-500" : "text-zinc-400"}`}>
                                          {sizeInKB > 1024 ? `${(sizeInKB / 1024).toFixed(2)} MB` : `${sizeInKB.toFixed(1)} KB`}
                                        </span>
                                        {isHuge && (
                                          <span className="bg-red-500/10 text-red-400 px-1 rounded text-[9px] font-bold border border-red-500/20">
                                            极大
                                          </span>
                                        )}
                                        {!isHuge && isLarge && (
                                          <span className="bg-amber-500/10 text-amber-400 px-1 rounded text-[9px] font-bold border border-amber-500/20">
                                            较大
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                    
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteStorageFile(file.path)}
                                      className="p-1.5 hover:bg-red-500/10 hover:text-red-400 text-zinc-500 rounded-lg transition-colors shrink-0"
                                      title="从云存储彻底删除"
                                    >
                                      <Trash2 size={14} />
                                    </button>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-6 text-zinc-500 gap-2">
                        <button
                          type="button"
                          onClick={runDiagnostics}
                          className="bg-zinc-900 border border-zinc-700 hover:border-orange-500 hover:text-orange-400 text-white font-semibold py-2 px-4 rounded-xl transition-colors text-xs flex items-center gap-1.5"
                        >
                          <RefreshCw size={14} />
                          开始存储空间诊断与扫描
                        </button>
                      </div>
                    )}
                  </div>
                </>
              )}
              {activeTab === "menu" && (
                <>
                  {/* Add Dish Settings */}
                  <form
                    onSubmit={handleAddDish}
                    className="p-4 bg-zinc-950 rounded-2xl border border-zinc-800/50"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                        <Plus size={20} className="text-orange-500" />{" "}
                        添加新菜品
                      </h3>
                      <button
                        type="button"
                        onClick={handleAITranslate}
                        disabled={isTranslating}
                        className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 bg-zinc-900 border border-zinc-700 hover:border-orange-500 hover:text-orange-400 rounded-lg transition-colors text-zinc-300 disabled:opacity-50"
                      >
                        {isTranslating ? (
                          <Loader2 size={14} className="animate-spin" />
                        ) : (
                          <Sparkles size={14} />
                        )}
                        一键 AI 翻译
                      </button>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-medium text-zinc-400 mb-1">
                          选择分类
                        </label>
                        <select
                          value={selectedCategory}
                          onChange={(e) => setSelectedCategory(e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                        >
                          {categories.map((cat) => (
                            <option key={cat.id} value={cat.id}>
                              {cat.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="col-span-1 sm:col-span-2">
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            图片 URL 或 上传本地图片 *
                          </label>
                          <div className="flex gap-2 mb-2">
                            <input
                              required
                              type="text"
                              value={newDish.image}
                              onChange={(e) =>
                                setNewDish({
                                  ...newDish,
                                  image: e.target.value,
                                })
                              }
                              placeholder="输入图片 URL 或点击右侧上传"
                              className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white"
                            />
                            <label className="flex items-center justify-center bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-xl px-4 cursor-pointer transition-colors text-sm font-semibold text-zinc-300">
                              {isUploading ? (
                                <>
                                  <Loader2
                                    size={14}
                                    className="animate-spin mr-1"
                                  />{" "}
                                  上传中
                                </>
                              ) : (
                                <span>上传图片</span>
                              )}
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={async (e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    try {
                                      setIsUploading(true);
                                      const compressed =
                                        await compressImage(file);
                                      if (isCloudConnected) {
                                        const publicUrl =
                                          await uploadBase64ToStorage(
                                            compressed,
                                            "dishes",
                                          );
                                        setNewDish((prev) => ({
                                          ...prev,
                                          image: publicUrl,
                                        }));
                                      } else {
                                        setNewDish((prev) => ({
                                          ...prev,
                                          image: compressed,
                                        }));
                                      }
                                    } catch (err: any) {
                                      console.error(
                                        "Image upload failed:",
                                        err,
                                      );
                                      alert(err.message || "上传失败");
                                    } finally {
                                      setIsUploading(false);
                                    }
                                  }
                                }}
                              />
                            </label>
                          </div>
                          {newDish.image &&
                            newDish.image.startsWith("data:image") && (
                              <button
                                type="button"
                                onClick={handleAIEnhanceImage}
                                disabled={isEnhancing}
                                className="w-full flex items-center justify-center gap-2 text-xs font-semibold px-4 py-2 mt-2 bg-zinc-900 border border-orange-500/50 hover:bg-orange-500/10 text-orange-400 rounded-xl transition-colors disabled:opacity-50"
                              >
                                {isEnhancing ? (
                                  <Loader2 size={14} className="animate-spin" />
                                ) : (
                                  <Sparkles size={14} />
                                )}
                                AI 一键美化图片 (统一菜单风格)
                              </button>
                            )}
                          {newDish.image && (
                            <div className="mt-3 relative w-full h-40 sm:h-48 rounded-xl border border-zinc-800 overflow-hidden bg-zinc-900 group">
                              <img
                                src={newDish.image}
                                alt="Preview"
                                className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-700"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-3 pointer-events-none">
                                <span className="text-[10px] sm:text-xs text-zinc-300 font-medium flex items-center gap-1.5">
                                  <ImageIcon size={14} /> 实时外观预览 (Preview)
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            价格 *
                          </label>
                          <div className="flex gap-2">
                            <input
                              required
                              type="text"
                              placeholder="28"
                              value={newDish.price}
                              onChange={(e) =>
                                setNewDish({
                                  ...newDish,
                                  price: e.target.value,
                                })
                              }
                              className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white"
                            />
                            <select
                              value={currency}
                              onChange={(e) => setCurrency(e.target.value)}
                              className="w-24 bg-zinc-900 border border-zinc-800 rounded-xl px-2 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
                            >
                              <option value="MAD">MAD (迪拉姆)</option>
                              <option value="€">€</option>
                              <option value="$">$</option>
                              <option value="¥">¥</option>
                              <option value="£">£</option>
                              <option value="none">无标志</option>
                            </select>
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            库存数量 (留空为无限制) / Stock Limit
                          </label>
                          <input
                            type="number"
                            min="0"
                            placeholder="例如：50"
                            value={newDish.stock}
                            onChange={(e) =>
                              setNewDish({
                                ...newDish,
                                stock: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white"
                          />
                        </div>

                        <div className="col-span-1 sm:col-span-2">
                          <label className="block text-xs font-medium text-zinc-400 mb-2">
                            过敏原信息 / Allergens
                          </label>
                          <div className="flex flex-wrap gap-2">
                            {ALLERGEN_OPTIONS.map((allergen) => {
                              const isSelected = newDish.allergens.includes(
                                allergen.id,
                              );
                              return (
                                <button
                                  type="button"
                                  key={allergen.id}
                                  onClick={() => {
                                    setNewDish((prev) => ({
                                      ...prev,
                                      allergens: isSelected
                                        ? prev.allergens.filter(
                                            (a) => a !== allergen.id,
                                          )
                                        : [...prev.allergens, allergen.id],
                                    }));
                                  }}
                                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                                    isSelected
                                      ? "bg-orange-500/20 border-orange-500 text-orange-400"
                                      : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700"
                                  }`}
                                >
                                  <span>{allergen.icon}</span>
                                  <span>{allergen.label}</span>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        <div className="col-span-2 mt-2 border-t border-zinc-800 pt-2 text-xs font-bold text-zinc-500">
                          多语言内容 / Multi-language Content
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            菜品名称 (中) *
                          </label>
                          <input
                            required
                            type="text"
                            value={newDish.title}
                            onChange={(e) =>
                              setNewDish({ ...newDish, title: e.target.value })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            描述 (中)
                          </label>
                          <textarea
                            rows={2}
                            value={newDish.description}
                            onChange={(e) =>
                              setNewDish({
                                ...newDish,
                                description: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white resize-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            Name (EN)
                          </label>
                          <input
                            type="text"
                            value={newDish.enTitle}
                            onChange={(e) =>
                              setNewDish({
                                ...newDish,
                                enTitle: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            Description (EN)
                          </label>
                          <textarea
                            rows={2}
                            value={newDish.enDescription}
                            onChange={(e) =>
                              setNewDish({
                                ...newDish,
                                enDescription: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white resize-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            Nom (FR)
                          </label>
                          <input
                            type="text"
                            value={newDish.frTitle}
                            onChange={(e) =>
                              setNewDish({
                                ...newDish,
                                frTitle: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            Description (FR)
                          </label>
                          <textarea
                            rows={2}
                            value={newDish.frDescription}
                            onChange={(e) =>
                              setNewDish({
                                ...newDish,
                                frDescription: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white resize-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            الاسم (AR)
                          </label>
                          <input
                            type="text"
                            value={newDish.arTitle}
                            onChange={(e) =>
                              setNewDish({
                                ...newDish,
                                arTitle: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white text-right"
                            dir="auto"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            الوصف (AR)
                          </label>
                          <textarea
                            rows={2}
                            value={newDish.arDescription}
                            onChange={(e) =>
                              setNewDish({
                                ...newDish,
                                arDescription: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white resize-none text-right"
                            dir="auto"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            الاسم (MA)
                          </label>
                          <input
                            type="text"
                            value={newDish.maTitle}
                            onChange={(e) =>
                              setNewDish({
                                ...newDish,
                                maTitle: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white text-right"
                            dir="auto"
                            placeholder="Moroccan Arabic (Darija)"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-zinc-400 mb-1">
                            الوصف (MA)
                          </label>
                          <textarea
                            rows={2}
                            value={newDish.maDescription}
                            onChange={(e) =>
                              setNewDish({
                                ...newDish,
                                maDescription: e.target.value,
                              })
                            }
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-white resize-none text-right"
                            dir="auto"
                            placeholder="Moroccan Arabic (Darija)"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl px-4 py-3 transition-colors mt-4"
                      >
                        确认添加菜品
                      </button>
                    </div>
                  </form>
                </>
              )}

              {activeTab === "inventory" && (
                <InventoryManager
                  menuCategories={categories}
                  onUpdateCategories={setCategories}
                />
              )}
            </div>
          </div>
        )}
      </div>

      <SupabaseSetupModal
        isOpen={isSupabaseSetupOpen}
        onClose={() => setIsSupabaseSetupOpen(false)}
      />

      {checkoutOrder && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto touch-pan-y"
          style={{ zIndex: 9999 }}
        >
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-3xl flex flex-col md:flex-row shadow-2xl max-h-[90dvh] my-auto overflow-y-auto custom-scrollbar">
            {/* Left Column: Order Summary & Inputs */}
            <div className="flex-1 p-4 sm:p-6 flex flex-col min-h-0 overflow-y-auto custom-scrollbar">
              <h3 className="text-xl font-bold text-white mb-4">
                订单结账 (Checkout)
              </h3>
              <div className="space-y-4 mb-6 flex-1">
                <div>
                  <label className="block text-sm font-semibold text-zinc-400 mb-1">
                    订单总金额 (Total Amount)
                  </label>
                  <div className="text-2xl font-bold text-white">
                    {currency} {checkoutOrder.total}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-zinc-400 mb-2">
                    结算方式 (Payment Method)
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                    {[
                      { id: "微信支付", label: "微信支付", icon: "💬" },
                      { id: "现金", label: "现金", icon: "💵" },
                      { id: "POS机", label: "POS刷卡", icon: "💳" },
                      { id: "支付宝", label: "支付宝", icon: "📱" },
                      { id: "其他", label: "其他", icon: "✨" },
                    ].map((pm) => (
                      <button
                        key={pm.id}
                        type="button"
                        onClick={() => setCheckoutPaymentMethod(pm.id)}
                        className={`px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all border flex flex-col items-center justify-center gap-1 ${
                          checkoutPaymentMethod === pm.id
                            ? "bg-orange-600 text-white border-orange-500 shadow-md shadow-orange-500/20"
                            : "bg-zinc-800/80 text-zinc-300 border-zinc-700 hover:bg-zinc-700"
                        }`}
                      >
                        <span>{pm.icon}</span>
                        <span>{pm.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div
                  className={`p-3 rounded-xl border transition-all ${
                    activeNumpadField === "discount"
                      ? "border-orange-500 bg-orange-500/10 shadow-sm"
                      : "border-zinc-800 bg-zinc-800/40"
                  }`}
                  onClick={() => setActiveNumpadField("discount")}
                >
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm font-semibold text-zinc-300 flex items-center gap-1.5">
                      🏷️ 打折/优惠额度 (Discount)
                    </label>
                    <div className="flex bg-zinc-900 border border-zinc-700 p-0.5 rounded-lg text-xs font-semibold">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCheckoutDiscountMode("amount");
                          setCheckoutDiscountStr("0");
                          setActiveNumpadField("discount");
                        }}
                        className={`px-2.5 py-1 rounded-md transition-all ${
                          checkoutDiscountMode === "amount"
                            ? "bg-orange-600 text-white shadow-sm"
                            : "text-zinc-400 hover:text-white"
                        }`}
                      >
                        立减金额 (￥)
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCheckoutDiscountMode("rate");
                          setCheckoutDiscountStr("8.5");
                          setActiveNumpadField("discount");
                        }}
                        className={`px-2.5 py-1 rounded-md transition-all ${
                          checkoutDiscountMode === "rate"
                            ? "bg-orange-600 text-white shadow-sm"
                            : "text-zinc-400 hover:text-white"
                        }`}
                      >
                        折率/几折 (折)
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mb-2">
                    <div className="relative flex-1">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 font-bold text-sm">
                        {checkoutDiscountMode === "amount" ? "￥" : "折"}
                      </span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={checkoutDiscountStr}
                        onChange={(e) => {
                          setCheckoutDiscountStr(e.target.value);
                        }}
                        onFocus={() => setActiveNumpadField("discount")}
                        placeholder={checkoutDiscountMode === "amount" ? "输入立减金额 (如 15)" : "输入折扣率 (如 8.8)"}
                        className="w-full bg-zinc-950 border border-zinc-700 focus:border-orange-500 rounded-xl pl-8 pr-3 py-2 text-lg font-bold text-white outline-none transition-colors"
                      />
                    </div>
                  </div>

                  {checkoutDiscountMode === "rate" && (
                    <div className="text-xs text-orange-400 font-medium mb-2 bg-orange-500/10 px-2 py-1 rounded border border-orange-500/20">
                      当前为 {rawDiscountNum > 0 ? (rawDiscountNum > 10 ? (rawDiscountNum / 10).toFixed(1) : rawDiscountNum) : 10} 折，优惠折算立减 {currency} {parsedDiscount.toFixed(2)}
                    </div>
                  )}

                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {[
                      { label: "9折", mode: "rate", val: "9" },
                      { label: "8.5折", mode: "rate", val: "8.5" },
                      { label: "8折", mode: "rate", val: "8" },
                      { label: "半价(5折)", mode: "rate", val: "5" },
                      { label: "免单", mode: "amount", val: String(checkoutOrder.total || 0) },
                    ].map((d) => (
                      <button
                        key={d.label}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCheckoutDiscountMode(d.mode as any);
                          setCheckoutDiscountStr(d.val);
                          setActiveNumpadField("received");
                        }}
                        className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 active:scale-95 text-xs font-semibold text-zinc-200 rounded-lg transition-all border border-zinc-700"
                      >
                        {d.label}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        const val = prompt(
                          "请输入自定义打折额度：\n- 输入折扣率（如 8.8 表示 8.8折）\n- 或输入立减金额（如 20 表示减免 20 元）",
                          checkoutDiscountStr || "8.5"
                        );
                        if (val !== null && val.trim() !== "") {
                          const trimmed = val.trim();
                          const num = parseFloat(trimmed);
                          if (!isNaN(num)) {
                            if (num > 0 && num < 10) {
                              setCheckoutDiscountMode("rate");
                              setCheckoutDiscountStr(trimmed);
                            } else {
                              setCheckoutDiscountMode("amount");
                              setCheckoutDiscountStr(trimmed);
                            }
                            setActiveNumpadField("received");
                          }
                        }
                      }}
                      className="px-2.5 py-1 bg-orange-600/20 hover:bg-orange-600/30 text-orange-400 active:scale-95 text-xs font-semibold rounded-lg transition-all border border-orange-500/30 flex items-center gap-1"
                    >
                      ✏️ 自定义打折
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-zinc-400 mb-1">
                    折后应收 (After Discount)
                  </label>
                  <div className="text-xl font-bold text-orange-500">
                    {currency}{" "}
                    {Math.max(
                      0,
                      (checkoutOrder.total || 0) - parsedDiscount,
                    ).toFixed(2)}
                  </div>
                </div>

                <div
                  className={`p-3 rounded-xl border transition-all ${
                    activeNumpadField === "received"
                      ? "border-orange-500 bg-orange-500/10 shadow-sm"
                      : "border-zinc-800 bg-zinc-800/40"
                  }`}
                  onClick={() => setActiveNumpadField("received")}
                >
                  <label className="block text-sm font-semibold text-zinc-300 mb-1">
                    💵 顾客支付金额 (Amount Received)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 font-bold text-sm">
                      ￥
                    </span>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={checkoutReceivedStr}
                      onChange={(e) => setCheckoutReceivedStr(e.target.value)}
                      onFocus={() => setActiveNumpadField("received")}
                      placeholder="0.00"
                      className="w-full bg-zinc-950 border border-zinc-700 focus:border-orange-500 rounded-xl pl-8 pr-3 py-2 text-xl font-bold text-white outline-none transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-zinc-400 mb-1">
                    找零 (Change)
                  </label>
                  <div className="text-xl font-bold text-green-500">
                    {currency}{" "}
                    {Math.max(
                      0,
                      parsedReceived -
                        Math.max(
                          0,
                          (checkoutOrder.total || 0) - parsedDiscount,
                        ),
                    ).toFixed(2)}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 justify-end whitespace-nowrap pt-4 border-t border-zinc-800">
                <button
                  onClick={() => setCheckoutOrder(null)}
                  className="px-4 py-3 text-sm font-semibold text-zinc-300 hover:text-white hover:bg-zinc-800 rounded-xl transition-colors border border-transparent"
                >
                  取消 (Cancel)
                </button>
                <button
                  onClick={async () => {
                    try {
                      const finalTotalVal = Math.max(0, (checkoutOrder.total || 0) - parsedDiscount);
                      const changeVal = Math.max(0, parsedReceived - finalTotalVal);
                      const targetId = checkoutOrder._id || checkoutOrder.id;
                      await api.updateOrder(
                        targetId,
                        {
                          status: "completed",
                          paymentMethod: checkoutPaymentMethod || "微信支付",
                          discountAmount: parsedDiscount,
                          receivedAmount: parsedReceived,
                          changeAmount: changeVal,
                          finalTotal: finalTotalVal,
                          completedAt: new Date().toISOString()
                        }
                      );
                      setCheckoutOrder(null);
                    } catch (e) {
                      console.error("Failed to complete order:", e);
                      alert("结账保存失败 (Failed to complete order)");
                    }
                  }}
                  className="px-6 py-3 text-sm font-semibold text-white bg-green-600 hover:bg-green-700 shadow-lg shadow-green-500/20 rounded-xl transition-colors"
                >
                  完成结账 (Complete)
                </button>
              </div>
            </div>

            {/* Right Column: Numpad */}
            <div className="w-full md:w-[320px] bg-zinc-950 p-4 sm:p-6 flex items-center justify-center border-t md:border-t-0 md:border-l border-zinc-800">
              <div className="grid grid-cols-3 gap-2 sm:gap-3 w-full max-w-[280px] md:max-w-none mx-auto">
                {numpadKeys.map((key) => (
                  <button
                    key={key}
                    onClick={() => handleNumpadInput(key)}
                    className={`h-12 sm:h-16 rounded-xl sm:rounded-2xl text-lg sm:text-xl font-bold transition-colors shadow-sm flex items-center justify-center
                      ${
                        key === "C"
                          ? "bg-red-500/10 text-red-500 hover:bg-red-500/20"
                          : key === "⌫"
                            ? "bg-zinc-800 text-zinc-300 hover:bg-zinc-700"
                            : "bg-zinc-800 text-white hover:bg-zinc-700"
                      }
                      active:scale-95`}
                  >
                    {key}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {confirmDialog && confirmDialog.isOpen && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4"
          style={{ zIndex: 9999 }}
        >
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-sm w-full p-6 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4">
              {confirmDialog.isAlert ? "提示 (Alert)" : "确认操作 (Confirm)"}
            </h3>
            <p className="text-sm text-zinc-300 mb-6 whitespace-pre-wrap">
              {confirmDialog.message}
            </p>
            <div className="flex gap-3 justify-end whitespace-nowrap">
              {!confirmDialog.isAlert && (
                <button
                  onClick={() => setConfirmDialog(null)}
                  className="px-4 py-2 text-sm font-semibold text-zinc-300 hover:text-white hover:bg-zinc-800 rounded-xl transition-colors border border-transparent"
                >
                  取消 (Cancel)
                </button>
              )}
              <button
                onClick={confirmDialog.onConfirm}
                className={`px-4 py-2 text-sm font-semibold text-white rounded-xl transition-colors shadow-lg ${confirmDialog.isAlert ? "bg-blue-600 hover:bg-blue-700 shadow-blue-500/20" : "bg-red-600 hover:bg-red-700 shadow-red-500/20"}`}
              >
                确认 (Confirm)
              </button>
            </div>
          </div>
        </div>
      )}

      {promptDialog && promptDialog.isOpen && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4"
          style={{ zIndex: 9999 }}
        >
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-sm w-full p-6 shadow-2xl text-left">
            <h3 className="text-xl font-bold text-white mb-4">
              修改内容 (Edit)
            </h3>
            <p className="text-sm text-zinc-300 mb-4 whitespace-pre-wrap">
              {promptDialog.message}
            </p>
            <input
              type="text"
              value={promptValue}
              onChange={(e) => setPromptValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  promptDialog.onConfirm(promptValue);
                } else if (e.key === "Escape") {
                  setPromptDialog(null);
                }
              }}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white mb-6 focus:outline-none focus:border-orange-500 transition-colors"
              autoFocus
            />
            <div className="flex gap-3 justify-end whitespace-nowrap">
              <button
                onClick={() => setPromptDialog(null)}
                className="px-4 py-2 text-sm font-semibold text-zinc-300 hover:text-white hover:bg-zinc-800 rounded-xl transition-colors border border-transparent"
              >
                取消 (Cancel)
              </button>
              <button
                onClick={() => promptDialog.onConfirm(promptValue)}
                className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-lg shadow-blue-500/20"
              >
                确认 (Confirm)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Export Success & Manual Backup Modal */}
      {showExportModal && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          style={{ zIndex: 9999 }}
        >
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-2xl flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <CheckCircle className="text-green-500" size={24} />
                <h3 className="text-lg font-bold text-white">菜单导出成功 (Export Success)</h3>
              </div>
              <button
                onClick={() => setShowExportModal(false)}
                className="text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-zinc-800 transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <p className="text-xs sm:text-sm text-zinc-300 mb-4 leading-relaxed">
              系统已尝试触发文件下载。如果您的浏览器或设备拦截了自动下载，可以直接使用以下按钮再次下载、复制 JSON 备份，或导出 Excel/CSV 菜品列表。
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-4">
              <button
                onClick={handleExportJson}
                className="flex items-center justify-center gap-2 bg-orange-600 hover:bg-orange-500 active:scale-95 text-white font-medium text-sm py-2.5 px-4 rounded-xl transition-all shadow-lg shadow-orange-600/20"
              >
                <DownloadCloud size={18} />
                <span>再次下载 JSON 备份</span>
              </button>

              <button
                onClick={handleCopyJson}
                className={`flex items-center justify-center gap-2 border active:scale-95 font-medium text-sm py-2.5 px-4 rounded-xl transition-all ${
                  copiedSuccess
                    ? "bg-green-600/20 border-green-500 text-green-400"
                    : "bg-zinc-800 border-zinc-700 hover:border-zinc-500 text-zinc-200"
                }`}
              >
                {copiedSuccess ? <Check size={18} /> : <Copy size={18} />}
                <span>{copiedSuccess ? "已成功复制 JSON!" : "复制 JSON 到剪贴板"}</span>
              </button>

              <button
                onClick={handleExportCsv}
                className="col-span-1 sm:col-span-2 flex items-center justify-center gap-2 bg-emerald-700 hover:bg-emerald-600 active:scale-95 text-white font-medium text-sm py-2.5 px-4 rounded-xl transition-all shadow-lg shadow-emerald-700/20"
              >
                <FileSpreadsheet size={18} />
                <span>导出 Excel / CSV 菜品清单表格</span>
              </button>
            </div>

            <div className="flex-1 flex flex-col min-h-0">
              <div className="flex items-center justify-between text-xs text-zinc-400 mb-1">
                <span>备份数据 JSON 预览 (Data Preview):</span>
                <span>{(exportedJsonStr.length / 1024).toFixed(1)} KB</span>
              </div>
              <textarea
                readOnly
                value={exportedJsonStr}
                onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                className="w-full h-32 bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-zinc-400 font-mono focus:outline-none focus:border-orange-500/50 resize-none overflow-y-auto"
              />
            </div>

            <div className="mt-4 pt-3 border-t border-zinc-800 flex justify-end">
              <button
                onClick={() => setShowExportModal(false)}
                className="bg-zinc-800 hover:bg-zinc-700 text-white px-5 py-2 rounded-xl text-sm font-semibold transition-colors"
              >
                关闭 (Close)
              </button>
            </div>
          </div>
        </div>
      )}

      {importProgress && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[250] flex items-center justify-center p-4 animate-fade-in"
          style={{ zIndex: 10000 }}
        >
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-sm w-full p-6 shadow-2xl flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full border-4 border-orange-500/20 border-t-orange-500 animate-spin mb-4" />
            <h3 className="text-lg font-bold text-white mb-2">正在导入备份数据...</h3>
            <p className="text-sm text-zinc-400 whitespace-pre-wrap leading-relaxed">{importProgress}</p>
          </div>
        </div>
      )}
    </div>
  );
}
