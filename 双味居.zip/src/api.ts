import { supabase, isSupabaseConfigured, isSupabaseHealthy, setSupabaseHealthy } from "./supabase";
import { INITIAL_MENU_CATEGORIES, mergeAndOrderCategories } from "./initialData";
import { kvCache } from "./services/kvCache";
import { blobStorage } from "./services/blobStorage";

const SETTINGS_DOC_ID = "global";

const handleSupabaseReadError = (err: any, context: string) => {
  console.warn(`Supabase read notice [${context}]:`, err);
};

const handleSupabaseWriteError = (err: any, context: string) => {
  console.warn(`[Supabase Write Fallback] Notice in [${context}]:`, err?.message || err);
};

const handleSupabaseError = handleSupabaseWriteError;

const KNOWN_COLUMNS: Record<string, string[]> = {
  settings: [
    "id",
    "categories",
    "promotions",
    "bgUrl",
    "restaurantName",
    "welcomeMessage",
    "logoUrl",
    "adminPassword",
    "devicePasswords",
    "securityQuestion",
    "securityAnswer",
    "soundEnabled",
    "layoutStyle",
    "receiptSettings",
    "deletedItemIds",
    "theme"
  ],
  orders: [
    "_id",
    "id",
    "table_no",
    "customerName",
    "customer_name",
    "type",
    "status",
    "total_amount",
    "total",
    "items",
    "timestamp",
    "notes",
    "unprintedNewOrder",
    "unprintedAdditions",
    "createdAt",
    "created_at"
  ],
  tables: [
    "tableNo",
    "key",
    "active",
    "createdAt"
  ],
  inventory_items: [
    "id",
    "name",
    "category",
    "stock",
    "unit",
    "safety_stock",
    "price",
    "updated_at"
  ],
  recipe_boms: [
    "id",
    "menu_item_name",
    "inventory_item_id",
    "dosage",
    "unit"
  ],
  categories: [
    "id",
    "name",
    "sort_order",
    "created_at"
  ],
  menu_items: [
    "id",
    "category_id",
    "name",
    "price",
    "image_url",
    "description",
    "is_available",
    "created_at"
  ],
  order_items: [
    "id",
    "order_id",
    "menu_item_id",
    "name",
    "quantity",
    "unit_price",
    "subtotal"
  ]
};

const tableColumnsCache: Record<string, string[] | null> = {};

async function getTableColumns(tableName: string): Promise<string[] | null> {
  if (tableColumnsCache[tableName]) {
    return tableColumnsCache[tableName];
  }
  if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
    try {
      const { data, error } = await supabase
        .from(tableName)
        .select("*")
        .limit(1)
        .maybeSingle();
      if (data) {
        const cols = Object.keys(data);
        tableColumnsCache[tableName] = cols;
        return cols;
      }
    } catch (e) {
      console.warn(`Failed to discover table columns for ${tableName}:`, e);
    }
  }
  return null;
}

async function filterPayloadByTable(tableName: string, payload: any): Promise<any> {
  const columns = await getTableColumns(tableName) || KNOWN_COLUMNS[tableName];
  if (!columns) return payload;

  const filtered: any = {};
  for (const key of Object.keys(payload)) {
    if (columns.includes(key)) {
      filtered[key] = payload[key];
    }
  }
  return filtered;
}

let quotaExceededListeners: (() => void)[] = [];
export let isQuotaExceeded = false;

export const setQuotaExceeded = (val: boolean) => {
  if (isQuotaExceeded !== val) {
    isQuotaExceeded = val;
    quotaExceededListeners.forEach(cb => cb());
  }
};

export const onQuotaExceededChange = (cb: () => void) => {
  quotaExceededListeners.push(cb);
  return () => {
    quotaExceededListeners = quotaExceededListeners.filter(listener => listener !== cb);
  };
};

export const normalizeOrder = (o: any) => {
  if (!o) return o;
  const normalizedId = String(o.id || o._id || o.orderNumber || Math.random());
  const custName = o.customerName || o.customer_name || "";
  const totalVal = o.total !== undefined ? Number(o.total) : (o.total_amount !== undefined ? Number(o.total_amount) : 0);
  const itemsList = Array.isArray(o.items) ? o.items : [];
  return {
    ...o,
    _id: normalizedId,
    id: normalizedId,
    customerName: custName,
    customer_name: custName,
    table_no: o.table_no || o.tableNo || custName || "A1",
    total: totalVal,
    total_amount: totalVal,
    items: itemsList,
    status: o.status || "pending",
    timestamp: o.timestamp || o.created_at || o.createdAt || new Date().toISOString(),
    unprintedNewOrder: o.unprintedNewOrder !== undefined ? o.unprintedNewOrder : false,
    unprintedAdditions: Array.isArray(o.unprintedAdditions) ? o.unprintedAdditions : []
  };
};

let ordersListeners: ((orders: any[]) => void)[] = [];
let settingsListeners: ((data: any) => void)[] = [];
const broadcastOrdersMemoryCache = new Map<string, any>();

const triggerLocalOrdersChange = async () => {
  if (ordersListeners.length === 0) {
    return;
  }
  let remoteOrders: any[] = [];
  try {
    if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
      const { data, error } = await supabase
        .from("orders")
        .select("*");
      if (error) handleSupabaseReadError(error, "triggerLocalOrdersChange");
      if (data) {
        remoteOrders = data.map(normalizeOrder);
      }
    }
  } catch (e) {
    handleSupabaseReadError(e, "triggerLocalOrdersChange");
  }
  
  const localOrdersStr = localStorage.getItem("local_orders");
  const localOrders = localOrdersStr ? JSON.parse(localOrdersStr) : [];
  
  const mergedMap = new Map<string, any>();
  
  // 1. Remote DB orders
  remoteOrders.forEach((ro: any) => {
    const norm = normalizeOrder(ro);
    if (norm._id) mergedMap.set(String(norm._id), norm);
  });
  
  // 2. Realtime broadcast orders held in memory
  broadcastOrdersMemoryCache.forEach((bo: any) => {
    const norm = normalizeOrder(bo);
    if (norm._id) {
      const existing = mergedMap.get(String(norm._id));
      if (!existing) {
        mergedMap.set(String(norm._id), norm);
      } else {
        const existingTime = new Date(existing.timestamp || 0).getTime();
        const normTime = new Date(norm.timestamp || 0).getTime();
        if (normTime > existingTime) {
          mergedMap.set(String(norm._id), norm);
        }
      }
    }
  });
  
  // 3. Local storage orders
  localOrders.forEach((lo: any) => {
    const norm = normalizeOrder(lo);
    if (norm._id) {
      const existing = mergedMap.get(String(norm._id));
      if (!existing) {
        mergedMap.set(String(norm._id), norm);
      } else {
        const existingTime = new Date(existing.timestamp || 0).getTime();
        const normTime = new Date(norm.timestamp || 0).getTime();
        if (normTime > existingTime) {
          mergedMap.set(String(norm._id), norm);
        }
      }
    }
  });
  
  const sorted = Array.from(mergedMap.values()).sort(
    (a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  );
  
  ordersListeners.forEach(cb => cb(sorted));
};

let tablesListeners: ((tables: any[]) => void)[] = [];

const triggerLocalTablesChange = async () => {
  if (tablesListeners.length === 0) {
    return;
  }
  let remoteTables: any[] = [];
  try {
    if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
      const { data, error } = await supabase
        .from("tables")
        .select("*");
      if (error) throw error;
      if (data) {
        remoteTables = data;
      }
    }
  } catch (e) {
    handleSupabaseReadError(e, "triggerLocalTablesChange");
  }
  
  const localTablesStr = localStorage.getItem("local_tables");
  const localTables = localTablesStr ? JSON.parse(localTablesStr) : [];
  
  const merged = [...remoteTables];
  localTables.forEach((lt: any) => {
    if (!merged.some(rt => rt.tableNo === lt.tableNo)) {
      merged.push(lt);
    }
  });
  
  tablesListeners.forEach(cb => cb(merged));
};

let customerOrderListeners: { customerName: string; callback: (order: any) => void; fetchAndCallback: () => void }[] = [];
let inventoryListeners: (() => void)[] = [];

export const triggerLocalInventoryChange = () => {
  inventoryListeners.forEach(cb => cb());
};

let globalSyncChannel: any = null;

let isRealtimeConnected = false;
export const getIsRealtimeConnected = () => isRealtimeConnected;

export const ensureSyncChannel = () => {
  if (supabase && isSupabaseConfigured && !globalSyncChannel) {
    globalSyncChannel = supabase.channel('restaurant-sync', {
      config: {
        broadcast: { self: true }
      }
    });

    globalSyncChannel
      .on('postgres_changes', { event: '*', schema: 'public', table: 'settings', filter: `id=eq.${SETTINGS_DOC_ID}` }, (payload: any) => {
        if (payload.new) {
          kvCache.set("app_settings", payload.new, 600);
          settingsListeners.forEach(cb => cb(payload.new));
        }
      })
      .on('broadcast', { event: 'settings_changed' }, () => {
        kvCache.invalidate("app_settings");
        api.getSettings().then(data => {
          if (data) settingsListeners.forEach(cb => cb(data));
        });
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, (payload: any) => {
        if (payload.eventType === 'DELETE' && payload.old) {
          const delId = String(payload.old._id || payload.old.id);
          if (delId) {
            broadcastOrdersMemoryCache.delete(delId);
            const localOrdersStr = localStorage.getItem("local_orders");
            if (localOrdersStr) {
              let localOrders = JSON.parse(localOrdersStr);
              localOrders = localOrders.filter((o: any) => String(o._id) !== delId && String(o.id) !== delId);
              localStorage.setItem("local_orders", JSON.stringify(localOrders));
            }
          }
        }
        if (ordersListeners.length > 0) {
          triggerLocalOrdersChange();
        }

        if (payload.eventType === 'INSERT' && payload.new && payload.new.items) {
          api.deductInventoryForOrderItems(payload.new.items);
        }
        
        customerOrderListeners.forEach(listener => {
          const newRecord = payload.new;
          const oldRecord = payload.old;
          const affectedCustomer = (newRecord && (newRecord.customerName || newRecord.customer_name || newRecord.table_no || newRecord.tableNo)) || 
                                   (oldRecord && (oldRecord.customerName || oldRecord.customer_name || oldRecord.table_no || oldRecord.tableNo));
          
          if (!affectedCustomer || affectedCustomer === listener.customerName) {
            listener.fetchAndCallback();
          }
        });
      })
      .on('broadcast', { event: 'orders_changed' }, (evtPayload: any) => {
        const payload = evtPayload?.payload || evtPayload;
        if (payload) {
          if (payload.action === 'delete' && payload.orderId) {
            const delId = String(payload.orderId);
            broadcastOrdersMemoryCache.delete(delId);
            broadcastOrdersMemoryCache.forEach((v, k) => {
              if (String(v._id) === delId || String(v.id) === delId) {
                broadcastOrdersMemoryCache.delete(k);
              }
            });
            const localOrdersStr = localStorage.getItem("local_orders");
            if (localOrdersStr) {
              let localOrders = JSON.parse(localOrdersStr);
              localOrders = localOrders.filter((o: any) => String(o._id) !== delId && String(o.id) !== delId);
              localStorage.setItem("local_orders", JSON.stringify(localOrders));
            }
          } else if (payload.action === 'clear') {
            if (payload.status) {
              broadcastOrdersMemoryCache.forEach((v, k) => {
                if (v.status === payload.status) broadcastOrdersMemoryCache.delete(k);
              });
              const localOrdersStr = localStorage.getItem("local_orders");
              if (localOrdersStr) {
                let localOrders = JSON.parse(localOrdersStr);
                localOrders = localOrders.filter((o: any) => o.status !== payload.status);
                localStorage.setItem("local_orders", JSON.stringify(localOrders));
              }
            } else {
              broadcastOrdersMemoryCache.clear();
              localStorage.setItem("local_orders", JSON.stringify([]));
            }
          } else if (payload.order) {
            const norm = normalizeOrder(payload.order);
            if (norm && norm._id) {
              broadcastOrdersMemoryCache.set(String(norm._id), norm);
              const localOrdersStr = localStorage.getItem("local_orders");
              let localOrders = localOrdersStr ? JSON.parse(localOrdersStr) : [];
              const idx = localOrders.findIndex((o: any) => String(o._id) === String(norm._id) || String(o.id) === String(norm._id));
              if (idx !== -1) {
                localOrders[idx] = norm;
              } else {
                localOrders.push(norm);
              }
              localStorage.setItem("local_orders", JSON.stringify(localOrders));
            }
          }
        }
        if (ordersListeners.length > 0) {
          triggerLocalOrdersChange();
        }
        customerOrderListeners.forEach(listener => {
          listener.fetchAndCallback();
        });
      })
      .on('broadcast', { event: 'tables_changed' }, () => {
        if (tablesListeners.length > 0) {
          triggerLocalTablesChange();
        }
      })
      .on('broadcast', { event: 'inventory_changed' }, () => {
        kvCache.invalidate("inventory_items");
        kvCache.invalidate("recipe_boms");
        triggerLocalInventoryChange();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tables' }, () => {
        if (tablesListeners.length > 0) {
          triggerLocalTablesChange();
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'inventory_items' }, () => {
        kvCache.invalidate("inventory_items");
        triggerLocalInventoryChange();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'recipe_boms' }, () => {
        kvCache.invalidate("recipe_boms");
        triggerLocalInventoryChange();
      })
      .subscribe((status: string) => {
        console.log(`Supabase unified sync channel status: ${status}`);
        if (status === 'SUBSCRIBED') {
          isRealtimeConnected = true;
        } else if (status === 'CLOSED' || status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          isRealtimeConnected = false;
        }
      });
  }
};

// Start connection immediately on module load
ensureSyncChannel();

// 自动检测并补全 Supabase 生产环境数据库空表
setTimeout(() => {
  api.seedProductionDatabase(false).catch(err => {
    console.warn("[Auto-Seed] Startup check notice:", err);
  });
}, 1000);

export const triggerBroadcast = (event: string, payload: any = {}) => {
  ensureSyncChannel();
  if (globalSyncChannel) {
    globalSyncChannel.send({
      type: 'broadcast',
      event,
      payload
    }).catch((err: any) => {
      console.warn(`Failed to send broadcast for ${event}:`, err);
    });
  }
};

async function ensureNoBase64Image(imageUrl: string | undefined, folder: string): Promise<string> {
  if (!imageUrl || typeof imageUrl !== "string") return "";
  if (imageUrl.startsWith("data:image/")) {
    try {
      return await api.uploadBlob(imageUrl, folder);
    } catch (e) {
      console.warn(`[Supabase Storage] Failed to upload base64 image to ${folder}, removing raw base64 to prevent database bloat:`, e);
      return ""; // Protect Postgres JSON fields from multi-megabyte base64 bloat
    }
  }
  return imageUrl;
}

export const api = {
  getSettings: async () => {
    // 1. 尝试从腾讯云 / 本地 KV 缓存快速读取
    const cachedKvSettings = await kvCache.get<any>("app_settings");
    if (cachedKvSettings) {
      if (cachedKvSettings.categories) {
        cachedKvSettings.categories = mergeAndOrderCategories(cachedKvSettings.categories, INITIAL_MENU_CATEGORIES);
      }
      return cachedKvSettings;
    }

    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { data, error } = await supabase
          .from("settings")
          .select("*")
          .eq("id", SETTINGS_DOC_ID)
          .maybeSingle();

        if (error) throw error;
        if (data) {
          tableColumnsCache["settings"] = Object.keys(data);
          if (data.categories) {
            data.categories = mergeAndOrderCategories(data.categories, INITIAL_MENU_CATEGORIES);
          }
          // 写入 KV 缓存
          kvCache.set("app_settings", data, 600);
          return data;
        }
      }
    } catch (e) {
      handleSupabaseReadError(e, "getSettings");
    }

    // Local fallback
    const cachedCategories = localStorage.getItem("menuCategories");
    const cachedPromotions = localStorage.getItem("menuPromotions");
    const cachedBgUrl = localStorage.getItem("menuBgUrl");
    const cachedRestaurantName = localStorage.getItem("menuRestaurantName");
    const cachedWelcomeMessage = localStorage.getItem("menuWelcomeMessage");
    const cachedLogoUrl = localStorage.getItem("menuLogoUrl");
    const cachedAdminPassword = localStorage.getItem("menuAdminPassword");
    const cachedDevicePasswords = localStorage.getItem("menuDevicePasswords");
    const cachedSecurityQuestion = localStorage.getItem("menuSecurityQuestion");
    const cachedSecurityAnswer = localStorage.getItem("menuSecurityAnswer");
    const cachedSoundEnabled = localStorage.getItem("menuSoundEnabled");
    const cachedLayoutStyle = localStorage.getItem("menuLayoutStyle");
    const cachedReceiptSettings = localStorage.getItem("menuReceiptSettings");
    const cachedDeletedItemIds = localStorage.getItem("menuDeletedItemIds");
    const cachedThemeMode = localStorage.getItem("menuThemeMode");

    return {
      categories: cachedCategories ? mergeAndOrderCategories(JSON.parse(cachedCategories), INITIAL_MENU_CATEGORIES) : INITIAL_MENU_CATEGORIES,
      promotions: cachedPromotions ? JSON.parse(cachedPromotions) : [],
      bgUrl: cachedBgUrl || "",
      restaurantName: cachedRestaurantName || "炙·双味居",
      welcomeMessage: cachedWelcomeMessage || "Premium Charcoal BBQ",
      logoUrl: cachedLogoUrl || "",
      adminPassword: cachedAdminPassword || "admin123",
      devicePasswords: cachedDevicePasswords ? JSON.parse(cachedDevicePasswords) : [],
      securityQuestion: cachedSecurityQuestion || "",
      securityAnswer: cachedSecurityAnswer || "",
      soundEnabled: cachedSoundEnabled ? cachedSoundEnabled === "true" : true,
      layoutStyle: cachedLayoutStyle || "grid",
      receiptSettings: cachedReceiptSettings ? JSON.parse(cachedReceiptSettings) : {},
      deletedItemIds: cachedDeletedItemIds ? JSON.parse(cachedDeletedItemIds) : [],
      theme: (cachedThemeMode as "midnight" | "light") || "midnight"
    };
  },

  subscribeToSettings: (callback: (data: any) => void) => {
    settingsListeners.push(callback);
    
    let lastJson = "";
    const handleData = (data: any) => {
      if (!data) return;
      const currentJson = JSON.stringify(data);
      if (currentJson !== lastJson) {
        lastJson = currentJson;
        callback(data);
        // Sync to other local listeners
        settingsListeners.forEach(cb => {
          if (cb !== callback) cb(data);
        });
      }
    };

    // Immediately fetch
    api.getSettings().then(handleData).catch(() => {});

    // Ensure the unified channel is running
    ensureSyncChannel();

    // Active polling fallback (ONLY polls if Supabase is unhealthy or unconfigured to sync local tabs)
    // Avoids polling the database if Supabase is connected and healthy
    const pollInterval = setInterval(() => {
      if (!isSupabaseConfigured || !isSupabaseHealthy) {
        api.getSettings().then(handleData).catch(() => {});
      }
    }, 5000);

    // Passive refresh on window focus / tab visible (extremely cheap, only runs when user actively opens the app)
    let lastFetchTime = 0;
    const handleFocus = () => {
      const now = Date.now();
      if (now - lastFetchTime < 30000) return; // 30s throttle
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        lastFetchTime = now;
        api.getSettings().then(handleData).catch(() => {});
      }
    };
    window.addEventListener("focus", handleFocus);
    document.addEventListener("visibilitychange", handleFocus);

    return () => {
      settingsListeners = settingsListeners.filter(l => l !== callback);
      clearInterval(pollInterval);
      window.removeEventListener("focus", handleFocus);
      document.removeEventListener("visibilitychange", handleFocus);
    };
  },

  getOrders: async () => {
    try {
      let remoteOrders: any[] = [];
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { data, error } = await supabase
          .from("orders")
          .select("*");
        if (error) throw error;
        if (data) {
          remoteOrders = data.map(normalizeOrder);
        }
      }
      
      const localOrdersStr = localStorage.getItem("local_orders");
      const localOrders = localOrdersStr ? JSON.parse(localOrdersStr) : [];
      
      const mergedMap = new Map<string, any>();
      remoteOrders.forEach((ro: any) => {
        const norm = normalizeOrder(ro);
        if (norm._id) mergedMap.set(String(norm._id), norm);
      });
      localOrders.forEach((lo: any) => {
        const norm = normalizeOrder(lo);
        if (norm._id) {
          const existing = mergedMap.get(String(norm._id));
          if (!existing) {
            mergedMap.set(String(norm._id), norm);
          } else {
            const existingTime = new Date(existing.timestamp || 0).getTime();
            const normTime = new Date(norm.timestamp || 0).getTime();
            if (normTime > existingTime) {
              mergedMap.set(String(norm._id), norm);
            }
          }
        }
      });
      
      return Array.from(mergedMap.values()).sort(
        (a: any, b: any) =>
          new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime(),
      );
    } catch (e: any) {
      handleSupabaseReadError(e, "getOrders");
      const localOrdersStr = localStorage.getItem("local_orders");
      const localOrders = localOrdersStr ? JSON.parse(localOrdersStr) : [];
      return localOrders.map(normalizeOrder).sort(
        (a: any, b: any) =>
          new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime(),
      );
    }
  },

  subscribeToOrders: (callback: (orders: any[]) => void) => {
    ordersListeners.push(callback);
    
    let lastJson = "";
    const fetchAndTrigger = async () => {
      try {
        const currentOrders = await api.getOrders();
        const currentJson = JSON.stringify(currentOrders);
        if (currentJson !== lastJson) {
          lastJson = currentJson;
          callback(currentOrders);
          ordersListeners.forEach(cb => {
            if (cb !== callback) cb(currentOrders);
          });
        }
      } catch (e) {
        console.warn("Failed to fetch orders in fallback:", e);
      }
    };

    fetchAndTrigger();
    ensureSyncChannel();

    const pollInterval = setInterval(() => {
      // 智能自适应策略（额度防护）：
      // 1. 如果页面处于后台 (document.hidden)，彻底不进行 API 轮询
      // 2. 如果 WebSocket 已稳定连通 (isRealtimeConnected === true)，通过长连接实时推送，减少 95%+ 数据库轮询，仅保留 60 秒极低频安全心跳
      // 3. 只有当 WebSocket 断线 (isRealtimeConnected === false) 时，才启动 10 秒兜底轮询
      if (document.hidden) return;

      if (!isRealtimeConnected) {
        fetchAndTrigger();
      } else {
        const now = Date.now();
        if (now - lastFetchTime > 60000) {
          lastFetchTime = now;
          fetchAndTrigger();
        }
      }
    }, 10000);

    let lastFetchTime = 0;
    const handleFocus = () => {
      const now = Date.now();
      if (now - lastFetchTime < 10000) return;
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        lastFetchTime = now;
        fetchAndTrigger();
      }
    };
    window.addEventListener("focus", handleFocus);
    document.addEventListener("visibilitychange", handleFocus);

    return () => {
      ordersListeners = ordersListeners.filter(l => l !== callback);
      clearInterval(pollInterval);
      window.removeEventListener("focus", handleFocus);
      document.removeEventListener("visibilitychange", handleFocus);
    };
  },

  verifyOrderValidity: async (customerNameOrTable: string): Promise<{ hasActiveOrder: boolean; activeOrder: any | null }> => {
    const custName = customerNameOrTable || "A1";
    if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
      try {
        const cols = (await getTableColumns("orders")) || KNOWN_COLUMNS["orders"] || [];
        let query = supabase.from("orders").select("*").neq("status", "completed").neq("status", "cancelled");
        const validMatchCols = ["table_no", "customer_name", "customerName", "tableNo"].filter(c => cols.includes(c));
        if (validMatchCols.length > 0) {
          const orStr = validMatchCols.map(c => `${c}.eq.${custName}`).join(",");
          query = query.or(orStr);
        }
        const { data, error } = await query;
        if (!error && data) {
          if (data.length === 0) {
            // DB confirms NO active order -> Clear stale active local order for this customer/table
            const localOrdersStr = localStorage.getItem("local_orders");
            if (localOrdersStr) {
              let localOrders = JSON.parse(localOrdersStr);
              localOrders = localOrders.filter((o: any) => {
                const matchCust = o.customerName === custName || o.customer_name === custName || o.table_no === custName || o.tableNo === custName;
                return !matchCust || o.status === "completed" || o.status === "cancelled";
              });
              localStorage.setItem("local_orders", JSON.stringify(localOrders));
            }
            broadcastOrdersMemoryCache.forEach((v, k) => {
              const matchCust = v.customerName === custName || v.customer_name === custName || v.table_no === custName || v.tableNo === custName;
              if (matchCust && v.status !== "completed" && v.status !== "cancelled") {
                broadcastOrdersMemoryCache.delete(k);
              }
            });
            return { hasActiveOrder: false, activeOrder: null };
          } else {
            const activeOrder = normalizeOrder(data[0]);
            return { hasActiveOrder: true, activeOrder };
          }
        }
      } catch (e) {
        console.warn("[verifyOrderValidity] server verification failed:", e);
      }
    }
    return { hasActiveOrder: false, activeOrder: null };
  },

  addOrder: async (order: any) => {
    const custName = order.customerName || order.customer_name || "A1";
    const tableNo = order.tableNo || order.table_no || custName || "A1";

    // Server-side active order validity verification before processing
    const verification = await api.verifyOrderValidity(custName);

    const newId = order.id || order._id || "ORD-" + Date.now() + "-" + Math.floor(Math.random() * 1000);
    const sanitizedItems = [];
    if (order.items && Array.isArray(order.items)) {
      for (const item of order.items) {
        const cleanImage = await ensureNoBase64Image(item.image, "order_dishes");
        sanitizedItems.push({ ...item, image: cleanImage });
      }
    }

    const localOrdersStr = localStorage.getItem("local_orders");
    let localOrders = localOrdersStr ? JSON.parse(localOrdersStr) : [];

    let activeLocalIdx = -1;
    if (verification.hasActiveOrder && verification.activeOrder) {
      activeLocalIdx = localOrders.findIndex((o: any) => 
        String(o._id) === String(verification.activeOrder._id) || String(o.id) === String(verification.activeOrder._id)
      );
      if (activeLocalIdx === -1) {
        localOrders.push(verification.activeOrder);
        activeLocalIdx = localOrders.length - 1;
        localStorage.setItem("local_orders", JSON.stringify(localOrders));
      }
    } else {
      // Force clean state: ensure no stale active order matches this table
      localOrders = localOrders.filter((o: any) => {
        const matchCust = o.customerName === custName || o.customer_name === custName || o.table_no === tableNo || o.tableNo === tableNo;
        return !matchCust || o.status === "completed" || o.status === "cancelled";
      });
      localStorage.setItem("local_orders", JSON.stringify(localOrders));
    }

    let fullOrder: any = null;

    if (activeLocalIdx !== -1) {
      // 1. Existing active order -> MERGE items as addition (加菜)
      const existingLocal = localOrders[activeLocalIdx];
      const addedItems = sanitizedItems.map((item: any) => ({ ...item, isAdded: true }));
      const newItems = [...(existingLocal.items || []), ...addedItems];
      const currentUnprinted = existingLocal.unprintedAdditions || [];
      const newUnprinted = [...currentUnprinted, { items: addedItems, timestamp: new Date().toISOString() }];
      const newTotal = Number((Number(existingLocal.total || existingLocal.total_amount || 0) + Number(order.total || 0)).toFixed(2));

      fullOrder = normalizeOrder({
        ...existingLocal,
        items: newItems,
        unprintedAdditions: newUnprinted,
        total: newTotal,
        total_amount: newTotal,
        timestamp: new Date().toISOString(),
        created_at: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        unprintedNewOrder: existingLocal.unprintedNewOrder !== false
      });

      localOrders[activeLocalIdx] = fullOrder;
      localStorage.setItem("local_orders", JSON.stringify(localOrders));

      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        try {
          const dbPayload = await filterPayloadByTable("orders", fullOrder);
          const cols = (await getTableColumns("orders")) || KNOWN_COLUMNS["orders"] || [];
          let queryBuilder = supabase.from("orders").update(dbPayload);
          if (cols.includes("id") && cols.includes("_id")) {
            queryBuilder = queryBuilder.or(`id.eq.${fullOrder.id},_id.eq.${fullOrder.id}`);
          } else if (cols.includes("_id")) {
            queryBuilder = queryBuilder.eq("_id", fullOrder.id);
          } else {
            queryBuilder = queryBuilder.eq("id", fullOrder.id);
          }
          const { error: updateError } = await queryBuilder;
          if (updateError) console.warn("[addOrder] Supabase update error:", updateError);
        } catch (dbErr) {
          console.warn("[addOrder] Supabase update sync failed:", dbErr);
        }
      }
    } else {
      // 2. No active order found (all previous orders were completed or cancelled) -> BRAND NEW ORDER
      fullOrder = normalizeOrder({
        id: newId,
        _id: newId,
        orderNumber: order.orderNumber || ("ORD-" + Math.floor(Math.random() * 1000000)),
        customerName: custName,
        customer_name: custName,
        table_no: tableNo,
        tableNo: tableNo,
        status: order.status || "pending",
        items: sanitizedItems,
        total: Number(order.total || 0),
        total_amount: Number(order.total || 0),
        timestamp: order.timestamp || new Date().toISOString(),
        created_at: order.timestamp || new Date().toISOString(),
        createdAt: order.timestamp || new Date().toISOString(),
        notes: order.notes || "",
        unprintedNewOrder: true,
        unprintedAdditions: order.unprintedAdditions || []
      });

      localOrders.push(fullOrder);
      localStorage.setItem("local_orders", JSON.stringify(localOrders));

      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        try {
          const dbPayload = await filterPayloadByTable("orders", fullOrder);
          const { error: insertError } = await supabase.from("orders").insert(dbPayload);
          if (insertError) console.warn("[addOrder] Supabase insert error:", insertError);
        } catch (dbErr) {
          console.warn("[addOrder] Supabase insert sync failed:", dbErr);
        }
      }
    }

    broadcastOrdersMemoryCache.set(String(fullOrder._id), fullOrder);

    triggerLocalOrdersChange();
    triggerBroadcast('orders_changed', { action: 'upsert', order: fullOrder });
    api.deductInventoryForOrderItems(order.items);
  },

  clearOrders: async (status?: string) => {
    if (status) {
      broadcastOrdersMemoryCache.forEach((v, k) => {
        if (v.status === status) broadcastOrdersMemoryCache.delete(k);
      });
    } else {
      broadcastOrdersMemoryCache.clear();
    }

    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const cols = (await getTableColumns("orders")) || KNOWN_COLUMNS["orders"] || [];
        let queryBuilder = supabase.from("orders").delete();
        if (status) {
          queryBuilder = queryBuilder.eq("status", status);
        } else {
          if (cols.includes("id")) {
            queryBuilder = queryBuilder.neq("id", "keep-none");
          } else if (cols.includes("_id")) {
            queryBuilder = queryBuilder.neq("_id", "keep-none");
          }
        }
        const { error } = await queryBuilder;
        if (error) handleSupabaseError(error, "clearOrders");
      }
    } catch (e: any) {
      handleSupabaseError(e, "clearOrders");
    }

    const localOrdersStr = localStorage.getItem("local_orders");
    if (localOrdersStr) {
      let localOrders = JSON.parse(localOrdersStr);
      if (status) {
        localOrders = localOrders.filter((o: any) => o.status !== status);
      } else {
        localOrders = [];
      }
      localStorage.setItem("local_orders", JSON.stringify(localOrders));
    }
    triggerLocalOrdersChange();
    triggerBroadcast('orders_changed', { action: 'clear', status });
  },

  deleteOrder: async (orderId: string) => {
    const sId = String(orderId);
    broadcastOrdersMemoryCache.delete(sId);
    broadcastOrdersMemoryCache.forEach((v, k) => {
      if (String(v._id) === sId || String(v.id) === sId) {
        broadcastOrdersMemoryCache.delete(k);
      }
    });

    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const cols = (await getTableColumns("orders")) || KNOWN_COLUMNS["orders"] || [];
        let queryBuilder = supabase.from("orders").delete();
        if (cols.includes("id") && cols.includes("_id")) {
          queryBuilder = queryBuilder.or(`id.eq.${orderId},_id.eq.${orderId}`);
        } else if (cols.includes("_id")) {
          queryBuilder = queryBuilder.eq("_id", orderId);
        } else {
          queryBuilder = queryBuilder.eq("id", orderId);
        }
        const { error } = await queryBuilder;
        if (error) handleSupabaseError(error, "deleteOrder");
      }
    } catch (e: any) {
      handleSupabaseError(e, "deleteOrder");
    }

    const localOrdersStr = localStorage.getItem("local_orders");
    if (localOrdersStr) {
      let localOrders = JSON.parse(localOrdersStr);
      localOrders = localOrders.filter((o: any) => String(o._id) !== sId && String(o.id) !== sId);
      localStorage.setItem("local_orders", JSON.stringify(localOrders));
    }
    triggerLocalOrdersChange();
    triggerBroadcast('orders_changed', { action: 'delete', orderId });
  },

  subscribeToCustomerOrder: (customerName: string, callback: (order: any) => void) => {
    let isCancelled = false;
    
    const isMatch = (o: any) => {
      const matchName = o.customerName === customerName || o.customer_name === customerName || o.table_no === customerName || o.tableNo === customerName;
      return matchName && o.status !== "completed" && o.status !== "cancelled";
    };

    const triggerLocalCustomerOrder = () => {
      const memOrder = Array.from(broadcastOrdersMemoryCache.values()).find(isMatch);
      if (memOrder) {
        callback(normalizeOrder(memOrder));
        return true;
      }
      const localOrdersStr = localStorage.getItem("local_orders");
      const localOrders = localOrdersStr ? JSON.parse(localOrdersStr) : [];
      const activeOrder = localOrders.find(isMatch);
      if (activeOrder) {
        callback(normalizeOrder(activeOrder));
        return true;
      }
      return false;
    };
    
    const fetchAndCallback = async () => {
      try {
        if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
          const cols = (await getTableColumns("orders")) || KNOWN_COLUMNS["orders"] || [];
          let query = supabase.from("orders").select("*").neq("status", "completed").neq("status", "cancelled");
          
          const validMatchCols = ["table_no", "customer_name", "customerName", "tableNo"].filter(c => cols.includes(c));
          if (validMatchCols.length > 0) {
            const orStr = validMatchCols.map(c => `${c}.eq.${customerName}`).join(",");
            query = query.or(orStr);
          }

          if (cols.includes("timestamp")) {
            query = query.order("timestamp", { ascending: false });
          } else if (cols.includes("created_at")) {
            query = query.order("created_at", { ascending: false });
          }
          const { data, error } = await query;
          
          if (error) handleSupabaseReadError(error, "subscribeToCustomerOrder");
          if (isCancelled) return;
          
          if (data && data.length > 0) {
            const dbOrder = normalizeOrder(data[0]);
            const localOrdersStr = localStorage.getItem("local_orders");
            const localOrders = localOrdersStr ? JSON.parse(localOrdersStr) : [];
            const localOrder = localOrders.find(isMatch);
            if (localOrder) {
              const normalizedLocal = normalizeOrder(localOrder);
              const dbTime = new Date(dbOrder.timestamp || 0).getTime();
              const localTime = new Date(normalizedLocal.timestamp || 0).getTime();
              if (localTime > dbTime) {
                callback(normalizedLocal);
                return;
              }
            }
            callback(dbOrder);
          } else {
            // DB confirms no active uncompleted order exists for this customer -> Purge stale local cache
            const localOrdersStr = localStorage.getItem("local_orders");
            if (localOrdersStr) {
              let localOrders = JSON.parse(localOrdersStr);
              const filtered = localOrders.filter((o: any) => !isMatch(o));
              if (filtered.length !== localOrders.length) {
                localStorage.setItem("local_orders", JSON.stringify(filtered));
              }
            }
            broadcastOrdersMemoryCache.forEach((v, k) => {
              if (isMatch(v)) {
                broadcastOrdersMemoryCache.delete(k);
              }
            });
            callback(null);
          }
        } else {
          triggerLocalCustomerOrder();
        }
      } catch (e) {
        handleSupabaseReadError(e, "subscribeToCustomerOrder fetchAndCallback");
        triggerLocalCustomerOrder();
      }
    };

    const listenerObj = { customerName, callback, fetchAndCallback };
    customerOrderListeners.push(listenerObj);

    fetchAndCallback();
    ensureSyncChannel();

    return () => {
      isCancelled = true;
      customerOrderListeners = customerOrderListeners.filter(l => l !== listenerObj);
    };
  },

  updateOrder: async (orderId: string, data: any) => {
    const sId = String(orderId);
    if (broadcastOrdersMemoryCache.has(sId)) {
      const prev = broadcastOrdersMemoryCache.get(sId);
      const updated = normalizeOrder({ ...prev, ...data });
      broadcastOrdersMemoryCache.set(sId, updated);
    }

    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const updatePayload = await filterPayloadByTable("orders", {
          ...data,
          timestamp: new Date().toISOString(),
          created_at: new Date().toISOString()
        });

        const cols = (await getTableColumns("orders")) || KNOWN_COLUMNS["orders"] || [];
        let queryBuilder = supabase.from("orders").update(updatePayload);
        if (cols.includes("id") && cols.includes("_id")) {
          queryBuilder = queryBuilder.or(`id.eq.${orderId},_id.eq.${orderId}`);
        } else if (cols.includes("_id")) {
          queryBuilder = queryBuilder.eq("_id", orderId);
        } else {
          queryBuilder = queryBuilder.eq("id", orderId);
        }
        const { error } = await queryBuilder;
        if (error) handleSupabaseError(error, "updateOrder");
      }
    } catch (e: any) {
      handleSupabaseError(e, "updateOrder");
    }

    const localOrdersStr = localStorage.getItem("local_orders");
    if (localOrdersStr) {
      let localOrders = JSON.parse(localOrdersStr);
      const idx = localOrders.findIndex((o: any) => String(o._id) === sId || String(o.id) === sId);
      if (idx !== -1) {
        localOrders[idx] = normalizeOrder({
          ...localOrders[idx],
          ...data,
          timestamp: new Date().toISOString()
        });
        localStorage.setItem("local_orders", JSON.stringify(localOrders));
      }
    }
    triggerLocalOrdersChange();
    triggerBroadcast('orders_changed', { action: 'upsert', orderId, ...data });
  },

  updateOrderStatus: async (orderId: string, status: string) => {
    const sId = String(orderId);
    if (broadcastOrdersMemoryCache.has(sId)) {
      const prev = broadcastOrdersMemoryCache.get(sId);
      const updated = normalizeOrder({ ...prev, status, timestamp: new Date().toISOString() });
      broadcastOrdersMemoryCache.set(sId, updated);
    }

    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const cols = (await getTableColumns("orders")) || KNOWN_COLUMNS["orders"] || [];
        let queryBuilder = supabase.from("orders").update({
          status,
          timestamp: new Date().toISOString(),
          created_at: new Date().toISOString()
        });
        if (cols.includes("id") && cols.includes("_id")) {
          queryBuilder = queryBuilder.or(`id.eq.${orderId},_id.eq.${orderId}`);
        } else if (cols.includes("_id")) {
          queryBuilder = queryBuilder.eq("_id", orderId);
        } else {
          queryBuilder = queryBuilder.eq("id", orderId);
        }
        const { error } = await queryBuilder;
        if (error) handleSupabaseError(error, "updateOrderStatus");
      }
    } catch (e: any) {
      handleSupabaseError(e, "updateOrderStatus");
    }

    const localOrdersStr = localStorage.getItem("local_orders");
    if (localOrdersStr) {
      let localOrders = JSON.parse(localOrdersStr);
      const idx = localOrders.findIndex((o: any) => String(o._id) === sId || String(o.id) === sId);
      if (idx !== -1) {
        localOrders[idx] = normalizeOrder({
          ...localOrders[idx],
          status,
          timestamp: new Date().toISOString()
        });
        localStorage.setItem("local_orders", JSON.stringify(localOrders));
      }
    }
    triggerLocalOrdersChange();
    triggerBroadcast('orders_changed', { action: 'upsert', orderId, status });
  },

  updateSettings: async (payload: any, onProgress?: (msg: string) => void) => {
    try {
      if (onProgress) onProgress("正在优化图文并保存到云端... (Optimizing & saving to cloud...)");

      const cleanPayload = JSON.parse(JSON.stringify(payload));

      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        // Auto-extract inline base64 images and upload to Supabase Storage
        if (cleanPayload.categories && Array.isArray(cleanPayload.categories)) {
          for (const cat of cleanPayload.categories) {
            if (cat.items && Array.isArray(cat.items)) {
              for (const item of cat.items) {
                if (item.image) {
                  item.image = await ensureNoBase64Image(item.image, "dishes");
                }
              }
            }
          }
        }

        if (cleanPayload.promotions && Array.isArray(cleanPayload.promotions)) {
          for (const promo of cleanPayload.promotions) {
            if (promo.image) {
              promo.image = await ensureNoBase64Image(promo.image, "promotions");
            }
          }
        }

        if (cleanPayload.bgUrl) {
          cleanPayload.bgUrl = await ensureNoBase64Image(cleanPayload.bgUrl, "backgrounds");
        }

        if (cleanPayload.logoUrl) {
          cleanPayload.logoUrl = await ensureNoBase64Image(cleanPayload.logoUrl, "logos");
        }

        const dbPayload = await filterPayloadByTable("settings", cleanPayload);

        const { error } = await supabase
          .from("settings")
          .upsert({
            id: SETTINGS_DOC_ID,
            ...dbPayload
          });

        if (error) throw error;
        // 更新 KV 高速缓存
        await kvCache.set("app_settings", cleanPayload, 600);
        triggerBroadcast('settings_changed');

        // 自动将分类与菜品同步至 Supabase 关系表 (categories / menu_items)
        if (cleanPayload.categories && Array.isArray(cleanPayload.categories)) {
          api.syncCategoriesAndMenuItemsToSupabase(cleanPayload.categories).catch(err => {
            console.warn("[Auto-Sync] Failed to sync menu items to relational tables:", err);
          });
        }

        if (onProgress) onProgress("");
        settingsListeners.forEach(cb => cb(cleanPayload));
        return cleanPayload;
      }
    } catch (e: any) {
      handleSupabaseError(e, "updateSettings");
    }

    // Local fallback
    if (onProgress) onProgress("");
    if (payload.categories) localStorage.setItem("menuCategories", JSON.stringify(payload.categories));
    if (payload.promotions) localStorage.setItem("menuPromotions", JSON.stringify(payload.promotions));
    if (payload.bgUrl !== undefined) localStorage.setItem("menuBgUrl", payload.bgUrl);
    if (payload.restaurantName !== undefined) localStorage.setItem("menuRestaurantName", payload.restaurantName);
    if (payload.welcomeMessage !== undefined) localStorage.setItem("menuWelcomeMessage", payload.welcomeMessage);
    if (payload.logoUrl !== undefined) localStorage.setItem("menuLogoUrl", payload.logoUrl);
    if (payload.adminPassword !== undefined) localStorage.setItem("menuAdminPassword", payload.adminPassword);
    if (payload.devicePasswords !== undefined) localStorage.setItem("menuDevicePasswords", JSON.stringify(payload.devicePasswords));
    if (payload.securityQuestion !== undefined) localStorage.setItem("menuSecurityQuestion", payload.securityQuestion);
    if (payload.securityAnswer !== undefined) localStorage.setItem("menuSecurityAnswer", payload.securityAnswer);
    if (payload.soundEnabled !== undefined) localStorage.setItem("menuSoundEnabled", String(payload.soundEnabled));
    if (payload.layoutStyle !== undefined) localStorage.setItem("menuLayoutStyle", payload.layoutStyle);
    if (payload.receiptSettings !== undefined) localStorage.setItem("menuReceiptSettings", JSON.stringify(payload.receiptSettings));
    if (payload.deletedItemIds !== undefined) localStorage.setItem("menuDeletedItemIds", JSON.stringify(payload.deletedItemIds));
    if (payload.theme !== undefined) localStorage.setItem("menuThemeMode", payload.theme);
    
    await kvCache.set("app_settings", payload, 600);
    settingsListeners.forEach(cb => cb(payload));
    triggerBroadcast('settings_changed');
    return payload;
  },

  uploadBlob: async (base64: string, basePath: string) => {
    try {
      const { compressBase64Image } = await import("./utils/image");
      // Compress image to optimized web size
      const compressedBase64 = await compressBase64Image(base64, 800, 800, 0.72);

      // 使用 腾讯云 COS / Supabase Storage 统一 Blob 存储适配器
      const publicUrl = await blobStorage.uploadImage(compressedBase64, basePath);
      if (publicUrl) {
        return publicUrl;
      }
    } catch (e: any) {
      console.warn("Blob Storage upload failed, falling back to local compressed base64 image", e);
    }

    // Safe Fail-fast fallback: compress to a high-quality thumbnail (600x600, 75% quality).
    // This is perfectly suited for mobile viewports and keeps sizes optimized for database storage!
    try {
      const { compressBase64Image } = await import("./utils/image");
      return await compressBase64Image(base64, 600, 600, 0.75);
    } catch (err) {
      return base64;
    }
  },

  getStorageDiagnostics: async () => {
    if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
      try {
        const folders = ["dishes", "backgrounds", "bg", "logo", "promotions", "categories"];
        let totalSizeBytes = 0;
        const allFiles: Array<{ name: string; path: string; size: number; createdAt: string }> = [];

        // Add root files and discover additional folders
        try {
          const { data: rootItems, error: rootError } = await supabase.storage.from("menu-assets").list("");
          if (!rootError && rootItems) {
            for (const item of rootItems) {
              if (item.name === ".emptyFolderPlaceholder") continue;
              const size = item.metadata?.size || (item as any).size || 0;
              if (size > 0) {
                totalSizeBytes += size;
                allFiles.push({
                  name: item.name,
                  path: item.name,
                  size: size,
                  createdAt: item.created_at || ""
                });
              } else if (!folders.includes(item.name) && item.name.indexOf('.') === -1) {
                folders.push(item.name);
              }
            }
          }
        } catch (rootErr) {
          console.warn("Failed to list root folder:", rootErr);
        }

        // List files in all folders
        for (const folder of folders) {
          try {
            const { data, error } = await supabase.storage.from("menu-assets").list(folder);
            if (error) {
              console.warn(`Failed to list folder ${folder} in diagnostics:`, error);
              continue;
            }
            if (data) {
              for (const file of data) {
                if (file.name === ".emptyFolderPlaceholder") continue;
                const size = file.metadata?.size || (file as any).size || 0;
                totalSizeBytes += size;
                allFiles.push({
                  name: file.name,
                  path: `${folder}/${file.name}`,
                  size: size,
                  createdAt: file.created_at || ""
                });
              }
            }
          } catch (folderErr) {
            console.warn(`Error scanning folder ${folder}:`, folderErr);
          }
        }

        // Sort allFiles by size descending
        allFiles.sort((a, b) => b.size - a.size);

        return {
          success: true,
          totalUsedBytes: totalSizeBytes,
          bucketLimitBytes: 1024 * 1024 * 1024, // 1 GB free limit
          files: allFiles,
          configured: true
        };
      } catch (err: any) {
        console.error("Storage diagnostics failed:", err);
        return { success: false, error: err.message, configured: true };
      }
    }
    return { success: false, error: "Supabase not configured or unhealthy", configured: false };
  },

  deleteStorageFile: async (filePath: string) => {
    if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
      try {
        const { data, error } = await supabase.storage.from("menu-assets").remove([filePath]);
        if (error) throw error;
        return { success: true, data };
      } catch (err: any) {
        console.error("Failed to delete storage file:", err);
        return { success: false, error: err.message };
      }
    }
    return { success: false, error: "Supabase not configured or unhealthy" };
  },

  // Static Table QR
  createTableQr: async (tableNo: string) => {
    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        // Check first
        const { data: existing, error: selectError } = await supabase
          .from("tables")
          .select("*")
          .eq("tableNo", tableNo)
          .maybeSingle();

        if (selectError) throw selectError;
        if (existing) {
          return existing;
        }

        const key = Math.random().toString(36).substring(2, 10);
        const tableData = {
          tableNo,
          key,
          active: true,
          createdAt: new Date().toISOString(),
        };

        const { error: insertError } = await supabase
          .from("tables")
          .insert(tableData);

        if (insertError) throw insertError;
        triggerBroadcast('tables_changed');
        return tableData;
      }
    } catch (e: any) {
      handleSupabaseError(e, "createTableQr");
    }

    // Local Fallback
    const localTablesStr = localStorage.getItem("local_tables");
    let localTables = localTablesStr ? JSON.parse(localTablesStr) : [];
    const existingIdx = localTables.findIndex((t: any) => t.tableNo === tableNo);
    const tableData = {
      tableNo,
      key: Math.random().toString(36).substring(2, 10),
      active: true,
      createdAt: new Date().toISOString(),
    };

    if (existingIdx !== -1) {
      return localTables[existingIdx];
    } else {
      localTables.push(tableData);
      localStorage.setItem("local_tables", JSON.stringify(localTables));
      triggerLocalTablesChange();
      triggerBroadcast('tables_changed');
      return tableData;
    }
  },

  getTableQr: async (tableNo: string) => {
    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { data, error } = await supabase
          .from("tables")
          .select("*")
          .eq("tableNo", tableNo)
          .maybeSingle();
        if (error) throw error;
        if (data) {
          return data;
        }
      }
    } catch (e: any) {
      handleSupabaseReadError(e, "getTableQr");
    }

    const localTablesStr = localStorage.getItem("local_tables");
    const localTables = localTablesStr ? JSON.parse(localTablesStr) : [];
    return localTables.find((t: any) => t.tableNo === tableNo) || null;
  },

  updateTableStatus: async (tableNo: string, active: boolean) => {
    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { error } = await supabase
          .from("tables")
          .update({ active })
          .eq("tableNo", tableNo);
        if (error) throw error;
        triggerBroadcast('tables_changed');
      }
    } catch (e: any) {
      handleSupabaseError(e, "updateTableStatus");
    }

    // Local
    const localTablesStr = localStorage.getItem("local_tables");
    if (localTablesStr) {
      let localTables = JSON.parse(localTablesStr);
      const idx = localTables.findIndex((t: any) => t.tableNo === tableNo);
      if (idx !== -1) {
        localTables[idx] = { ...localTables[idx], active };
        localStorage.setItem("local_tables", JSON.stringify(localTables));
        triggerLocalTablesChange();
        triggerBroadcast('tables_changed');
      }
    }
  },

  deleteTableQr: async (tableNo: string) => {
    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { error } = await supabase
          .from("tables")
          .delete()
          .eq("tableNo", tableNo);
        if (error) throw error;
        triggerBroadcast('tables_changed');
      }
    } catch (e: any) {
      handleSupabaseError(e, "deleteTableQr");
    }

    // Local
    const localTablesStr = localStorage.getItem("local_tables");
    if (localTablesStr) {
      let localTables = JSON.parse(localTablesStr);
      localTables = localTables.filter((t: any) => t.tableNo !== tableNo);
      localStorage.setItem("local_tables", JSON.stringify(localTables));
      triggerLocalTablesChange();
      triggerBroadcast('tables_changed');
    }
  },

  subscribeToTables: (callback: (tables: any[]) => void) => {
    tablesListeners.push(callback);
    
    let lastJson = "";
    const fetchAndTrigger = async () => {
      let remoteTables: any[] = [];
      try {
        if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
          const { data, error } = await supabase
            .from("tables")
            .select("*");
          if (error) throw error;
          if (data) {
            remoteTables = data;
          }
        }
      } catch (e) {
        handleSupabaseReadError(e, "subscribeToTables fetchAndTrigger");
      }
      
      const localTablesStr = localStorage.getItem("local_tables");
      const localTables = localTablesStr ? JSON.parse(localTablesStr) : [];
      
      const merged = [...remoteTables];
      localTables.forEach((lt: any) => {
        if (!merged.some(rt => rt.tableNo === lt.tableNo)) {
          merged.push(lt);
        }
      });

      const currentJson = JSON.stringify(merged);
      if (currentJson !== lastJson) {
        lastJson = currentJson;
        callback(merged);
        tablesListeners.forEach(cb => {
          if (cb !== callback) cb(merged);
        });
      }
    };

    // Immediate fetch
    fetchAndTrigger();

    // Ensure unified sync channel
    ensureSyncChannel();

    // Active polling fallback (ONLY polls if Supabase is unhealthy or unconfigured to sync local tabs)
    // Avoids polling the database if Supabase is connected and healthy
    const pollInterval = setInterval(() => {
      if (!isSupabaseConfigured || !isSupabaseHealthy) {
        fetchAndTrigger();
      }
    }, 5000);

    // Passive refresh on window focus / tab visible
    let lastFetchTime = 0;
    const handleFocus = () => {
      const now = Date.now();
      if (now - lastFetchTime < 30000) return; // 30s throttle
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        lastFetchTime = now;
        fetchAndTrigger();
      }
    };
    window.addEventListener("focus", handleFocus);
    document.addEventListener("visibilitychange", handleFocus);

    return () => {
      tablesListeners = tablesListeners.filter(l => l !== callback);
      clearInterval(pollInterval);
      window.removeEventListener("focus", handleFocus);
      document.removeEventListener("visibilitychange", handleFocus);
    };
  },

  // ==========================================
  // 库存物料 & BOM配方 API 接口
  // ==========================================
  getInventoryItems: async (): Promise<any[]> => {
    // 尝试从 KV 读取
    const cachedKv = await kvCache.get<any[]>("inventory_items");
    if (cachedKv) return cachedKv;

    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { data, error } = await supabase
          .from("inventory_items")
          .select("*")
          .order("id", { ascending: true });
        if (error) throw error;
        if (data && data.length > 0) {
          kvCache.set("inventory_items", data, 300);
          return data;
        }
      }
    } catch (e) {
      handleSupabaseReadError(e, "getInventoryItems");
    }

    const localStr = localStorage.getItem("local_inventory_items");
    if (localStr) {
      return JSON.parse(localStr);
    }
    localStorage.setItem("local_inventory_items", JSON.stringify(DEFAULT_INVENTORY_ITEMS));
    return DEFAULT_INVENTORY_ITEMS;
  },

  saveInventoryItem: async (item: any) => {
    const payload = await filterPayloadByTable("inventory_items", {
      ...item,
      updated_at: new Date().toISOString()
    });

    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { error } = await supabase
          .from("inventory_items")
          .upsert(payload, { onConflict: "id" });
        if (error) throw error;
        triggerBroadcast("inventory_changed");
      }
    } catch (e) {
      handleSupabaseError(e, "saveInventoryItem");
    }

    const localStr = localStorage.getItem("local_inventory_items");
    let localItems: any[] = localStr ? JSON.parse(localStr) : [...DEFAULT_INVENTORY_ITEMS];
    const idx = localItems.findIndex((i: any) => i.id === item.id);
    if (idx !== -1) {
      localItems[idx] = { ...localItems[idx], ...payload };
    } else {
      localItems.push(payload);
    }
    localStorage.setItem("local_inventory_items", JSON.stringify(localItems));
    kvCache.invalidate("inventory_items");
    triggerLocalInventoryChange();
    triggerBroadcast("inventory_changed");
  },

  deleteInventoryItem: async (id: string) => {
    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { error } = await supabase
          .from("inventory_items")
          .delete()
          .eq("id", id);
        if (error) throw error;
        triggerBroadcast("inventory_changed");
      }
    } catch (e) {
      handleSupabaseError(e, "deleteInventoryItem");
    }

    kvCache.invalidate("inventory_items");
    const localStr = localStorage.getItem("local_inventory_items");
    if (localStr) {
      let localItems: any[] = JSON.parse(localStr);
      localItems = localItems.filter((i: any) => i.id !== id);
      localStorage.setItem("local_inventory_items", JSON.stringify(localItems));
      triggerLocalInventoryChange();
      triggerBroadcast("inventory_changed");
    }
  },

  getRecipeBoms: async (): Promise<any[]> => {
    // 尝试从 KV 缓存中快速读取 BOM 配方
    const cachedBoms = await kvCache.get<any[]>("recipe_boms");
    if (cachedBoms) return cachedBoms;

    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { data, error } = await supabase
          .from("recipe_boms")
          .select("*");
        if (error) throw error;
        if (data && data.length > 0) {
          kvCache.set("recipe_boms", data, 300);
          return data;
        }
      }
    } catch (e) {
      handleSupabaseReadError(e, "getRecipeBoms");
    }

    const localStr = localStorage.getItem("local_recipe_boms");
    if (localStr) {
      return JSON.parse(localStr);
    }
    localStorage.setItem("local_recipe_boms", JSON.stringify(DEFAULT_RECIPE_BOMS));
    return DEFAULT_RECIPE_BOMS;
  },

  saveRecipeBom: async (bom: any) => {
    const payload = await filterPayloadByTable("recipe_boms", {
      ...bom,
      id: bom.id || "BOM-" + Math.random().toString(36).substring(2, 9)
    });

    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { error } = await supabase
          .from("recipe_boms")
          .upsert(payload, { onConflict: "id" });
        if (error) throw error;
        triggerBroadcast("inventory_changed");
      }
    } catch (e) {
      handleSupabaseError(e, "saveRecipeBom");
    }

    kvCache.invalidate("recipe_boms");
    const localStr = localStorage.getItem("local_recipe_boms");
    let localBoms: any[] = localStr ? JSON.parse(localStr) : [...DEFAULT_RECIPE_BOMS];
    const idx = localBoms.findIndex((b: any) => b.id === payload.id);
    if (idx !== -1) {
      localBoms[idx] = { ...localBoms[idx], ...payload };
    } else {
      localBoms.push(payload);
    }
    localStorage.setItem("local_recipe_boms", JSON.stringify(localBoms));
    triggerLocalInventoryChange();
    triggerBroadcast("inventory_changed");
  },

  deleteRecipeBom: async (id: string) => {
    try {
      if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
        const { error } = await supabase
          .from("recipe_boms")
          .delete()
          .eq("id", id);
        if (error) throw error;
        triggerBroadcast("inventory_changed");
      }
    } catch (e) {
      handleSupabaseError(e, "deleteRecipeBom");
    }

    kvCache.invalidate("recipe_boms");
    const localStr = localStorage.getItem("local_recipe_boms");
    if (localStr) {
      let localBoms: any[] = JSON.parse(localStr);
      localBoms = localBoms.filter((b: any) => b.id !== id);
      localStorage.setItem("local_recipe_boms", JSON.stringify(localBoms));
      triggerLocalInventoryChange();
      triggerBroadcast("inventory_changed");
    }
  },

  subscribeToInventory: (callback: () => void) => {
    inventoryListeners.push(callback);
    ensureSyncChannel();
    return () => {
      inventoryListeners = inventoryListeners.filter(l => l !== callback);
    };
  },

  deductInventoryForOrderItems: async (items: any[]) => {
    if (!items || !Array.isArray(items) || items.length === 0) return;

    try {
      const inventory = await api.getInventoryItems();
      const boms = await api.getRecipeBoms();

      if (!inventory.length || !boms.length) return;

      const updatedMap = new Map<string, any>();
      inventory.forEach(item => updatedMap.set(item.id, { ...item }));

      let inventoryChanged = false;

      for (const orderItem of items) {
        const itemName = orderItem.title || orderItem.name;
        const qty = Number(orderItem.quantity || orderItem.count || 1);
        if (!itemName || isNaN(qty) || qty <= 0) continue;

        // Match BOMs by menu item name
        const matchingBoms = boms.filter(
          (b: any) => b.menu_item_name && b.menu_item_name.trim().toLowerCase() === itemName.trim().toLowerCase()
        );

        for (const bom of matchingBoms) {
          const targetInv = updatedMap.get(bom.inventory_item_id);
          if (targetInv) {
            const deduction = Number(bom.dosage) * qty;
            const currentStock = Number(targetInv.stock || 0);
            const newStock = Math.max(0, Number((currentStock - deduction).toFixed(2)));
            targetInv.stock = newStock;
            targetInv.updated_at = new Date().toISOString();
            updatedMap.set(bom.inventory_item_id, targetInv);
            inventoryChanged = true;
          }
        }
      }

      if (inventoryChanged) {
        for (const [, invItem] of updatedMap) {
          await api.saveInventoryItem(invItem);
        }
      }
    } catch (err) {
      console.warn("Failed automatic BOM deduction:", err);
    }
  },

  syncCategoriesAndMenuItemsToSupabase: async (categories: any[]) => {
    if (!categories || !Array.isArray(categories)) return;
    if (supabase && isSupabaseConfigured && isSupabaseHealthy) {
      try {
        for (let i = 0; i < categories.length; i++) {
          const cat = categories[i];
          const catName = cat.name || cat.title || "未命名分类";

          const { data: existingCat } = await supabase
            .from("categories")
            .select("id")
            .eq("name", catName)
            .maybeSingle();

          let catId = existingCat?.id;
          if (!catId) {
            const { data: insertedCat } = await supabase
              .from("categories")
              .insert({ name: catName, sort_order: i })
              .select("id")
              .single();
            catId = insertedCat?.id;
          }

          if (cat.items && Array.isArray(cat.items)) {
            for (const item of cat.items) {
              const itemTitle = item.title || item.name;
              if (!itemTitle) continue;
              const numericPrice = parseFloat(String(item.price || "0").replace(/[^\d.]/g, "")) || 0;

              const { data: existingDish } = await supabase
                .from("menu_items")
                .select("id")
                .eq("name", itemTitle)
                .maybeSingle();

              const itemPayload = {
                name: itemTitle,
                category_id: catId,
                price: numericPrice,
                image_url: item.image || "",
                description: item.description || "",
                is_available: !item.isSoldOut
              };

              if (existingDish?.id) {
                await supabase
                  .from("menu_items")
                  .update(itemPayload)
                  .eq("id", existingDish.id);
              } else {
                await supabase
                  .from("menu_items")
                  .insert(itemPayload);
              }
            }
          }
        }
      } catch (e) {
        console.warn("Failed to sync menu items to relational Supabase tables:", e);
      }
    }
  },

  getProductionDatabaseStats: async () => {
    if (!supabase || !isSupabaseConfigured || !isSupabaseHealthy) {
      return { connected: false, tables: {} };
    }
    const tableList = ["settings", "categories", "menu_items", "inventory_items", "recipe_boms", "tables", "orders"];
    const stats: Record<string, number> = {};
    for (const tableName of tableList) {
      try {
        const { count, error } = await supabase.from(tableName).select("*", { count: "exact", head: true });
        stats[tableName] = error ? -1 : (count ?? 0);
      } catch {
        stats[tableName] = -1;
      }
    }
    return { connected: true, tables: stats };
  },

  seedProductionDatabase: async (force: boolean = false) => {
    if (!supabase || !isSupabaseConfigured || !isSupabaseHealthy) {
      return { success: false, logs: ["❌ Supabase 未正确配置或连接故障"] };
    }

    const logs: string[] = [];

    try {
      // 1. settings 表全局数据初始化
      const { data: existingSettings } = await supabase.from("settings").select("*").eq("id", SETTINGS_DOC_ID).maybeSingle();
      let categoriesToSync = INITIAL_MENU_CATEGORIES;

      if (!existingSettings || !existingSettings.categories || existingSettings.categories.length === 0 || force) {
        const defaultSettingsPayload = {
          id: SETTINGS_DOC_ID,
          categories: INITIAL_MENU_CATEGORIES,
          promotions: existingSettings?.promotions || [],
          bgUrl: existingSettings?.bgUrl || "",
          restaurantName: existingSettings?.restaurantName || "炙·双味居",
          welcomeMessage: existingSettings?.welcomeMessage || "Premium Charcoal BBQ",
          logoUrl: existingSettings?.logoUrl || "",
          adminPassword: existingSettings?.adminPassword || "admin123",
          devicePasswords: existingSettings?.devicePasswords || [],
          securityQuestion: existingSettings?.securityQuestion || "",
          securityAnswer: existingSettings?.securityAnswer || "",
          soundEnabled: existingSettings?.soundEnabled ?? true,
          layoutStyle: existingSettings?.layoutStyle || "grid",
          receiptSettings: existingSettings?.receiptSettings || {},
          deletedItemIds: existingSettings?.deletedItemIds || [],
          theme: existingSettings?.theme || "midnight"
        };
        await supabase.from("settings").upsert(defaultSettingsPayload);
        logs.push("✅ settings 表全局设置数据已成功初始化");
      } else {
        categoriesToSync = mergeAndOrderCategories(existingSettings.categories, INITIAL_MENU_CATEGORIES);
        if (JSON.stringify(categoriesToSync) !== JSON.stringify(existingSettings.categories)) {
          await supabase.from("settings").update({ categories: categoriesToSync }).eq("id", SETTINGS_DOC_ID);
          logs.push("✅ settings 表已同步更新最新的菜单分类与新菜品排序");
        } else {
          logs.push("ℹ️ settings 表已包含最新设置数据");
        }
      }

      // 2. 同步 categories 和 menu_items 关系表
      try {
        await api.syncCategoriesAndMenuItemsToSupabase(categoriesToSync);
        logs.push(`✅ 已成功同步 ${categoriesToSync.length} 个分类及相关菜品至 categories / menu_items 表`);
      } catch (e: any) {
        logs.push(`⚠️ categories / menu_items 同步通知: ${e.message || e}`);
      }

      // 3. inventory_items 原材料库存表初始化
      const { count: invCount } = await supabase.from("inventory_items").select("*", { count: "exact", head: true });
      if ((invCount === 0 || invCount === null || force) && DEFAULT_INVENTORY_ITEMS.length > 0) {
        for (const item of DEFAULT_INVENTORY_ITEMS) {
          await supabase.from("inventory_items").upsert({
            ...item,
            updated_at: new Date().toISOString()
          }, { onConflict: "id" });
        }
        logs.push(`✅ inventory_items 库存表已成功初始化 (${DEFAULT_INVENTORY_ITEMS.length} 种物料)`);
      } else {
        logs.push(`ℹ️ inventory_items 表当前包含 ${invCount ?? 0} 条物料记录`);
      }

      // 4. recipe_boms BOM配方表初始化
      const { count: bomCount } = await supabase.from("recipe_boms").select("*", { count: "exact", head: true });
      if ((bomCount === 0 || bomCount === null || force) && DEFAULT_RECIPE_BOMS.length > 0) {
        for (const bom of DEFAULT_RECIPE_BOMS) {
          await supabase.from("recipe_boms").upsert(bom, { onConflict: "id" });
        }
        logs.push(`✅ recipe_boms 配方表已成功初始化 (${DEFAULT_RECIPE_BOMS.length} 条 BOM 配方)`);
      } else {
        logs.push(`ℹ️ recipe_boms 表当前包含 ${bomCount ?? 0} 条配方记录`);
      }

      // 5. tables 二维码餐桌表初始化
      const { count: tableCount } = await supabase.from("tables").select("*", { count: "exact", head: true });
      if (tableCount === 0 || tableCount === null || force) {
        const defaultTables = ["A1", "A2", "A3", "A4", "A5", "A6", "B1", "B2", "B3", "B4", "C1", "C2"];
        for (const tNo of defaultTables) {
          await supabase.from("tables").upsert({
            tableNo: tNo,
            key: Math.random().toString(36).substring(2, 10),
            active: true,
            createdAt: new Date().toISOString()
          }, { onConflict: "tableNo" });
        }
        logs.push(`✅ tables 餐桌表已成功初始化 (${defaultTables.length} 个基础餐桌)`);
      } else {
        logs.push(`ℹ️ tables 餐桌表当前包含 ${tableCount ?? 0} 条餐桌记录`);
      }

      // 刷新缓存
      kvCache.invalidate("app_settings");
      kvCache.invalidate("inventory_items");
      kvCache.invalidate("recipe_boms");

      triggerBroadcast('settings_changed');
      triggerBroadcast('inventory_changed');
      triggerBroadcast('tables_changed');

      return { success: true, logs };
    } catch (err: any) {
      logs.push(`❌ 初始化数据发生错误: ${err.message || err}`);
      return { success: false, logs };
    }
  }
};

export const DEFAULT_INVENTORY_ITEMS = [
  { id: "INV-101", name: "特级雪花牛肉", category: "肉类与海鲜", stock: 50.0, unit: "kg", safety_stock: 5.0, price: 80.0, updated_at: new Date().toISOString() },
  { id: "INV-102", name: "精选猪肉鲜肉馅", category: "肉类与海鲜", stock: 40.0, unit: "kg", safety_stock: 4.0, price: 40.0, updated_at: new Date().toISOString() },
  { id: "INV-103", name: "农家鲜土鸡", category: "肉类与海鲜", stock: 30.0, unit: "kg", safety_stock: 3.0, price: 35.0, updated_at: new Date().toISOString() },
  { id: "INV-104", name: "饺子皮面粉", category: "粮油面粉", stock: 80.0, unit: "kg", safety_stock: 8.0, price: 8.0, updated_at: new Date().toISOString() },
  { id: "INV-105", name: "重庆特级朝天椒", category: "调料香料", stock: 15.0, unit: "kg", safety_stock: 2.0, price: 25.0, updated_at: new Date().toISOString() },
  { id: "INV-106", name: "香浓高汤原汁", category: "汤底底料", stock: 60.0, unit: "L", safety_stock: 10.0, price: 12.0, updated_at: new Date().toISOString() },
];

export const DEFAULT_RECIPE_BOMS = [
  { id: "BOM-101", menu_item_name: "清汤锅底", inventory_item_id: "INV-103", dosage: 0.3, unit: "kg" },
  { id: "BOM-102", menu_item_name: "清汤锅底", inventory_item_id: "INV-106", dosage: 1.5, unit: "L" },
  { id: "BOM-103", menu_item_name: "汤饺", inventory_item_id: "INV-102", dosage: 0.25, unit: "kg" },
  { id: "BOM-104", menu_item_name: "汤饺", inventory_item_id: "INV-104", dosage: 0.15, unit: "kg" },
  { id: "BOM-105", menu_item_name: "汤饺", inventory_item_id: "INV-106", dosage: 0.5, unit: "L" },
  { id: "BOM-106", menu_item_name: "汤饺 (小份)", inventory_item_id: "INV-102", dosage: 0.18, unit: "kg" },
  { id: "BOM-107", menu_item_name: "汤饺 (小份)", inventory_item_id: "INV-104", dosage: 0.10, unit: "kg" },
  { id: "BOM-108", menu_item_name: "汤饺 (小份)", inventory_item_id: "INV-106", dosage: 0.35, unit: "L" },
  { id: "BOM-109", menu_item_name: "煎饺", inventory_item_id: "INV-102", dosage: 0.25, unit: "kg" },
  { id: "BOM-110", menu_item_name: "煎饺", inventory_item_id: "INV-104", dosage: 0.15, unit: "kg" },
  { id: "BOM-111", menu_item_name: "煎饺 (小份)", inventory_item_id: "INV-102", dosage: 0.18, unit: "kg" },
  { id: "BOM-112", menu_item_name: "煎饺 (小份)", inventory_item_id: "INV-104", dosage: 0.10, unit: "kg" },
];
