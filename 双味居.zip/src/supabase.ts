import { createClient } from "@supabase/supabase-js";

const customUrl = typeof window !== "undefined" ? localStorage.getItem("custom_supabase_url") : null;
const customKey = typeof window !== "undefined" ? localStorage.getItem("custom_supabase_anon_key") : null;

export const supabaseUrl = customUrl || import.meta.env.VITE_SUPABASE_URL || "";
export const supabaseAnonKey = customKey || import.meta.env.VITE_SUPABASE_ANON_KEY || "";

export const isSupabaseConfigured = !!(supabaseUrl && supabaseAnonKey);

export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

export let isSupabaseHealthy = true;

export const getSupabaseHealthy = () => {
  return isSupabaseHealthy;
};

export const setSupabaseHealthy = (val: boolean) => {
  isSupabaseHealthy = val;
};

