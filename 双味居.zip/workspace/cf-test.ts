import fs from 'fs';
const token = 'cfat_LOj3kFqfi8wGk7Wnhi0hWeKPpesT55ccaXdvWR8l0611684e';
fetch('https://api.cloudflare.com/client/v4/accounts', {
  headers: {
    'Authorization': 'Bearer ' + token,
    'Content-Type': 'application/json'
  }
}).then(r => r.json()).then(data => console.log(JSON.stringify(data))).catch(console.error);
