-- ======================================================================
-- 餐饮点餐系统 (Customer Menu) + POS 后厨管理 + 库存管理系统 (Inventory POS)
-- 共用 Supabase 数据库统一初始化 SQL 脚本 (supabase_schema.sql)
--
-- 使用指南：
-- 1. 登录您的 Supabase 控制台 (https://supabase.com) 并进入您的项目
-- 2. 点击左侧菜单 "SQL Editor"
-- 3. 点击 "New query"，将本文件全选复制粘贴进去，点击 "Run" 运行
-- 4. 在两端程序的 .env 文件中填入相同的 VITE_SUPABASE_URL 和 VITE_SUPABASE_ANON_KEY
-- ======================================================================

-- 1. 菜单分类表 (categories)
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  sort_order INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. 菜单菜品表 (menu_items) - 菜单程序 & POS/库存管理系统共用
CREATE TABLE IF NOT EXISTS public.menu_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
  name VARCHAR(100) NOT NULL,
  price DECIMAL(10, 2) NOT NULL DEFAULT 0,
  image_url TEXT,
  description TEXT,
  is_available BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. 实时订单表 (orders) - 菜单程序下单，POS/后厨/库存管理端实时接收
CREATE TABLE IF NOT EXISTS public.orders (
  id VARCHAR(100) PRIMARY KEY,
  _id VARCHAR(100),
  table_no VARCHAR(50) NOT NULL DEFAULT 'A1',
  customer_name VARCHAR(100),
  type VARCHAR(20) DEFAULT 'dine_in' CHECK (type IN ('dine_in', 'takeaway', 'delivery')),
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'cooking', 'served', 'completed', 'cancelled')),
  total_amount DECIMAL(10, 2) NOT NULL DEFAULT 0,
  total DECIMAL(10, 2) DEFAULT 0,
  items JSONB DEFAULT '[]'::jsonb,
  notes TEXT DEFAULT '',
  "unprintedNewOrder" BOOLEAN DEFAULT false,
  "unprintedAdditions" JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  "createdAt" TIMESTAMPTZ DEFAULT NOW()
);

-- 4. 订单明细表 (order_items)
CREATE TABLE IF NOT EXISTS public.order_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id VARCHAR(100) REFERENCES public.orders(id) ON DELETE CASCADE,
  menu_item_id UUID REFERENCES public.menu_items(id) ON DELETE SET NULL,
  name VARCHAR(100) NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(10, 2) NOT NULL DEFAULT 0,
  subtotal DECIMAL(10, 2) NOT NULL DEFAULT 0
);

-- 5. 原材料库存物料表 (inventory_items)
CREATE TABLE IF NOT EXISTS public.inventory_items (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL DEFAULT '常规物料',
  stock DECIMAL(10, 2) NOT NULL DEFAULT 0,
  unit VARCHAR(20) NOT NULL DEFAULT 'kg',
  safety_stock DECIMAL(10, 2) NOT NULL DEFAULT 5,
  price DECIMAL(10, 2) NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. 菜品-食材配方关联表 (recipe_boms) - BOM 自动扣减关系
CREATE TABLE IF NOT EXISTS public.recipe_boms (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  menu_item_name VARCHAR(100) NOT NULL,
  inventory_item_id VARCHAR(50) REFERENCES public.inventory_items(id) ON DELETE CASCADE,
  dosage DECIMAL(10, 2) NOT NULL DEFAULT 0, -- 消耗量 (如 0.2kg)
  unit VARCHAR(20) NOT NULL DEFAULT 'kg'
);

-- 7. 全局菜单与系统设置表 (settings) - 兼顾 JSON 模式与传统点餐应用兼容
CREATE TABLE IF NOT EXISTS public.settings (
    id TEXT PRIMARY KEY DEFAULT 'global',
    categories JSONB DEFAULT '[]'::jsonb,
    promotions JSONB DEFAULT '[]'::jsonb,
    "bgUrl" TEXT DEFAULT '',
    "restaurantName" TEXT DEFAULT '',
    "welcomeMessage" TEXT DEFAULT '',
    "logoUrl" TEXT DEFAULT '',
    "adminPassword" TEXT DEFAULT 'admin123',
    "devicePasswords" JSONB DEFAULT '[]'::jsonb,
    "securityQuestion" TEXT DEFAULT '',
    "securityAnswer" TEXT DEFAULT '',
    "soundEnabled" BOOLEAN DEFAULT true,
    "layoutStyle" TEXT DEFAULT 'grid',
    "receiptSettings" JSONB DEFAULT '{}'::jsonb,
    "theme" TEXT DEFAULT 'dark'
);

-- 插入默认设置记录 (如果未存在)
INSERT INTO public.settings (id) VALUES ('global') ON CONFLICT (id) DO NOTHING;

-- 8. 二维码餐桌表 (tables)
CREATE TABLE IF NOT EXISTS public.tables (
    "tableNo" TEXT PRIMARY KEY,
    key TEXT,
    active BOOLEAN DEFAULT true,
    "createdAt" TEXT
);

-- 关闭 RLS (行级安全策略)，确保跨程序读写无阻碍
ALTER TABLE public.categories DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.recipe_boms DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.tables DISABLE ROW LEVEL SECURITY;

-- 开启 Supabase Realtime 实时推播与广播订阅服务
ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.inventory_items;
ALTER PUBLICATION supabase_realtime ADD TABLE public.recipe_boms;
ALTER PUBLICATION supabase_realtime ADD TABLE public.menu_items;
ALTER PUBLICATION supabase_realtime ADD TABLE public.categories;
ALTER PUBLICATION supabase_realtime ADD TABLE public.settings;
ALTER PUBLICATION supabase_realtime ADD TABLE public.tables;
